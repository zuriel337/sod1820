import "jsr:@supabase/functions-js/edge-runtime.d.ts";

// ROLLBACK EQUIVALENT of the deployed contact-notify v1 (12.11.2026). Identical to v1 except one line: the recipient, which v1
// hard-coded as a personal address, is read from the server secret CONTACT_NOTIFY_TO (set it to the same address before use).
// The exact v1 bytes are not stored in the repository because they contain that personal address.
const ADMIN_EMAIL = Deno.env.get("CONTACT_NOTIFY_TO") ?? "";
const RESEND_KEY = Deno.env.get("RESEND_API_KEY") ?? "";
const FROM = Deno.env.get("NOTIFY_FROM") ?? Deno.env.get("NEWSLETTER_FROM") ?? "סוד 1820 <news@sod1820.co.il>";
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
  "Cache-Control": "no-store",
};
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: CORS });
const esc = (s: string) => s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  if (!RESEND_KEY || !ADMIN_EMAIL) return json({ error: "email_not_configured" }, 503);

  try {
    const body = await req.json();
    const name = String(body?.name ?? "גולש").trim().slice(0, 120) || "גולש";
    const email = String(body?.email ?? "").trim().slice(0, 254);
    const subject = String(body?.subject ?? "פנייה מהאתר").trim().slice(0, 200) || "פנייה מהאתר";
    const message = String(body?.message ?? "").trim().slice(0, 8000);
    if (!message || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return json({ error: "invalid_input" }, 400);

    const html = `<div dir="rtl" style="font-family:Arial,sans-serif;line-height:1.8">
      <h2>פנייה חדשה מטופס האתר SOD1820</h2>
      <p><b>שם:</b> ${esc(name)}</p>
      <p><b>אימייל:</b> <a href="mailto:${esc(email)}">${esc(email)}</a></p>
      <p><b>נושא:</b> ${esc(subject)}</p>
      <hr/><p style="white-space:pre-wrap">${esc(message)}</p>
      <hr/><p><a href="https://sod1820.co.il">sod1820.co.il</a></p>
    </div>`;
    const sent = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from: FROM, to: [ADMIN_EMAIL], reply_to: email, subject: `[SOD1820 Contact] ${subject}`, html }),
    });
    if (!sent.ok) {
      const detail = (await sent.text()).slice(0, 250);
      console.error("contact-notify-resend-failed", sent.status, detail);
      return json({ error: "email_send_failed" }, 502);
    }
    return json({ ok: true });
  } catch (error) {
    console.error("contact-notify-error", String(error).slice(0, 250));
    return json({ error: "internal_error" }, 500);
  }
});
