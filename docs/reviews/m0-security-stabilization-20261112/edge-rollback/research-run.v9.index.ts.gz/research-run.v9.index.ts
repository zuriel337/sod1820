// src/lib/research/researchIdentityResolver.js
var RESEARCH_IDENTITY_CONFIDENCE = Object.freeze({
  EXACT: "exact",
  STRONG: "strong",
  CANDIDATE: "candidate"
}), RESEARCH_IDENTITY_SOURCE = Object.freeze({
  EXPLICIT_REF: "explicit_ref",
  GRAPH_IDENTITY: "graph_identity",
  SURFACE_CONTEXT: "surface_context",
  PERSONAL_CONTEXT: "personal_context",
  TEXT_MATCH: "text_match",
  NUMERIC_LITERAL: "numeric_literal"
}), TYPE_PRIORITY = Object.freeze({
  person: 100,
  book: 95,
  event: 90,
  place: 85,
  number: 80,
  name: 75,
  verse: 70,
  topic: 65,
  phrase: 40,
  word: 35,
  entity: 20
});
function clean(value) {
  return value == null ? null : String(value).trim() || null;
}
function canonicalIdentityKey(identity) {
  return clean(identity?.identity_key) || clean(identity?.identityKey) || clean(identity?.ref) || clean(identity?.id) || [clean(identity?.type), clean(identity?.value ?? identity?.label)].filter(Boolean).join(":") || null;
}
function sourceWeight(source) {
  switch (source) {
    case RESEARCH_IDENTITY_SOURCE.EXPLICIT_REF:
      return 60;
    case RESEARCH_IDENTITY_SOURCE.GRAPH_IDENTITY:
      return 50;
    case RESEARCH_IDENTITY_SOURCE.SURFACE_CONTEXT:
      return 45;
    case RESEARCH_IDENTITY_SOURCE.PERSONAL_CONTEXT:
      return 40;
    case RESEARCH_IDENTITY_SOURCE.NUMERIC_LITERAL:
      return 35;
    case RESEARCH_IDENTITY_SOURCE.TEXT_MATCH:
      return 20;
    default:
      return 0;
  }
}
function confidenceWeight(confidence) {
  switch (confidence) {
    case RESEARCH_IDENTITY_CONFIDENCE.EXACT:
      return 30;
    case RESEARCH_IDENTITY_CONFIDENCE.STRONG:
      return 20;
    case RESEARCH_IDENTITY_CONFIDENCE.CANDIDATE:
      return 5;
    default:
      return 0;
  }
}
function normalizeIdentity(identity = {}) {
  let type = clean(identity.type) || "entity", value = identity.value ?? null, label = clean(identity.label ?? value) || "", source = clean(identity.source) || RESEARCH_IDENTITY_SOURCE.TEXT_MATCH, confidence = clean(identity.confidence) || RESEARCH_IDENTITY_CONFIDENCE.CANDIDATE, key = canonicalIdentityKey(identity);
  return key ? {
    key,
    type,
    id: clean(identity.id),
    ref: clean(identity.ref),
    identity_key: clean(identity.identity_key ?? identity.identityKey),
    label,
    value,
    source,
    confidence,
    provenance: identity.provenance ?? null,
    access: identity.access ?? null,
    metadata: identity.metadata ?? null
  } : null;
}
function identityRank(identity) {
  return (TYPE_PRIORITY[identity.type] || 0) + sourceWeight(identity.source) + confidenceWeight(identity.confidence);
}
function dedupeResearchIdentities(candidates = []) {
  let byKey = /* @__PURE__ */ new Map();
  for (let raw of Array.isArray(candidates) ? candidates : []) {
    let next = normalizeIdentity(raw);
    if (!next) continue;
    let existing = byKey.get(next.key);
    (!existing || identityRank(next) > identityRank(existing)) && byKey.set(next.key, next);
  }
  return [...byKey.values()].sort((a, b) => identityRank(b) - identityRank(a));
}
function resolveResearchIdentities({
  candidates = [],
  rawInput = null,
  explicitTextComputation = !1
} = {}) {
  let identities = dedupeResearchIdentities(candidates), semantic = identities.filter((x) => x.type !== "phrase" && x.type !== "word"), textRepresentations = identities.filter((x) => x.type === "phrase" || x.type === "word");
  return {
    v: 1,
    raw_input: rawInput == null ? null : String(rawInput),
    identities,
    primary: identities[0] || null,
    semantic,
    text_representations: textRepresentations,
    explicit_text_computation: !!explicitTextComputation,
    // When a semantic identity is known, free-text calculation must be opt-in. This is the direct
    // guard against Book title -> gematria drift discovered during the 1820 + Ahavat Torah audit.
    text_calculation_allowed: !!explicitTextComputation || semantic.length === 0
  };
}
function identityKinds(resolved) {
  return [...new Set((resolved?.identities || []).map((x) => x.type).filter(Boolean))];
}
function hasIdentityKind(resolved, kind) {
  return (resolved?.identities || []).some((x) => x.type === kind);
}

// src/lib/research/razielRouteAction.js
var RAZIEL_ROUTE_ACTION = Object.freeze({
  UNDERSTAND: "understand",
  RESEARCH: "research",
  CONNECT: "connect",
  CONTINUE: "continue"
});

// src/lib/research/razielSemanticIntentGate.js
var clean2 = (value, limit = 180) => value == null ? "" : String(value).normalize("NFKC").replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, limit), grammarText = (value) => clean2(value, 500).replace(/^\d{1,2}[.)]\s+/u, "").replace(/[־–—-]/gu, " ").replace(/[?؟!.]+$/gu, "").replace(/\s+/gu, " ").trim();
var NUMERIC_CONTEXT_LABELS = [
  "\u05E9\u05E0\u05EA",
  "\u05E9\u05E0\u05D4",
  "\u05E2\u05DE\u05D5\u05D3",
  "\u05D3\u05E3",
  "\u05E4\u05E8\u05E7",
  "\u05E4\u05E1\u05D5\u05E7",
  "\u05DE\u05E7\u05D5\u05E8",
  "\u05DE\u05E7\u05D5\u05E8\u05D5\u05EA",
  "\u05E9\u05D0\u05DC\u05D4",
  "\u05E9\u05D0\u05DC\u05D5\u05EA",
  "\u05EA\u05D5\u05E6\u05D0\u05D4",
  "\u05EA\u05D5\u05E6\u05D0\u05D5\u05EA",
  "\u05E7\u05E9\u05E8",
  "\u05E7\u05E9\u05E8\u05D9\u05DD",
  "\u05D4\u05E6\u05DC\u05D1\u05D4",
  "\u05D4\u05E6\u05DC\u05D1\u05D5\u05EA",
  "\u05E4\u05E2\u05DE\u05D9\u05DD",
  "\u05DB\u05DE\u05D5\u05EA"
];
function escapePattern(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function resolveRazielExpressionContinuationDirective(question) {
  let q = grammarText(question);
  if (!q || q.length > 140) return null;
  let command = /^(?:תחשב|חשב|חשבי|תחשבי)(?:\s+לי)?\s+(.+)$/u.exec(q);
  if (!command) return null;
  let remainder = clean2(command[1], 120), asksConnections = /(?:^|\s)(?:ומצא|מצא|וחפש|חפש|ובדוק|בדוק)(?:\s+לי)?\s+(?:הצלבות|קשרים)$/u.test(remainder);
  remainder = remainder.replace(/\s+(?:ומצא|מצא|וחפש|חפש|ובדוק|בדוק)(?:\s+לי)?\s+(?:הצלבות|קשרים)$/u, "").trim();
  let anaphor = /^(?:את\s+)?(?:זה|זאת|אותו|אותה)(?:\s+(.*))?$/u.exec(remainder), directive = clean2(anaphor ? anaphor[1] : remainder, 80);
  if (!anaphor && !/^(?:בכל\s+השיטות|במצב\s+(?:רגיל|כללי)|בשיטת\s+.+)$/u.test(directive) || directive && !/^(?:בכל\s+השיטות|במצב\s+(?:רגיל|כללי)|בשיטת\s+.{1,60})$/u.test(directive)) return null;
  let method = /^בשיטת\s+(.{1,60})$/u.exec(directive)?.[1] || null;
  return Object.freeze({
    requested_action: asksConnections ? "connect" : "research",
    requested_method: method ? clean2(method, 60) : null,
    all_methods: directive === "\u05D1\u05DB\u05DC \u05D4\u05E9\u05D9\u05D8\u05D5\u05EA",
    view_mode_only: /^במצב\s+(?:רגיל|כללי)$/u.test(directive)
  });
}
function validExplicitHebrewExpression(value) {
  let expression = clean2(value, 120).replace(/^["'״׳]+|["'״׳]+$/gu, "").replace(/[?؟!.]+$/gu, "").trim();
  return !expression || /^\d+$/u.test(expression) || !/[\u0590-\u05ff]/u.test(expression) || /^(?:ה?שם(?:\s+שלי)?|שמי|שלי|ה?מילה|ה?ביטוי|זה|זאת|משהו)$/u.test(expression) || /^(?:שנת|שנה|עמוד|דף|פרק|פסוק|מקור(?:ות)?)\s+\d+$/u.test(expression) ? null : expression;
}
function explicitExpressionCalculationCommand(question) {
  let q = grammarText(question), command = /^(?:תחשב|חשב|חשבי|תחשבי)(?:\s+לי)?(?:\s+את)?(?:\s+(?:המילה|הביטוי|השם))?\s+(.+)$/u.exec(q);
  if (!command) return null;
  let body = clean2(command[1], 240), connectionSuffix = /\s+(?:ומצא|מצא|וחפש|חפש|ובדוק|בדוק)(?:\s+לי)?\s+(?:הצלבות|קשרים)$/u, asksConnections = connectionSuffix.test(body);
  body = body.replace(connectionSuffix, "").trim();
  let marker = body.lastIndexOf(" \u05D1\u05E9\u05D9\u05D8\u05EA "), requestedMethod = marker > 0 ? clean2(body.slice(marker + 7), 60) : "", expressionText = marker > 0 ? body.slice(0, marker) : body.replace(/\s+(?:בגימטרי[הא]|בכל\s+השיטות|במצב\s+(?:רגיל|כללי))$/u, "").trim(), expression = validExplicitHebrewExpression(expressionText);
  return !expression || marker > 0 && (!requestedMethod || !/[\u0590-\u05ff]/u.test(requestedMethod)) ? null : Object.freeze({
    type: "phrase",
    label: expression,
    evidence_text: expression,
    identity_key: `phrase:${expression}`,
    source: RESEARCH_IDENTITY_SOURCE.TEXT_MATCH,
    confidence: RESEARCH_IDENTITY_CONFIDENCE.EXACT,
    requested_action: asksConnections ? "connect" : "research",
    ...requestedMethod ? { requested_method: requestedMethod } : {},
    explicit_text_computation: !0
  });
}
function resolveExplicitHebrewExpressionResearchSubject(question) {
  let q = grammarText(question);
  if (!q || resolveRazielExpressionContinuationDirective(q)) return null;
  let expressionCalculationCommand = explicitExpressionCalculationCommand(q);
  if (expressionCalculationCommand) return expressionCalculationCommand;
  let match = /^(?:מצא|מצאי|חפש|חפשי|בדוק|בדקי|תבדוק|תבדקי)(?:\s+לי)?\s+(?:הצלבות|קשרים)\s+(?:(?:למילה|לביטוי|לשם|עבור)\s+)(.+)$/u.exec(q), requestedAction = "connect", requestedMethod = null, observedValue = null;
  if (!match) {
    let focusedValue = /^(?:מה\s+(?:אתה\s+אומר|את\s+אומרת|דעתך)\s+על|(?:תסביר|הסבר|תסבירי|הסבירי)(?:\s+לי)?(?:\s+את)?)\s+(\d{1,12})\s+ה?(.{2,60}?)\s+של\s+(?:(?:המילה|הביטוי|השם)\s+)?(.+)$/u.exec(q);
    if (focusedValue) {
      match = [focusedValue[0], focusedValue[3]], requestedMethod = clean2(focusedValue[2], 60);
      let numeric = Number(focusedValue[1]);
      observedValue = Number.isSafeInteger(numeric) && numeric >= 1 ? numeric : null, requestedAction = "research";
    }
  }
  if (!match) {
    let focused = /^(?:(?:מה\s+(?:יש\s+לך|ידוע(?:\s+לך)?)\s+על)|(?:מה\s+(?:אומר(?:ת)?|מראה|מלמד(?:ת)?|מגלה))|(?:מה\s+(?:ה?משמעות|ה?פירוש)(?:\s+של)?)|(?:איך\s+(?:מפרשים|מפרשות|לפרש)(?:\s+את)?)|(?:ספר(?:י)?(?:\s+לי)?\s+על)|(?:(?:תסביר|הסבר|תסבירי|הסבירי)(?:\s+לי)?\s+את))\s+ה?(.{2,60}?)\s+של\s+(?:(?:המילה|הביטוי|השם)\s+)?(.+)$/u.exec(q);
    focused && (match = [focused[0], focused[2]], requestedMethod = clean2(focused[1], 60), requestedAction = "research");
  }
  match || (match = /^מה\s+זה\s+(.+?)\s+בגימטרי[הא](?:\s+ו(?:מה|אילו)\s+(?:ההצלבות|הקשרים)(?:\s+(?:שיש|שלו|שלה|קיימים|קיימות))?)?$/u.exec(q), requestedAction = /(?:הצלבות|קשרים)/u.test(q) ? "connect" : "research"), match || (match = /^מה\s+(?:הגימטרי[הא]|הערך)\s+של\s+(.+?)(?:\s+ו(?:מה|אילו)\s+(?:ההצלבות|הקשרים)(?:\s+(?:שיש|שלו|שלה|קיימים|קיימות))?)?$/u.exec(q), requestedAction = /(?:הצלבות|קשרים)/u.test(q) ? "connect" : "research"), match || (match = /^(?:כמה\s+(?:זה|שווה)|מה\s+שווה)\s+(.+?)\s+בגימטרי[הא]$/u.exec(q), requestedAction = "research"), match || (match = /^(?:בדוק|בדקי|תבדוק|תבדקי|תן|תני)(?:\s+לי)?(?:\s+את)?\s+(?:הגימטרי[הא]|הערך\s+הגימטרי)\s+(?:של\s+)?(.+?)(?:\s+(?:ומצא|וחפש|ובדוק)(?:\s+לי)?\s+(?:הצלבות|קשרים))?$/u.exec(q), requestedAction = /(?:הצלבות|קשרים)/u.test(q) ? "connect" : "research"), match || (match = /^(?:תחשב|חשב|חשבי|תחשבי)(?:\s+לי)?(?:\s+את)?(?:\s+(?:המילה|הביטוי|השם))?\s+(.+?)(?:\s+(?:ומצא|וחפש|ובדוק)(?:\s+לי)?\s+(?:הצלבות|קשרים))?$/u.exec(q), requestedAction = /(?:הצלבות|קשרים)/u.test(q) ? "connect" : "research");
  let label = match ? validExplicitHebrewExpression(match[1]) : null;
  return label ? Object.freeze({
    type: "phrase",
    label,
    evidence_text: label,
    identity_key: `phrase:${label}`,
    source: RESEARCH_IDENTITY_SOURCE.TEXT_MATCH,
    confidence: RESEARCH_IDENTITY_CONFIDENCE.EXACT,
    requested_action: requestedAction,
    ...requestedMethod ? { requested_method: requestedMethod } : {},
    ...observedValue != null ? { observed_value: observedValue } : {},
    explicit_text_computation: !0
  }) : null;
}
function resolveExplicitNumericResearchSubject(question) {
  let q = grammarText(question);
  if (!q) return null;
  let numericTokens = [...q.matchAll(/(?<!\d)\d{1,6}(?!\d)/gu)].map((match) => match[0]);
  if (numericTokens.length !== 1) return null;
  let literal = numericTokens[0], value = Number(literal);
  if (!Number.isSafeInteger(value) || value < 1 || value > 999999) return null;
  let escaped = escapePattern(literal), contextLabels = NUMERIC_CONTEXT_LABELS.join("|"), contextualBefore = new RegExp(`(?:^|\\s)(?:${contextLabels})\\s+(?:\u05DE\u05E1\u05E4\u05E8\\s+)?${escaped}(?:$|\\s)`, "u"), contextualAfter = new RegExp(`(?:^|\\s)${escaped}\\s+(?:${contextLabels})(?:$|\\s)`, "u"), explicitRoleQuestion = /(?:^|\s)(?:האם|אם)(?:\s|$)/u.test(q) && /(?:^|\s)(?:שנה|עמוד|דף|כמות|מספר)(?:\s|$)/u.test(q);
  if (contextualBefore.test(q) || contextualAfter.test(q) || explicitRoleQuestion) return null;
  let exactNumber = q === literal, explicitNumberNoun = new RegExp(`(?:^|\\s)\u05D4\u05DE\u05E1\u05E4\u05E8\\s+${escaped}(?:$|\\s)`, "u").test(q), cuePrefix = q.slice(0, q.indexOf(literal)), researchCue = /(?:^|\s)(?:חקור|חקרי|תחקור|תחקירי|בדוק|בדקי|תבדוק|תבדקי|צלול|צללי|לצלול|העמק|העמיקי|תעמיק|תעמיקי|להעמיק)(?:\s|$)/u.test(cuePrefix), connectionCue = /(?:^|\s)(?:קשר|קשרים|הצלבה|הצלבות|השווה|השווי|תשווה|לחבר)(?:\s|$)/u.test(cuePrefix), explanationCue = /(?:^|\s)(?:מה|מהו|תן|תני|ספר|ספרי|הסבר|הסבירי|הראה|הראי|הצג|הציגי)(?:\s|$)/u.test(cuePrefix);
  if (!exactNumber && !explicitNumberNoun && !researchCue && !connectionCue && !explanationCue) return null;
  let requestedAction = connectionCue ? "connect" : researchCue ? "research" : "understand";
  return Object.freeze({
    type: "number",
    value,
    label: literal,
    evidence_text: literal,
    identity_key: `number:${value}`,
    source: RESEARCH_IDENTITY_SOURCE.NUMERIC_LITERAL,
    confidence: RESEARCH_IDENTITY_CONFIDENCE.EXACT,
    requested_action: requestedAction
  });
}

// src/lib/research/razielRouteGrammar.js
var RAZIEL_ROUTE_GRAMMAR_VERSION = "raziel-route-grammar-v1";
var ACTION_ORDER = Object.freeze([
  RAZIEL_ROUTE_ACTION.UNDERSTAND,
  RAZIEL_ROUTE_ACTION.RESEARCH,
  RAZIEL_ROUTE_ACTION.CONNECT,
  RAZIEL_ROUTE_ACTION.CONTINUE
]), ACTION_CONTRACT = Object.freeze({
  [RAZIEL_ROUTE_ACTION.UNDERSTAND]: Object.freeze({
    label: "\u05DC\u05D4\u05D1\u05D9\u05DF",
    human_question: "\u05DE\u05D4 \u05D0\u05E0\u05D9 \u05E8\u05D5\u05D0\u05D4 \u05DB\u05D0\u05DF?",
    task_mode: "explain_current_context",
    preferred_home: "current",
    experience_role: "human-first explanation before deeper action"
  }),
  [RAZIEL_ROUTE_ACTION.RESEARCH]: Object.freeze({
    label: "\u05DC\u05D7\u05E7\u05D5\u05E8",
    human_question: "\u05D0\u05D9\u05DA \u05D1\u05D5\u05D3\u05E7\u05D9\u05DD \u05D0\u05EA \u05D6\u05D4 \u05DC\u05E2\u05D5\u05DE\u05E7?",
    task_mode: "deepen_research",
    preferred_home: "heichal",
    experience_role: "verification / calculation / sources / tools"
  }),
  [RAZIEL_ROUTE_ACTION.CONNECT]: Object.freeze({
    label: "\u05DC\u05D7\u05D1\u05E8",
    human_question: "\u05DE\u05D4 \u05DE\u05EA\u05D7\u05D1\u05E8 \u05DC\u05D6\u05D4?",
    task_mode: "discover_connections",
    preferred_home: "world",
    experience_role: "typed contextual connections around the active subject"
  }),
  [RAZIEL_ROUTE_ACTION.CONTINUE]: Object.freeze({
    label: "\u05DC\u05D4\u05EA\u05E7\u05D3\u05DD",
    human_question: "\u05DC\u05D0\u05DF \u05D6\u05D4 \u05DE\u05D5\u05D1\u05D9\u05DC \u05DE\u05DB\u05D0\u05DF?",
    task_mode: "continue_path",
    preferred_home: "journey",
    experience_role: "path continuity / why-transition / next meaningful branch"
  })
});
function clean3(value) {
  return value == null ? "" : String(value).trim();
}
function lower(value) {
  return clean3(value).toLowerCase();
}
function includesAny(text, terms) {
  let q = lower(text);
  return terms.some((term) => {
    let t = lower(term);
    if (!t) return !1;
    let escaped = t.replace(/[.*+?^${}()|[\]\\]/g, (ch) => `\\${ch}`);
    return new RegExp(`(^|[^\\p{L}\\p{N}_])${escaped}($|[^\\p{L}\\p{N}_])`, "u").test(q);
  });
}
function normalizedSurface(surfaceContext) {
  if (typeof surfaceContext == "string") return lower(surfaceContext) || "system";
  let raw = surfaceContext?.surface ?? surfaceContext?.surface_key ?? surfaceContext?.surfaceKey ?? surfaceContext?.type ?? surfaceContext?.home ?? "system";
  return lower(raw) || "system";
}
function explicitRequestedAction({ question = "", intent = "" } = {}) {
  let q = lower(question), i = lower(intent), numericSubject = resolveExplicitNumericResearchSubject(question), expressionSubject = resolveExplicitHebrewExpressionResearchSubject(question);
  return includesAny(q, [
    "\u05DE\u05D4 \u05D4\u05E7\u05E9\u05E8",
    "\u05D5\u05DE\u05D4 \u05D4\u05E7\u05E9\u05E8",
    "\u05DE\u05D4 \u05D4\u05D4\u05D1\u05D3\u05DC",
    "\u05D5\u05DE\u05D4 \u05D4\u05D4\u05D1\u05D3\u05DC",
    "\u05DE\u05D4 \u05DE\u05EA\u05D7\u05D1\u05E8",
    "\u05EA\u05D7\u05D1\u05E8",
    "\u05DC\u05D7\u05D1\u05E8",
    "\u05D4\u05E9\u05D5\u05D5\u05D4",
    "\u05D4\u05E9\u05D5\u05D5\u05D9",
    "\u05EA\u05E9\u05D5\u05D5\u05D4",
    "\u05DC\u05D4\u05E9\u05D5\u05D5\u05EA",
    "\u05D4\u05E9\u05D5\u05D5\u05D0\u05D4",
    "compare",
    "cross",
    "\u05E7\u05E9\u05E8 \u05D1\u05D9\u05DF",
    "\u05E7\u05E9\u05E8\u05D9\u05DD \u05D1\u05D9\u05DF",
    "\u05D9\u05D7\u05E1 \u05D1\u05D9\u05DF",
    "\u05D4\u05E6\u05DC\u05D1\u05D4",
    "\u05D4\u05E6\u05DC\u05D1\u05D5\u05EA",
    "\u05D4\u05D4\u05E6\u05DC\u05D1\u05D4",
    "\u05D4\u05D4\u05E6\u05DC\u05D1\u05D5\u05EA",
    "\u05D4\u05E7\u05E9\u05E8\u05D9\u05DD",
    "\u05DE\u05E6\u05D0 \u05E7\u05E9\u05E8\u05D9\u05DD",
    "\u05DE\u05E6\u05D0 \u05DC\u05D9 \u05E7\u05E9\u05E8\u05D9\u05DD",
    "relation"
  ]) ? RAZIEL_ROUTE_ACTION.CONNECT : numericSubject?.requested_action === RAZIEL_ROUTE_ACTION.CONNECT ? RAZIEL_ROUTE_ACTION.CONNECT : expressionSubject?.requested_action === RAZIEL_ROUTE_ACTION.CONNECT ? RAZIEL_ROUTE_ACTION.CONNECT : includesAny(q, [
    "\u05EA\u05DE\u05E9\u05D9\u05DA",
    "\u05D4\u05DE\u05E9\u05DA \u05DE\u05D4\u05DE\u05E7\u05D5\u05DD",
    "\u05D4\u05DE\u05E9\u05DA \u05DE\u05D4\u05DE\u05E1\u05E2",
    "\u05DC\u05D4\u05DE\u05E9\u05D9\u05DA \u05DE\u05DB\u05D0\u05DF",
    "\u05E7\u05D7 \u05D0\u05D5\u05EA\u05D9 \u05DC\u05DE\u05E1\u05E2",
    "\u05E4\u05EA\u05D7 \u05DE\u05E1\u05E2",
    "\u05D4\u05EA\u05D7\u05DC \u05DE\u05E1\u05E2",
    "\u05E6\u05D0 \u05DC\u05DE\u05E1\u05E2",
    "\u05DC\u05D0\u05DF \u05D6\u05D4 \u05DE\u05D5\u05D1\u05D9\u05DC",
    "\u05DC\u05D0\u05DF \u05DE\u05DE\u05E9\u05D9\u05DB\u05D9\u05DD",
    "next step",
    "continue",
    "resume journey",
    "resume path"
  ]) ? RAZIEL_ROUTE_ACTION.CONTINUE : includesAny(q, [
    "\u05EA\u05D7\u05E7\u05D5\u05E8",
    "\u05EA\u05D7\u05E7\u05D9\u05E8\u05D9",
    "\u05D7\u05E7\u05D5\u05E8",
    "\u05D7\u05E7\u05E8\u05D9",
    "\u05DC\u05D7\u05E7\u05D5\u05E8",
    "\u05EA\u05D1\u05D3\u05D5\u05E7",
    "\u05EA\u05D1\u05D3\u05E7\u05D9",
    "\u05D1\u05D3\u05D5\u05E7",
    "\u05D1\u05D3\u05E7\u05D9",
    "\u05DC\u05D1\u05D3\u05D5\u05E7",
    "\u05EA\u05E2\u05DE\u05D9\u05E7",
    "\u05D4\u05E2\u05DE\u05E7",
    "\u05DC\u05D4\u05E2\u05DE\u05D9\u05E7",
    "\u05DC\u05E2\u05D5\u05DE\u05E7",
    "\u05D1\u05D3\u05D9\u05E7\u05D4 \u05E2\u05DE\u05D5\u05E7\u05D4",
    "\u05E6\u05DC\u05D5\u05DC",
    "\u05DC\u05E6\u05DC\u05D5\u05DC",
    "\u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D4",
    "\u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D0",
    "\u05D7\u05E4\u05E9 \u05DE\u05E7\u05D5\u05E8",
    "\u05DE\u05E7\u05D5\u05E8\u05D5\u05EA",
    "els",
    "\u05D3\u05D9\u05DC\u05D5\u05D2",
    "trace",
    "research",
    "deep research"
  ]) ? RAZIEL_ROUTE_ACTION.RESEARCH : numericSubject?.requested_action === RAZIEL_ROUTE_ACTION.RESEARCH ? RAZIEL_ROUTE_ACTION.RESEARCH : expressionSubject?.requested_action === RAZIEL_ROUTE_ACTION.RESEARCH ? RAZIEL_ROUTE_ACTION.RESEARCH : includesAny(q, [
    "\u05DE\u05D4 \u05D6\u05D4",
    "\u05DE\u05D4 \u05D0\u05E0\u05D9 \u05E8\u05D5\u05D0\u05D4",
    "\u05EA\u05E1\u05D1\u05D9\u05E8",
    "\u05D4\u05E1\u05D1\u05E8",
    "\u05DC\u05DE\u05D4",
    "\u05DE\u05D4 \u05D0\u05D5\u05DE\u05E8",
    "\u05DE\u05D4 \u05D4\u05DE\u05E9\u05DE\u05E2\u05D5\u05EA",
    "explain",
    "understand",
    "what is"
  ]) ? RAZIEL_ROUTE_ACTION.UNDERSTAND : numericSubject?.requested_action === RAZIEL_ROUTE_ACTION.UNDERSTAND ? RAZIEL_ROUTE_ACTION.UNDERSTAND : expressionSubject?.requested_action === RAZIEL_ROUTE_ACTION.UNDERSTAND ? RAZIEL_ROUTE_ACTION.UNDERSTAND : ["compare", "cross", "relation", "relations"].includes(i) ? RAZIEL_ROUTE_ACTION.CONNECT : ["continue", "journey", "resume", "next_step"].includes(i) ? RAZIEL_ROUTE_ACTION.CONTINUE : ["els", "gematria", "verify", "deep_research", "source_research"].includes(i) ? RAZIEL_ROUTE_ACTION.RESEARCH : ["explain", "understand", "guide"].includes(i) ? RAZIEL_ROUTE_ACTION.UNDERSTAND : null;
}
function defaultActionForSurface(surface) {
  switch (surface) {
    case "world":
      return RAZIEL_ROUTE_ACTION.CONNECT;
    case "journey":
      return RAZIEL_ROUTE_ACTION.CONTINUE;
    case "heichal":
    case "els":
    case "books":
    case "sources":
    case "inspect":
    case "trace":
      return RAZIEL_ROUTE_ACTION.RESEARCH;
    default:
      return RAZIEL_ROUTE_ACTION.UNDERSTAND;
  }
}
function subjectType(identityResolution, surfaceContext) {
  let primary = identityResolution?.primary || null;
  return clean3(primary?.type || surfaceContext?.subject?.type || surfaceContext?.target?.type) || null;
}
function actionHints(action, { surface, subject_type: type }) {
  let hints = [];
  return action === RAZIEL_ROUTE_ACTION.RESEARCH && hints.push("verification_first", "deep_capability_allowed"), action === RAZIEL_ROUTE_ACTION.CONNECT && hints.push("graph_context", "typed_relations", "bounded_connections"), action === RAZIEL_ROUTE_ACTION.CONTINUE && hints.push("preserve_context", "why_transition", "exact_return"), action === RAZIEL_ROUTE_ACTION.UNDERSTAND && hints.push("human_first", "bounded_explanation"), (type === "number" || type === "expression" || type === "phrase") && hints.push("numeric_subject"), (type === "name" || type === "person") && hints.push("name_or_person_subject"), type === "post" && hints.push("narrative_entry"), surface === "journey" && hints.push("active_path"), [...new Set(hints)];
}
function buildRazielRouteGrammar({
  question = "",
  intent = "",
  identityResolution = null,
  surfaceContext = null
} = {}) {
  let surface = normalizedSurface(surfaceContext), subject_type = subjectType(identityResolution, surfaceContext), explicit = explicitRequestedAction({ question, intent }), requested_action = explicit || defaultActionForSurface(surface), requested_by = explicit ? "user_language" : "surface_default", actions = ACTION_ORDER.map((id) => {
    let contract = ACTION_CONTRACT[id];
    return Object.freeze({
      id,
      label: contract.label,
      human_question: contract.human_question,
      task_mode: contract.task_mode,
      preferred_home: contract.preferred_home,
      experience_role: contract.experience_role,
      selected: id === requested_action,
      hints: Object.freeze(actionHints(id, { surface, subject_type }))
    });
  });
  return Object.freeze({
    version: RAZIEL_ROUTE_GRAMMAR_VERSION,
    owner: "research_strategy_layer_law v15 + experience_governance_foundation_v1_law v7",
    surface,
    subject_type,
    requested_action,
    requested_by,
    actions: Object.freeze(actions),
    guards: Object.freeze({
      semantic_hint_only: !0,
      no_navigation_execution: !0,
      no_tool_execution: !0,
      no_authorization_decision: !0,
      no_truth_ranking: !0,
      no_second_router: !0,
      one_context_required: !0
    })
  });
}

// src/lib/research/researchPlanV2.js
var RESEARCH_CAPABILITY = Object.freeze({
  GRAPH: "graph",
  NUMERIC: "numeric",
  GEMATRIA: "gematria",
  // Contract-only in V1: a validated public expression-crossing transport may request this
  // existing-corpus adapter. It is never inferred from free-form question text or added to the
  // general Quick/Deep/Research profiles.
  CROSSINGS: "crossings",
  // Contract-only in V0: this capability is never inferred from question text and is excluded from
  // the general Quick/Deep/Research profiles. A validated bounded transport must request it.
  GEMATRIA_RELATIONS: "gematria_relations",
  OPERATORS: "numeric_operators",
  RELATIONS: "numeric_relations",
  FIBONACCI_ZECKENDORF: "sequence:fibonacci:zeckendorf",
  ELS: "els",
  SOURCES: "sources",
  BOOKS: "books",
  PERSON: "person",
  FAMILY: "family",
  NAME: "name",
  TIME: "time",
  RESEARCH_OBJECTS: "research_objects"
});
function clean4(value) {
  return value == null ? "" : String(value).trim();
}
function normalizedIntent(intent) {
  return clean4(intent).toLowerCase() || "research";
}
function uniq(values) {
  return [...new Set(values.filter(Boolean))];
}
function includesAny2(text, terms) {
  let q = clean4(text).toLowerCase();
  return terms.some((term) => q.includes(term));
}
function countIdentityKind(identityResolution, kind) {
  return (identityResolution?.identities || []).filter((identity) => identity?.type === kind).length;
}
function containsClockMoment(text) {
  return /(^|\D)(?:[01]?\d|2[0-3]):[0-5]\d(?:\D|$)/.test(clean4(text));
}
function inferExplicitCapabilityHints({ question, intent, identityResolution, requestedCapabilities = [] }) {
  let hints = [...requestedCapabilities], q = clean4(question), i = normalizedIntent(intent);
  if ((i === "els" || includesAny2(q, ["\u05D3\u05D9\u05DC\u05D5\u05D2", "\u05D3\u05D9\u05DC\u05D5\u05D2\u05D9\u05DD", "els", "\u05E6\u05D5\u05E4\u05DF \u05D0\u05D5\u05EA\u05D9\u05D5\u05EA"])) && hints.push(RESEARCH_CAPABILITY.ELS), (i === "gematria" || includesAny2(q, ["\u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D4", "\u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D0", "\u05D7\u05E9\u05D1 \u05D0\u05EA", "\u05DB\u05DE\u05D4 \u05E9\u05D5\u05D5\u05D4"])) && hints.push(RESEARCH_CAPABILITY.GEMATRIA), includesAny2(q, ["\u05DE\u05E7\u05D5\u05E8", "\u05DE\u05E7\u05D5\u05E8\u05D5\u05EA", "\u05E1\u05E4\u05E8", "\u05E2\u05DE\u05D5\u05D3", "\u05DB\u05EA\u05D1 \u05D9\u05D3", "\u05E2\u05D3 \u05E0\u05D5\u05E1\u05D7"]) && hints.push(RESEARCH_CAPABILITY.SOURCES), includesAny2(q, ["\u05DE\u05E9\u05E4\u05D7\u05D4", "\u05D0\u05D1\u05D0", "\u05D0\u05DE\u05D0", "\u05D1\u05DF \u05E9\u05DC\u05D9", "\u05D1\u05EA \u05E9\u05DC\u05D9", "\u05D9\u05DC\u05D3", "\u05D4\u05D5\u05E8\u05D4"]) && hints.push(RESEARCH_CAPABILITY.FAMILY), (containsClockMoment(q) || includesAny2(q, ["\u05E9\u05E2\u05D4", "\u05D1\u05E9\u05E2\u05D4", "\u05E8\u05D2\u05E2", "\u05E9\u05E2\u05D5\u05DF"])) && hints.push(RESEARCH_CAPABILITY.TIME, RESEARCH_CAPABILITY.OPERATORS), hasIdentityKind(identityResolution, "book") && hints.push(RESEARCH_CAPABILITY.BOOKS, RESEARCH_CAPABILITY.SOURCES, RESEARCH_CAPABILITY.GRAPH), hasIdentityKind(identityResolution, "number")) {
    hints.push(RESEARCH_CAPABILITY.NUMERIC, RESEARCH_CAPABILITY.OPERATORS, RESEARCH_CAPABILITY.GRAPH);
    let multiNumber = countIdentityKind(identityResolution, "number") >= 2, relationIntent = includesAny2(q, [
      "\u05E7\u05E9\u05E8",
      "\u05E7\u05E9\u05E8\u05D9\u05DD",
      "\u05D9\u05D7\u05E1",
      "\u05D9\u05D7\u05E1\u05D9\u05DD",
      "\u05E1\u05D3\u05E8\u05D4",
      "\u05D3\u05E4\u05D5\u05E1",
      "\u05D4\u05E4\u05E8\u05E9",
      "\u05D0\u05DE\u05E6\u05E2",
      "\u05D2\u05D5\u05E8\u05DD \u05DE\u05E9\u05D5\u05EA\u05E3",
      "\u05E4\u05D9\u05EA\u05D2\u05D5\u05E8\u05E1",
      "\u05E4\u05D5\u05DC\u05D9\u05E0\u05D5\u05DD"
    ]);
    (multiNumber || relationIntent) && hints.push(RESEARCH_CAPABILITY.RELATIONS), includesAny2(q, ["zeckendorf", "\u05D6\u05E7\u05E0\u05D3\u05D5\u05E8\u05E3", "\u05E4\u05D9\u05E8\u05D5\u05E7 \u05E4\u05D9\u05D1\u05D5\u05E0\u05D0\u05E6\u05D9", "\u05E4\u05D9\u05E8\u05D5\u05E7 \u05E4\u05D9\u05D1\u05D5\u05E0\u05D0\u05E6\u05F3\u05D9", "\u05E4\u05D9\u05E8\u05D5\u05E7 \u05E4\u05D9\u05D1\u05D5\u05E0\u05D0\u05E6\u05D9"]) && hints.push(RESEARCH_CAPABILITY.FIBONACCI_ZECKENDORF);
  }
  return hasIdentityKind(identityResolution, "person") && hints.push(RESEARCH_CAPABILITY.PERSON, RESEARCH_CAPABILITY.GRAPH), hasIdentityKind(identityResolution, "name") && hints.push(RESEARCH_CAPABILITY.NAME), hasIdentityKind(identityResolution, "event") && hints.push(RESEARCH_CAPABILITY.TIME, RESEARCH_CAPABILITY.SOURCES, RESEARCH_CAPABILITY.GRAPH), hasIdentityKind(identityResolution, "topic") && hints.push(RESEARCH_CAPABILITY.GRAPH, RESEARCH_CAPABILITY.RESEARCH_OBJECTS), identityResolution?.explicit_text_computation === !0 && hints.push(RESEARCH_CAPABILITY.GEMATRIA), uniq(hints);
}
function deriveStrategy({ identityResolution, capabilityHints }) {
  let kinds = identityKinds(identityResolution);
  return kinds.includes("person") ? capabilityHints.includes(RESEARCH_CAPABILITY.FAMILY) ? "personal_family_research" : "personal_research" : kinds.includes("book") ? kinds.includes("number") ? "cross_identity_research" : "source_research" : capabilityHints.includes(RESEARCH_CAPABILITY.GEMATRIA_RELATIONS) ? "gematria_relation_research" : capabilityHints.includes(RESEARCH_CAPABILITY.CROSSINGS) ? "gematria_crossing_research" : capabilityHints.includes(RESEARCH_CAPABILITY.ELS) ? "els_research" : kinds.includes("event") || kinds.includes("topic") ? "reality_research" : kinds.includes("number") ? "number_research" : kinds.includes("name") ? "name_research" : "discovery";
}
function deriveCheckOrder(capabilityHints) {
  return [
    RESEARCH_CAPABILITY.PERSON,
    RESEARCH_CAPABILITY.FAMILY,
    RESEARCH_CAPABILITY.TIME,
    RESEARCH_CAPABILITY.BOOKS,
    RESEARCH_CAPABILITY.SOURCES,
    RESEARCH_CAPABILITY.GRAPH,
    RESEARCH_CAPABILITY.NUMERIC,
    RESEARCH_CAPABILITY.OPERATORS,
    RESEARCH_CAPABILITY.RELATIONS,
    RESEARCH_CAPABILITY.FIBONACCI_ZECKENDORF,
    RESEARCH_CAPABILITY.GEMATRIA,
    RESEARCH_CAPABILITY.CROSSINGS,
    RESEARCH_CAPABILITY.GEMATRIA_RELATIONS,
    RESEARCH_CAPABILITY.NAME,
    RESEARCH_CAPABILITY.ELS,
    RESEARCH_CAPABILITY.RESEARCH_OBJECTS
  ].filter((x) => capabilityHints.includes(x));
}
var ACCESS_TIER = Object.freeze({
  PUBLIC: "public",
  PUBLIC_CANDIDATE: "public_candidate",
  PRIVATE: "private",
  PERSONAL: "personal"
}), PUBLIC_ONLY_TIERS = Object.freeze([ACCESS_TIER.PUBLIC]), VALID_ACCESS_TIERS = new Set(Object.values(ACCESS_TIER)), VERIFIED_AUTHORITY_SOURCE = Object.freeze({
  SUPABASE_AUTH: "supabase_auth",
  // resolved from a verified JWT / auth.uid()
  SERVICE_ROLE: "service_role",
  // a server path that already authenticated the subject
  ADMIN_RPC: "admin_rpc"
  // an admin-gated RPC that performed its own auth.uid() check
}), VALID_AUTHORITY_SOURCES = new Set(Object.values(VERIFIED_AUTHORITY_SOURCE));
function truthy(value) {
  return value === !0 || value === "true" || value === 1;
}
function readVerifiedAuthority(ctx) {
  let raw = ctx?.verified_authority ?? ctx?.verifiedAuthority;
  if (!raw || typeof raw != "object" || Array.isArray(raw)) return null;
  let source = clean4(raw.source).toLowerCase();
  return VALID_AUTHORITY_SOURCES.has(source) ? {
    source,
    admin: truthy(raw.admin),
    subjectVerified: truthy(raw.subject_verified ?? raw.subjectVerified)
  } : null;
}
function hasUnattestedAuthorityClaims(ctx) {
  return ctx ? truthy(ctx.admin) || truthy(ctx.is_admin) || clean4(ctx.role).toLowerCase() === "admin" || truthy(ctx.authenticated) || truthy(ctx.is_authenticated) : !1;
}
function buildAccessDescriptor(authorizationContext = null, contextType = "public_user") {
  let ctx = authorizationContext && typeof authorizationContext == "object" ? authorizationContext : null, context = clean4(contextType).toLowerCase() || "public_user", authority = readVerifiedAuthority(ctx), authenticated = !!(authority?.subjectVerified || authority?.admin), admin = !!authority?.admin, personalScopeAvailable = !!authority?.subjectVerified, tiers = new Set(PUBLIC_ONLY_TIERS);
  admin ? (tiers.add(ACCESS_TIER.PUBLIC_CANDIDATE), tiers.add(ACCESS_TIER.PRIVATE), tiers.add(ACCESS_TIER.PERSONAL)) : personalScopeAvailable && tiers.add(ACCESS_TIER.PERSONAL);
  let descriptor = {
    v: 1,
    context_type: context,
    authenticated,
    admin,
    personal_scope_available: personalScopeAvailable,
    allowed_access_tiers: [...tiers],
    entitlement_level: clean4(ctx?.entitlement_level ?? ctx?.entitlementLevel ?? ctx?.tier) || null,
    // Provenance of the authority itself, so a reader can see WHY these tiers were granted.
    authority_source: authority?.source || null,
    // Visible refusal: the context asserted authority but produced no attestation to back it.
    unverified_authority_claims_ignored: !!(!authority && hasUnattestedAuthorityClaims(ctx)),
    // Explicit statement that this object is the OUTPUT-SAFE projection, so a later reader can never
    // mistake it for the private execution context.
    contains_identifying_fields: !1,
    derived_from: ctx ? "authorization_context" : "no_authorization_context"
  };
  return Object.freeze(descriptor.allowed_access_tiers), Object.freeze(descriptor);
}
function normalizeAccessDescriptor(descriptor) {
  if (!descriptor || typeof descriptor != "object" || Array.isArray(descriptor))
    return buildAccessDescriptor(null, "public_user");
  let authoritySource = VALID_AUTHORITY_SOURCES.has(clean4(descriptor.authority_source)) ? clean4(descriptor.authority_source) : null, tiers = new Set(PUBLIC_ONLY_TIERS);
  if (authoritySource)
    for (let tier of Array.isArray(descriptor.allowed_access_tiers) ? descriptor.allowed_access_tiers : []) {
      let value = clean4(tier);
      value && VALID_ACCESS_TIERS.has(value) && tiers.add(value);
    }
  let out = {
    v: 1,
    context_type: clean4(descriptor.context_type) || "public_user",
    authenticated: !!authoritySource && descriptor.authenticated === !0,
    admin: !!authoritySource && descriptor.admin === !0,
    personal_scope_available: !!authoritySource && descriptor.personal_scope_available === !0,
    allowed_access_tiers: [...tiers],
    entitlement_level: clean4(descriptor.entitlement_level),
    authority_source: authoritySource,
    unverified_authority_claims_ignored: descriptor.unverified_authority_claims_ignored === !0 || !authoritySource && Array.isArray(descriptor.allowed_access_tiers) && descriptor.allowed_access_tiers.some((t) => clean4(t) && clean4(t) !== ACCESS_TIER.PUBLIC),
    contains_identifying_fields: !1,
    derived_from: clean4(descriptor.derived_from) || "normalized_descriptor"
  };
  return Object.freeze(out.allowed_access_tiers), Object.freeze(out);
}
function buildResearchPlanV2({
  question = "",
  intent = "research",
  identityResolution,
  authorizationContext = null,
  contextType = "public_user",
  surfaceContext = null,
  requestedCapabilities = [],
  // OPTIONAL filtering seam over the INFERRED capability hints only. It never widens anything the
  // inference step did not already hint at, and it is applied BEFORE strategy/check_order/
  // requested_capabilities are finalized. When omitted (null), behavior is unchanged from before this
  // seam existed. `route_grammar` below always reasons over the ORIGINAL `question`, never the
  // filtered hint set — allowlisting execution must never rewrite what the user actually asked.
  capabilityAllowlist = null,
  requestedDepth = null
} = {}) {
  let resolved = identityResolution || { identities: [], text_calculation_allowed: !0 }, inferredCapabilityHints = inferExplicitCapabilityHints({
    question,
    intent,
    identityResolution: resolved,
    requestedCapabilities
  }), capabilityAllowset = Array.isArray(capabilityAllowlist) ? new Set(capabilityAllowlist.map(clean4).filter(Boolean)) : null, capabilityHints = capabilityAllowset ? inferredCapabilityHints.filter((capability) => capabilityAllowset.has(capability)) : inferredCapabilityHints, strategy = deriveStrategy({ identityResolution: resolved, capabilityHints }), checkOrder = deriveCheckOrder(capabilityHints), routeGrammar = buildRazielRouteGrammar({
    question,
    intent,
    identityResolution: resolved,
    surfaceContext
  });
  return {
    v: 2,
    strategy,
    question: clean4(question),
    intent: normalizedIntent(intent),
    identities: resolved.identities || [],
    primary_identity: resolved.primary || null,
    context_type: contextType,
    // W2.2b: output-safe access descriptor ONLY. The raw authorization context never lands here.
    access: buildAccessDescriptor(authorizationContext, contextType),
    surface_context: surfaceContext,
    route_grammar: routeGrammar,
    requested_depth: requestedDepth,
    requested_capabilities: capabilityHints,
    capability_allowlist: capabilityAllowset ? [...capabilityAllowset] : null,
    check_order: checkOrder,
    guards: {
      identity_first: !0,
      semantic_identity_precedes_text_calculation: !0,
      text_calculation_allowed: resolved.text_calculation_allowed !== !1,
      access_must_be_resolved_before_evidence: !0,
      canonical_owners_decide_execution: !0,
      no_auto_canonicalization: !0,
      no_auto_publication: !0,
      raw_authorization_context_never_in_output: !0,
      route_grammar_is_semantic_hint_only: !0,
      capability_allowlist_applied_before_strategy: capabilityAllowset !== null
    }
  };
}

// src/lib/research/researchRepresentations.js
var HEBREW_UNIT_DIGITS = Object.freeze(["\u05D0", "\u05D1", "\u05D2", "\u05D3", "\u05D4", "\u05D5", "\u05D6", "\u05D7", "\u05D8"]);
function clean5(value) {
  return value == null ? null : String(value).trim() || null;
}
function identityKey(identity, index) {
  return clean5(identity?.key) || clean5(identity?.identity_key) || clean5(identity?.ref) || clean5(identity?.id) || `identity:${index}`;
}
function stableIdentityDigest(value) {
  let hash = 2166136261;
  for (let ch of String(value))
    hash ^= ch.codePointAt(0), hash = Math.imul(hash, 16777619) >>> 0;
  return hash.toString(36).padStart(7, "0");
}
function refKeyFor(parentKey, accessTier) {
  return accessTier === "public" ? parentKey : `anon:${stableIdentityDigest(parentKey)}`;
}
function wordsOf(text) {
  return clean5(text)?.split(/\s+/u).map(clean5).filter(Boolean) || [];
}
function roleParts(identity) {
  let meta = identity?.metadata && typeof identity.metadata == "object" ? identity.metadata : {}, explicit = [];
  if (Array.isArray(meta.name_parts)) {
    for (let raw of meta.name_parts)
      if (typeof raw == "string") {
        let text = clean5(raw);
        text && explicit.push({ text, role: null, role_source: "source_unspecified" });
      } else if (raw && typeof raw == "object") {
        let text = clean5(raw.text ?? raw.value ?? raw.label);
        text && explicit.push({ text, role: clean5(raw.role), role_source: clean5(raw.role) ? "source_declared" : "source_unspecified" });
      }
  }
  let declared = [
    ["given_name", meta.given_name ?? meta.givenName],
    ["middle_name", meta.middle_name ?? meta.middleName],
    ["family_name", meta.family_name ?? meta.familyName ?? meta.surname]
  ];
  for (let [role, raw] of declared) {
    let text = clean5(raw);
    text && !explicit.some((x) => x.text === text && x.role === role) && explicit.push({ text, role, role_source: "source_declared" });
  }
  if (Array.isArray(meta.middle_names ?? meta.middleNames))
    for (let raw of meta.middle_names ?? meta.middleNames) {
      let text = clean5(raw);
      text && !explicit.some((x) => x.text === text) && explicit.push({ text, role: "middle_name", role_source: "source_declared" });
    }
  return explicit;
}
function representationAccess(identity) {
  return clean5(identity?.access?.tier) || "public";
}
function addRepresentation(out, seen, rep, max) {
  if (out.length >= max) return;
  let text = clean5(rep.text);
  if (!text) return;
  let key = `${rep.parent_identity_key}|${rep.kind}|${rep.role || ""}|${text}`;
  seen.has(key) || (seen.add(key), out.push(Object.freeze({ ...rep, text })));
}
function expandResearchTextRepresentations(identityResolution, { maxRepresentations = 16 } = {}) {
  let max = Math.max(1, Math.min(Number(maxRepresentations) || 16, 32)), out = [], seen = /* @__PURE__ */ new Set(), identities = Array.isArray(identityResolution?.identities) ? identityResolution.identities : [], textAllowed = identityResolution?.text_calculation_allowed !== !1;
  return identities.forEach((identity, index) => {
    let type = clean5(identity?.type) || "entity", parentKey = identityKey(identity, index), accessTier = representationAccess(identity), refKey = refKeyFor(parentKey, accessTier), label = clean5(identity?.label ?? identity?.value), isNativeText = type === "phrase" || type === "word", isNameLike = type === "name" || type === "person";
    if (!label || !isNativeText && !(isNameLike && textAllowed)) return;
    let fullKind = type === "word" ? "word" : isNameLike ? "full_name" : "phrase";
    addRepresentation(out, seen, {
      ref: `repr:${refKey}:full`,
      parent_identity_key: refKey,
      parent_identity_type: type,
      kind: fullKind,
      role: isNameLike ? "full_name" : null,
      role_source: isNameLike ? "representation" : null,
      text: label,
      token_index: null,
      component_refs: [],
      access_tier: accessTier,
      primary_for_identity: !0
    }, max);
    let explicitParts = isNameLike ? roleParts(identity) : [];
    if (explicitParts.length) {
      explicitParts.forEach((part, partIndex) => {
        explicitParts.length === 1 && part.text === label || addRepresentation(out, seen, {
          ref: `repr:${refKey}:part:${partIndex + 1}`,
          parent_identity_key: refKey,
          parent_identity_type: type,
          kind: "name_part",
          role: part.role || `word_${partIndex + 1}`,
          role_source: part.role_source,
          text: part.text,
          token_index: partIndex,
          component_refs: [],
          access_tier: accessTier,
          primary_for_identity: !1
        }, max);
      });
      let given = explicitParts.filter((x) => x.role === "given_name").map((x) => x.text), family = explicitParts.filter((x) => x.role === "family_name").map((x) => x.text);
      if (given.length && family.length) {
        let combined = `${given.join(" ")} ${family.join(" ")}`;
        combined !== label && addRepresentation(out, seen, {
          ref: `repr:${refKey}:given-family`,
          parent_identity_key: refKey,
          parent_identity_type: type,
          kind: "name_combination",
          role: "given_family",
          role_source: "source_declared_roles",
          text: combined,
          token_index: null,
          component_refs: ["given_name", "family_name"],
          access_tier: accessTier,
          primary_for_identity: !1
        }, max);
      }
    } else {
      let words = wordsOf(label);
      words.length > 1 && words.forEach((word, tokenIndex) => {
        addRepresentation(out, seen, {
          ref: `repr:${refKey}:word:${tokenIndex + 1}`,
          parent_identity_key: refKey,
          parent_identity_type: type,
          kind: isNameLike ? "name_part" : "word_part",
          role: `word_${tokenIndex + 1}`,
          role_source: "whitespace_position_only",
          text: word,
          token_index: tokenIndex,
          component_refs: [],
          access_tier: accessTier,
          primary_for_identity: !1
        }, max);
      });
    }
  }), Object.freeze(out);
}

// src/lib/research/researchIntakeTransport.js
var RESTRICTED_TIERS = /* @__PURE__ */ new Set([
  "private",
  "public_candidate",
  "personal",
  "user_private",
  "draft",
  "internal",
  "pending"
]);
function clean6(value) {
  return value == null ? null : String(value).trim() || null;
}
function valueOf(raw) {
  return raw == null ? null : typeof raw == "object" && !Array.isArray(raw) ? raw.value ?? raw.text ?? raw.content ?? null : raw;
}
function freezeDeep(value) {
  if (!value || typeof value != "object" || Object.isFrozen(value)) return value;
  for (let item of Object.values(value)) freezeDeep(item);
  return Object.freeze(value);
}
function normalizeTier(value, fallback = "unclassified") {
  return clean6(value?.access?.tier ?? value?.access_tier ?? value?.accessTier ?? fallback) || "unclassified";
}
function accessOf(value, fallback) {
  return { tier: normalizeTier(value, fallback) };
}
function generatedRef(prefix, seed) {
  return `${prefix}:${stableIdentityDigest(seed || prefix)}`;
}
function normalizeRef(value, prefix, seed) {
  return clean6(value?.ref ?? value?.id ?? value?.source_ref ?? value?.sourceRef) || generatedRef(prefix, seed);
}
function normalizeFingerprint(value) {
  if (!value) return null;
  if (typeof value == "string")
    return { algorithm: "unspecified", value, strength: "candidate" };
  if (typeof value != "object" || Array.isArray(value)) return null;
  let fingerprint = clean6(value.value ?? value.hash ?? value.digest);
  return fingerprint ? {
    algorithm: clean6(value.algorithm ?? value.kind) || "unspecified",
    value: fingerprint,
    strength: clean6(value.strength) || "candidate"
  } : null;
}
function dedupeDescriptor(fingerprint) {
  if (!fingerprint) return {
    artifact_dedupe_ref: null,
    candidate_ref: null,
    strength: null
  };
  let seed = `${fingerprint.algorithm}:${fingerprint.value}`, strength = fingerprint.strength, strong = ["strong", "exact", "binary"].includes(strength);
  return {
    artifact_dedupe_ref: strong ? generatedRef("artifact", seed) : null,
    candidate_ref: strong ? null : generatedRef("artifact-candidate", seed),
    strength
  };
}
function normalizeArtifact(value, fallbackTier) {
  if (!value || typeof value != "object" || Array.isArray(value)) return null;
  let fingerprint = normalizeFingerprint(value.fingerprint ?? value.hash), dedupe = dedupeDescriptor(fingerprint), kind = clean6(value.kind ?? value.type) || "artifact", occurrenceRef = normalizeRef(
    value,
    "artifact-occurrence",
    `${kind}:${clean6(value.name) || ""}:${clean6(value.source_ref ?? value.sourceRef) || ""}:${fingerprint?.value || ""}`
  );
  return {
    ref: occurrenceRef,
    occurrence_ref: occurrenceRef,
    artifact_dedupe_ref: dedupe.artifact_dedupe_ref,
    dedupe_candidate_ref: dedupe.candidate_ref,
    dedupe_strength: dedupe.strength,
    kind,
    media_type: clean6(value.media_type ?? value.mediaType ?? value.mime_type ?? value.mimeType),
    source_ref: clean6(value.source_ref ?? value.sourceRef),
    locator: value.locator ?? null,
    availability: clean6(value.availability) || "available",
    replayable: value.replayable !== !1,
    access: accessOf(value, fallbackTier),
    fingerprint
  };
}
function normalizeExtraction(value, index, artifactRef, fallbackTier) {
  if (!value || typeof value != "object" || Array.isArray(value)) return null;
  let kind = clean6(value.kind ?? value.type) || "extraction", content = valueOf(value);
  return {
    ref: normalizeRef(
      value,
      "extraction",
      `${artifactRef || "no-artifact"}:${kind}:${index}:${content == null ? "" : String(content)}`
    ),
    kind,
    content,
    status: clean6(value.status) || "complete",
    source_artifact_ref: clean6(value.source_artifact_ref ?? value.sourceArtifactRef) || artifactRef || null,
    locator: value.locator ?? null,
    method_ref: clean6(value.method_ref ?? value.methodRef),
    version_ref: clean6(value.version_ref ?? value.versionRef),
    confidence: value.confidence ?? null,
    access: accessOf(value, fallbackTier)
  };
}
function normalizeRepresentation(value, index, artifactRef, fallbackTier) {
  if (!value || typeof value != "object" || Array.isArray(value)) return null;
  let kind = clean6(value.kind ?? value.type) || "representation", content = valueOf(value), ref = normalizeRef(
    value,
    "repr",
    `${artifactRef || "no-artifact"}:${kind}:${index}:${content == null ? "" : String(content)}`
  ), derived = value.derived_from_refs ?? value.derivedFromRefs ?? value.component_refs ?? [];
  return {
    ref,
    kind,
    content,
    extraction_ref: clean6(value.extraction_ref ?? value.extractionRef),
    source_artifact_ref: clean6(value.source_artifact_ref ?? value.sourceArtifactRef) || artifactRef || null,
    derived_from_refs: [...new Set((Array.isArray(derived) ? derived : []).map(clean6).filter(Boolean))],
    role: clean6(value.role),
    language: clean6(value.language),
    script: clean6(value.script),
    access: accessOf(value, fallbackTier)
  };
}
function normalizeInterpretation(value, index, artifactRef, fallbackTier) {
  if (!value || typeof value != "object" || Array.isArray(value)) return null;
  let content = valueOf(value);
  return {
    ref: normalizeRef(
      value,
      "interpretation",
      `${artifactRef || "no-artifact"}:${index}:${content == null ? "" : String(content)}`
    ),
    kind: clean6(value.kind ?? value.type) || "user_interpretation",
    content,
    source_artifact_ref: clean6(value.source_artifact_ref ?? value.sourceArtifactRef) || artifactRef || null,
    derived_from_refs: [...new Set((Array.isArray(value.derived_from_refs ?? value.derivedFromRefs) ? value.derived_from_refs ?? value.derivedFromRefs : []).map(clean6).filter(Boolean))],
    access: accessOf(value, fallbackTier)
  };
}
function normalizeTemporal(value, fallbackTier) {
  return !value || typeof value != "object" || Array.isArray(value) ? null : {
    occurred_at: value.occurred_at ?? value.occurredAt ?? null,
    source_time: value.source_time ?? value.sourceTime ?? null,
    input_time: value.input_time ?? value.inputTime ?? null,
    timezone: clean6(value.timezone),
    uncertainty: value.uncertainty ?? null,
    provenance: value.provenance ?? null,
    access: accessOf(value, fallbackTier)
  };
}
function normalizeOrigin(value) {
  return !value || typeof value != "object" || Array.isArray(value) ? null : {
    channel: clean6(value.channel),
    surface: clean6(value.surface),
    source_ref: clean6(value.source_ref ?? value.sourceRef),
    message_ref: clean6(value.message_ref ?? value.messageRef),
    external_url: clean6(value.external_url ?? value.externalUrl)
  };
}
function normalizePersistence(value) {
  return !value || typeof value != "object" || Array.isArray(value) ? { mode: "ephemeral", persisted_ref: null } : {
    mode: clean6(value.mode) || "ephemeral",
    persisted_ref: clean6(value.persisted_ref ?? value.persistedRef)
  };
}
function normalizeIdentityCandidates(values, fallbackTier) {
  return (Array.isArray(values) ? values : []).filter((x) => x && typeof x == "object" && !Array.isArray(x)).map((x) => ({
    ...x,
    access: x.access ?? { tier: normalizeTier(x, fallbackTier) }
  }));
}
function isResearchIntakeTransport(value) {
  return !!(value && typeof value == "object" && value.transport === "research_intake" && value.v === 1);
}
function buildResearchIntakeTransport({
  rawInput = null,
  rawKind = "text",
  rawRef = null,
  sourceArtifact = null,
  extractions = [],
  representations = [],
  identityCandidates = [],
  userInterpretations = [],
  temporal = null,
  origin = null,
  persistence = null,
  accessTier = null
} = {}) {
  if (isResearchIntakeTransport(rawInput)) return rawInput;
  let rawSpec = rawInput && typeof rawInput == "object" && !Array.isArray(rawInput) ? rawInput : { value: rawInput, kind: rawKind, ref: rawRef }, explicitTier = clean6(
    rawSpec?.access?.tier ?? rawSpec?.access_tier ?? rawSpec?.accessTier ?? accessTier ?? sourceArtifact?.access?.tier ?? sourceArtifact?.access_tier ?? sourceArtifact?.accessTier
  ) || "unclassified", artifact = normalizeArtifact(sourceArtifact, explicitTier), artifactRef = artifact?.ref || null, rawValue = valueOf(rawSpec), raw = rawValue == null ? null : {
    ref: clean6(rawSpec?.ref ?? rawSpec?.id ?? rawRef) || generatedRef("input", `${clean6(rawSpec?.kind ?? rawKind) || "text"}:${String(rawValue)}`),
    kind: clean6(rawSpec?.kind ?? rawKind) || "text",
    value: String(rawValue),
    source_artifact_ref: artifactRef,
    access: accessOf(rawSpec, explicitTier)
  }, normalizedExtractions = (Array.isArray(extractions) ? extractions : []).map((x, index) => normalizeExtraction(x, index, artifactRef, explicitTier)).filter(Boolean), normalizedRepresentations = (Array.isArray(representations) ? representations : []).map((x, index) => normalizeRepresentation(x, index, artifactRef, explicitTier)).filter(Boolean), normalizedInterpretations = (Array.isArray(userInterpretations) ? userInterpretations : []).map((x, index) => normalizeInterpretation(x, index, artifactRef, explicitTier)).filter(Boolean);
  return freezeDeep({
    v: 1,
    transport: "research_intake",
    owns_persistence: !1,
    owns_truth: !1,
    owns_identity: !1,
    owns_capability_routing: !1,
    root_access_tier: explicitTier,
    raw_input: raw,
    source_artifact: artifact,
    extractions: normalizedExtractions,
    representations: normalizedRepresentations,
    identity_candidates: normalizeIdentityCandidates(identityCandidates, explicitTier),
    user_interpretations: normalizedInterpretations,
    temporal: normalizeTemporal(temporal, explicitTier),
    origin: normalizeOrigin(origin),
    persistence: normalizePersistence(persistence)
  });
}
function ensureResearchIntakeTransport(value) {
  return value ? isResearchIntakeTransport(value) ? value : buildResearchIntakeTransport(value) : null;
}
function allowedTiers(accessDescriptor) {
  return new Set(normalizeAccessDescriptor(accessDescriptor).allowed_access_tiers || ["public"]);
}
function tierDecision(tier, accessDescriptor) {
  let normalized = clean6(tier) || "unclassified", allowed = allowedTiers(accessDescriptor);
  return normalized === "public" ? { allowed: !0, tier: normalized, reason: null } : normalized === "unclassified" ? { allowed: !1, tier: normalized, reason: "intake_access_unclassified" } : RESTRICTED_TIERS.has(normalized) ? allowed.has(normalized) ? { allowed: !0, tier: normalized, reason: null } : { allowed: !1, tier: normalized, reason: `intake_access_tier_not_permitted:${normalized}` } : { allowed: !1, tier: normalized, reason: `intake_access_unknown_tier:${normalized}` };
}
function researchIntakeAccessDecision(intake, accessDescriptor) {
  let transport = ensureResearchIntakeTransport(intake);
  if (!transport) return { allowed: !0, reasons: [], denied_refs: [] };
  let checks = [], add = (ref, access) => {
    ref && checks.push({ ref, ...tierDecision(access?.tier, accessDescriptor) });
  };
  add(transport.raw_input?.ref, transport.raw_input?.access), add(transport.source_artifact?.ref, transport.source_artifact?.access);
  for (let item of transport.extractions || []) add(item.ref, item.access);
  for (let item of transport.representations || []) add(item.ref, item.access);
  for (let item of transport.user_interpretations || []) add(item.ref, item.access);
  for (let [index, item] of (transport.identity_candidates || []).entries())
    add(
      clean6(item?.ref ?? item?.identity_key ?? item?.identityKey ?? item?.id) || `identity-candidate:${index}`,
      item?.access
    );
  transport.temporal && add("temporal", transport.temporal.access);
  let denied = checks.filter((x) => !x.allowed);
  return {
    allowed: denied.length === 0,
    reasons: [...new Set(denied.map((x) => x.reason).filter(Boolean))],
    denied_refs: denied.map((x) => x.ref)
  };
}
function safeRef(ref, access, accessDescriptor) {
  let value = clean6(ref);
  return value ? tierDecision(access?.tier, accessDescriptor).allowed ? value : `anon:${stableIdentityDigest(value)}` : null;
}
function projectItem(item, accessDescriptor, fields = [], safeWhenRedacted = []) {
  if (!item) return null;
  let decision = tierDecision(item.access?.tier, accessDescriptor), safeFields = new Set(safeWhenRedacted), out = {
    ref: safeRef(item.ref, item.access, accessDescriptor),
    kind: item.kind ?? null,
    access_tier: item.access?.tier ?? "unclassified",
    redacted: !decision.allowed
  };
  for (let field of fields)
    field in item && (field.endsWith("_ref") ? out[field] = safeRef(item[field], item.access, accessDescriptor) : (decision.allowed || safeFields.has(field)) && (out[field] = item[field]));
  return out;
}
function projectResearchIntakeLineage(intake, accessDescriptor) {
  let transport = ensureResearchIntakeTransport(intake);
  if (!transport) return null;
  let decision = researchIntakeAccessDecision(transport, accessDescriptor), artifact = transport.source_artifact, artifactDecision = artifact ? tierDecision(artifact.access?.tier, accessDescriptor) : null;
  return {
    v: 1,
    transport: "research_intake",
    access_allowed_for_execution: decision.allowed,
    access_reasons: decision.reasons,
    raw_input: transport.raw_input ? {
      ref: safeRef(transport.raw_input.ref, transport.raw_input.access, accessDescriptor),
      kind: transport.raw_input.kind,
      access_tier: transport.raw_input.access?.tier ?? "unclassified",
      redacted: !tierDecision(transport.raw_input.access?.tier, accessDescriptor).allowed
    } : null,
    source_artifact: artifact ? {
      ref: safeRef(artifact.ref, artifact.access, accessDescriptor),
      occurrence_ref: safeRef(artifact.occurrence_ref, artifact.access, accessDescriptor),
      artifact_dedupe_ref: artifactDecision?.allowed ? artifact.artifact_dedupe_ref : null,
      dedupe_candidate_ref: artifactDecision?.allowed ? artifact.dedupe_candidate_ref : null,
      dedupe_strength: artifact.dedupe_strength,
      kind: artifact.kind,
      media_type: artifactDecision?.allowed ? artifact.media_type : null,
      availability: artifact.availability,
      replayable: artifact.replayable,
      access_tier: artifact.access?.tier ?? "unclassified",
      redacted: !artifactDecision?.allowed
    } : null,
    extractions: (transport.extractions || []).map((x) => projectItem(
      x,
      accessDescriptor,
      ["status", "source_artifact_ref", "method_ref", "version_ref"],
      ["status"]
    )),
    representations: (transport.representations || []).map((x) => projectItem(
      x,
      accessDescriptor,
      ["extraction_ref", "source_artifact_ref", "role", "language", "script"]
    )),
    user_interpretations: (transport.user_interpretations || []).map((x) => projectItem(
      x,
      accessDescriptor,
      ["source_artifact_ref"]
    )),
    temporal: transport.temporal ? tierDecision(transport.temporal.access?.tier, accessDescriptor).allowed ? {
      occurred_at: transport.temporal.occurred_at,
      source_time: transport.temporal.source_time,
      input_time: transport.temporal.input_time,
      timezone: transport.temporal.timezone,
      uncertainty: transport.temporal.uncertainty,
      access_tier: transport.temporal.access?.tier ?? "unclassified",
      redacted: !1
    } : {
      present: !0,
      access_tier: transport.temporal.access?.tier ?? "unclassified",
      redacted: !0
    } : null,
    origin: transport.origin ? {
      channel: transport.origin.channel,
      surface: transport.origin.surface
    } : null,
    persistence: {
      mode: transport.persistence?.mode || "ephemeral",
      persisted_ref: safeRef(
        transport.persistence?.persisted_ref,
        { tier: transport.root_access_tier },
        accessDescriptor
      )
    }
  };
}
function rawInputForIntakeOutput(intake, accessDescriptor) {
  let transport = ensureResearchIntakeTransport(intake);
  return transport?.raw_input && tierDecision(transport.raw_input.access?.tier, accessDescriptor).allowed ? transport.raw_input.value : null;
}
function questionForIntakeOutput(question, intake, accessDescriptor) {
  let transport = ensureResearchIntakeTransport(intake), raw = transport?.raw_input?.value;
  if (!raw || tierDecision(transport.raw_input.access?.tier, accessDescriptor).allowed) return clean6(question);
  let q = clean6(question);
  return q ? q.includes(String(raw)) ? null : q : null;
}

// src/lib/research/universalFinding.js
var VALID_STAGES = Object.freeze(["candidate", "finding", "evidence", "claim", "interpretation"]), STAGE_SET = new Set(VALID_STAGES), VALID_VERIFICATION_STATES = Object.freeze(["match", "mismatch", "method_unknown", "not_tested"]), VERIFICATION_SET = new Set(VALID_VERIFICATION_STATES), safePart = (v) => encodeURIComponent(String(v ?? "").trim());
function universalFindingId({ kind, sourceIdentity, subjectKey, occurrence } = {}) {
  let occ = occurrence && typeof occurrence == "object" ? [occurrence.skip, occurrence.dir ?? occurrence.direction, occurrence.start].filter((v) => v != null).join(":") : "", native = typeof sourceIdentity == "string" ? sourceIdentity : sourceIdentity && typeof sourceIdentity == "object" ? JSON.stringify(sourceIdentity) : "";
  return ["uf1", kind || "other", subjectKey || "", native || occ].map(safePart).join(":");
}
function normalizeStage(stage) {
  if (stage == null || stage === "") return null;
  if (!STAGE_SET.has(stage))
    throw new TypeError(
      `universalFinding: invalid stage "${stage}". Allowed: ${VALID_STAGES.join(", ")}. Semantic state is never coerced (truth_axes_foundation_law INVARIANT PR2) \u2014 omit stage to leave the epistemic type honestly unknown.`
    );
  return stage;
}
function normalizeVerification(verification) {
  let v = verification && typeof verification == "object" ? verification : {}, state = v.verification_state, resolved = state == null || state === "" ? null : state;
  if (resolved !== null && !VERIFICATION_SET.has(resolved))
    throw new TypeError(
      `universalFinding: invalid verification_state "${state}". Allowed: ${VALID_VERIFICATION_STATES.join(", ")}. Semantic state is never coerced (truth_axes_foundation_law INVARIANT PR2) \u2014 omit verification_state to leave the verification axis honestly unknown.`
    );
  return {
    claimed_expression: null,
    claimed_method: null,
    claimed_value: null,
    engine_method_tested: null,
    engine_result: null,
    // Language the claimed_expression was written in, when a claim is actually present.
    // Scoped narrowly to verification — most Findings have no claimed expression at all,
    // so this stays null far more often than set (contract §C).
    statement_lang: null,
    ...v,
    verification_state: resolved
  };
}
function makeUniversalFinding(input = {}) {
  let stage = normalizeStage(input.stage), subject = input.subject || {}, identity = input.identity || {};
  return {
    v: 1,
    id: input.id || universalFindingId({
      kind: input.kind,
      sourceIdentity: identity.sourceIdentity,
      subjectKey: subject.key || subject.label,
      occurrence: identity.occurrence
    }),
    kind: input.kind || "other",
    // EPISTEMIC TYPE axis. null = honestly unknown. Never inferred from the envelope's name.
    stage,
    // GOVERNANCE axis as carried by the envelope. null = this envelope asserts nothing.
    status: input.status ?? null,
    subject: {
      type: subject.type || "entity",
      key: subject.key ?? null,
      label: subject.label || "",
      // REPRESENTATION axis only: the language subject.label is currently shown in.
      // Never the identity. subject.key/identity.entityRef must stay stable across languages
      // (Multilingual Identity Foundation Closure contract, docs/audits/SOD1820_SYSTEM_MASTER_MAP_2026-08-31.md §C).
      lang: subject.lang ?? null,
      value: subject.value ?? null
    },
    // source.lang = language of the underlying evidence/corpus text (never changes for a given
    // Finding regardless of display language). Distinct from subject.lang (display) and
    // verification.statement_lang (a claimed expression's language) — see contract §C.
    source: { engine: null, adapter: "universal-finding-v1", sourceRef: null, method: null, corpus: null, lang: null, ...input.source || {} },
    identity: { sourceIdentity: null, occurrence: null, entityRef: null, relationRef: null, ...identity },
    // VERIFICATION axis (Research DNA v1 §1 shape). verification_state null = honestly unknown;
    // it is NEVER read as "not_tested" — only an adapter that knows may declare that.
    verification: normalizeVerification(input.verification),
    evidence: { refs: [], facts: [], score: null, confidence: null, ...input.evidence || {} },
    // PUBLICATION/ACCESS axis. null = unknown; it is NEVER read as "public".
    access: { tier: null, reason: null, ...input.access || {} },
    provenance: {
      // null, not "SYSTEM": unknown origin must not inherit maximum institutional weight.
      createdBy: null,
      // Presentation-safe: a true fact about when THIS envelope was constructed.
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      inputRef: null,
      parentFindingIds: [],
      researchSessionId: null,
      journeyNodeId: null,
      ...input.provenance || {}
    },
    projection: { anchors: [], relations: [], dimensions: {}, ...input.projection || {} },
    view: { color: null, pinned: !1, selected: !1, hidden: !1, rendererHints: {}, ...input.view || {} }
  };
}
function isUniversalFinding(value) {
  return !!(value && value.v === 1 && value.id && value.subject && value.source && value.identity && value.provenance);
}

// src/lib/research/researchResultBundle.js
var CAPABILITY_STATUS = Object.freeze({
  EXECUTED: "executed",
  NEGATIVE_RESULT: "negative_result",
  SKIPPED: "skipped",
  CONTEXT_REQUIRED: "context_required",
  ENTITLEMENT_GATED: "entitlement_gated",
  UNVERIFIED: "unverified",
  FAILED: "failed",
  MISSING_ADAPTER: "missing_adapter",
  // Compatibility alias for early W2.1 callers. New code must emit MISSING_ADAPTER explicitly.
  MISSING: "missing_adapter"
}), EVIDENCE_RELATION = Object.freeze({
  DERIVATION: "derivation",
  CONVERGENCE: "convergence",
  INDEPENDENT_EVIDENCE: "independent_evidence"
}), VALID_CAPABILITY_STATUS = new Set(Object.values(CAPABILITY_STATUS)), VALID_EVIDENCE_RELATION = new Set(Object.values(EVIDENCE_RELATION)), ACCESS_CLASS = Object.freeze({
  PUBLIC_SOURCE: "public_source",
  SOURCE_ACCESS_CONTROLLED: "source_access_controlled",
  PERSONAL: "personal",
  UNCLASSIFIED: "unclassified"
}), SEMANTIC_CLASS = Object.freeze({
  EVIDENCE: "evidence",
  DERIVATION: "derivation",
  CONTEXT: "context",
  PROJECTION: "projection",
  RANKING: "ranking"
}), VALID_ACCESS_CLASS = new Set(Object.values(ACCESS_CLASS)), VALID_SEMANTIC_CLASS = new Set(Object.values(SEMANTIC_CLASS)), RESTRICTED_ACCESS_TIERS = /* @__PURE__ */ new Set(["private", "public_candidate", "personal", "user_private", "draft", "internal", "pending"]), RAW_AUTHORIZATION_KEYS = Object.freeze(["authorization_context", "authorizationContext", "auth_context", "authContext"]);
function stripRawAuthorizationContext(value) {
  if (!value || typeof value != "object" || Array.isArray(value)) return value;
  let touched = !1, out = {};
  for (let [key, item] of Object.entries(value)) {
    if (RAW_AUTHORIZATION_KEYS.includes(key)) {
      touched = !0;
      continue;
    }
    out[key] = item;
  }
  return touched && (out.authorization_context_removed_at_composition_boundary = !0), out;
}
var PERSONAL_CONTEXT_SOURCE = "personal_context", ACCESS_TIER_PERSONAL = "personal";
function identityAccessDecision(identity, accessDescriptor) {
  let allowed = allowedTiers2(accessDescriptor), tier = clean7(identity?.access?.tier);
  return tier && RESTRICTED_ACCESS_TIERS.has(tier) && !allowed.has(tier) ? { allowed: !1, reason: `identity_access_tier_not_permitted:${tier}` } : clean7(identity?.source) === PERSONAL_CONTEXT_SOURCE && !allowed.has(ACCESS_TIER_PERSONAL) ? { allowed: !1, reason: "personal_context_identity_without_personal_scope" } : { allowed: !0, reason: null };
}
function redactIdentity(identity, reason) {
  let stableSource = clean7(identity?.identity_key) || clean7(identity?.key) || clean7(identity?.ref) || clean7(identity?.label) || clean7(identity?.id) || "identity";
  return {
    type: clean7(identity?.type) || "entity",
    source: clean7(identity?.source),
    confidence: clean7(identity?.confidence),
    // Stable across runs so the same subject stays the same subject, reversible by nobody.
    ref: `anon:${stableIdentityDigest(stableSource)}`,
    access: { tier: clean7(identity?.access?.tier) },
    redacted: !0,
    redaction_reason: reason
  };
}
function projectIdentityForAccess(identity, accessDescriptor) {
  if (!identity || typeof identity != "object") return identity;
  let decision = identityAccessDecision(identity, accessDescriptor);
  return decision.allowed ? identity : redactIdentity(identity, decision.reason);
}
function projectIdentityListForAccess(list, accessDescriptor) {
  return Array.isArray(list) ? list.map((x) => projectIdentityForAccess(x, accessDescriptor)) : list;
}
function projectSnapshotForAccess(snapshot, accessDescriptor) {
  return !snapshot || typeof snapshot != "object" || Array.isArray(snapshot) || !Array.isArray(snapshot.resolved_identities) ? snapshot : {
    ...snapshot,
    resolved_identities: projectIdentityListForAccess(snapshot.resolved_identities, accessDescriptor)
  };
}
function projectQueryForAccess(query, accessDescriptor) {
  return !query || typeof query != "object" || Array.isArray(query) || !Array.isArray(query.identities) ? query : { ...query, identities: projectIdentityListForAccess(query.identities, accessDescriptor) };
}
function projectPlanForAccess(plan, accessDescriptor) {
  if (!plan || typeof plan != "object" || Array.isArray(plan)) return plan;
  let out = { ...plan };
  return Array.isArray(out.identities) && (out.identities = projectIdentityListForAccess(out.identities, accessDescriptor)), out.primary_identity && (out.primary_identity = projectIdentityForAccess(out.primary_identity, accessDescriptor)), out;
}
function allowedTiers2(accessDescriptor) {
  let list = Array.isArray(accessDescriptor?.allowed_access_tiers) ? accessDescriptor.allowed_access_tiers : null;
  return new Set(list && list.length ? list.map(String) : ["public"]);
}
function findingAccessDecision(finding, accessDescriptor, accessClass = ACCESS_CLASS.UNCLASSIFIED) {
  let tier = clean7(finding?.access?.tier), allowed = allowedTiers2(accessDescriptor), controlled = accessClass === ACCESS_CLASS.SOURCE_ACCESS_CONTROLLED || accessClass === ACCESS_CLASS.PERSONAL;
  return controlled && !tier ? { allowed: !1, reason: "access_controlled_source_without_explicit_access_tier" } : tier && !allowed.has(tier) && (controlled || RESTRICTED_ACCESS_TIERS.has(tier)) ? { allowed: !1, reason: `access_tier_not_permitted:${tier}` } : { allowed: !0, reason: null };
}
function normalizeBounded(bounded) {
  if (!bounded || typeof bounded != "object") return null;
  let total = Number(bounded.total_count ?? bounded.total), returned = Number(bounded.returned_count ?? bounded.returned);
  if (!Number.isFinite(total) && !Number.isFinite(returned)) return null;
  let totalCount = Number.isFinite(total) ? total : null, returnedCount = Number.isFinite(returned) ? returned : null;
  return {
    total_count: totalCount,
    returned_count: returnedCount,
    truncated: bounded.truncated === !0 || totalCount != null && returnedCount != null && returnedCount < totalCount,
    window: bounded.window ?? null,
    ordering: clean7(bounded.ordering),
    continuation: bounded.continuation ?? null
  };
}
function clean7(value) {
  return value == null ? null : String(value).trim() || null;
}
function normalizeFindingOutcome(outcome = {}, findingIds = /* @__PURE__ */ new Set()) {
  let findingId = clean7(outcome.finding_id || outcome.findingId);
  if (!findingId || !findingIds.has(findingId)) return null;
  let relation = clean7(outcome.evidence_relation || outcome.evidenceRelation);
  if (!VALID_EVIDENCE_RELATION.has(relation))
    throw new TypeError(`researchResultBundle: invalid evidence relation "${relation}" for ${findingId}`);
  let rawBaseRate = outcome.base_rate ?? outcome.baseRate, baseRate = rawBaseRate == null ? null : Number(rawBaseRate);
  return {
    finding_id: findingId,
    evidence_relation: relation,
    depends_on: [...new Set((Array.isArray(outcome.depends_on) ? outcome.depends_on : Array.isArray(outcome.dependsOn) ? outcome.dependsOn : []).map(clean7).filter(Boolean))],
    convergence_key: clean7(outcome.convergence_key || outcome.convergenceKey),
    reason: clean7(outcome.reason),
    expectedness: clean7(outcome.expectedness),
    expectedness_model: clean7(outcome.expectedness_model || outcome.expectednessModel),
    base_rate: Number.isFinite(baseRate) ? baseRate : null
  };
}
function normalizeCapabilityRecord(record = {}, accessDescriptor = null) {
  let key = clean7(record.key || record.capability);
  if (!key) throw new TypeError("researchResultBundle: capability key is required");
  let status = clean7(record.status) || CAPABILITY_STATUS.MISSING_ADAPTER;
  if (!VALID_CAPABILITY_STATUS.has(status))
    throw new TypeError(`researchResultBundle: invalid capability status "${status}" for ${key}`);
  let accessClass = clean7(record.access_class || record.accessClass) || ACCESS_CLASS.UNCLASSIFIED;
  if (!VALID_ACCESS_CLASS.has(accessClass))
    throw new TypeError(`researchResultBundle: invalid access class "${accessClass}" for ${key}`);
  let semanticClass = clean7(record.semantic_class || record.semanticClass);
  if (semanticClass && !VALID_SEMANTIC_CLASS.has(semanticClass))
    throw new TypeError(`researchResultBundle: invalid semantic class "${semanticClass}" for ${key}`);
  let rawFindings = (Array.isArray(record.findings) ? record.findings : []).filter(isUniversalFinding);
  if (status === CAPABILITY_STATUS.NEGATIVE_RESULT && rawFindings.length)
    throw new TypeError(`researchResultBundle: negative_result for ${key} cannot carry positive findings`);
  let findings = [], accessFilterReasons = /* @__PURE__ */ new Map();
  for (let finding of rawFindings) {
    let decision = findingAccessDecision(finding, accessDescriptor, accessClass);
    decision.allowed ? findings.push(finding) : accessFilterReasons.set(decision.reason, (accessFilterReasons.get(decision.reason) || 0) + 1);
  }
  let findingIds = new Set(findings.map((x) => x.id)), findingOutcomes = (Array.isArray(record.finding_outcomes) ? record.finding_outcomes : Array.isArray(record.findingOutcomes) ? record.findingOutcomes : []).map((x) => normalizeFindingOutcome(x, findingIds)).filter(Boolean);
  return {
    key,
    owner: clean7(record.owner),
    status,
    requested: record.requested !== !1,
    executed: status === CAPABILITY_STATUS.EXECUTED || status === CAPABILITY_STATUS.NEGATIVE_RESULT,
    reason: clean7(record.reason),
    negative_result: status === CAPABILITY_STATUS.NEGATIVE_RESULT ? {
      searched: !0,
      reason: clean7(record.reason),
      scope: record.negative_scope ?? record.negativeScope ?? null
    } : null,
    source_refs: Array.isArray(record.source_refs) ? record.source_refs.filter(Boolean) : [],
    version_refs: Array.isArray(record.version_refs) ? record.version_refs.filter(Boolean) : [],
    finding_ids: findings.map((x) => x.id),
    finding_outcomes: findingOutcomes,
    findings,
    access_class: accessClass,
    semantic_class: semanticClass,
    // Access filtering is reported, never silent. It is NOT negative evidence: nothing was searched
    // and found absent — material exists and was withheld from THIS caller.
    access_filtered: {
      count: [...accessFilterReasons.values()].reduce((a, b) => a + b, 0),
      reasons: [...accessFilterReasons.entries()].map(([reason, count]) => ({ reason, count }))
    },
    bounded: normalizeBounded(record.bounded),
    cost: record.cost ?? null,
    trace: record.trace ?? null
  };
}
function dedupeUniversalFindings(findings = []) {
  let byId = /* @__PURE__ */ new Map();
  for (let finding of Array.isArray(findings) ? findings : [])
    isUniversalFinding(finding) && (byId.has(finding.id) || byId.set(finding.id, finding));
  return [...byId.values()];
}
function summarizeCoverage(capabilities = []) {
  let summary = {
    requested: 0,
    executed: 0,
    executed_empty: 0,
    positive_result: 0,
    negative_result: 0,
    skipped: 0,
    context_required: 0,
    entitlement_gated: 0,
    unverified: 0,
    failed: 0,
    missing_adapter: 0,
    access_filtered: 0,
    partial: !1,
    complete: !1
  };
  for (let cap of capabilities)
    cap.requested && summary.requested++, cap.access_filtered?.count && (summary.access_filtered += cap.access_filtered.count), cap.status === CAPABILITY_STATUS.EXECUTED ? (summary.executed++, Array.isArray(cap.finding_ids) && cap.finding_ids.length > 0 ? summary.positive_result++ : summary.executed_empty++) : cap.status === CAPABILITY_STATUS.NEGATIVE_RESULT ? (summary.executed++, summary.negative_result++) : summary[cap.status] != null && summary[cap.status]++;
  let incomplete = summary.skipped + summary.context_required + summary.entitlement_gated + summary.unverified + summary.failed + summary.missing_adapter;
  return summary.partial = summary.requested > 0 && summary.executed > 0 && incomplete > 0, summary.complete = summary.requested > 0 && summary.executed === summary.requested, summary;
}
function normalizeRankingEntry(entry = {}, findingIds = /* @__PURE__ */ new Set()) {
  let findingId = clean7(entry.finding_id || entry.findingId);
  if (!findingId || !findingIds.has(findingId)) return null;
  let numericOrNull = (value) => {
    if (value == null || value === "") return null;
    let number = Number(value);
    return Number.isFinite(number) ? number : null;
  };
  return {
    finding_id: findingId,
    rank: numericOrNull(entry.rank),
    score: numericOrNull(entry.score),
    axes: entry.axes && typeof entry.axes == "object" ? entry.axes : {},
    reasons: Array.isArray(entry.reasons) ? entry.reasons.map(String) : []
  };
}
function composeResearchResultBundle({
  query,
  plan = null,
  capabilities = [],
  ranking = [],
  resolvedRunSnapshot = null,
  nextActions = [],
  synthesis = null,
  contractVersion = 1,
  accessDescriptor = null
} = {}) {
  let effectiveAccess = normalizeAccessDescriptor(accessDescriptor || plan?.access || null), safePlan = projectPlanForAccess(stripRawAuthorizationContext(plan), effectiveAccess), safeSnapshot = projectSnapshotForAccess(stripRawAuthorizationContext(resolvedRunSnapshot), effectiveAccess), safeQuery = projectQueryForAccess(query, effectiveAccess), normalizedCapabilities = (Array.isArray(capabilities) ? capabilities : []).map((record) => normalizeCapabilityRecord(record, effectiveAccess)), findings = dedupeUniversalFindings(normalizedCapabilities.flatMap((x) => x.findings)), findingIds = new Set(findings.map((x) => x.id)), normalizedRanking = (Array.isArray(ranking) ? ranking : []).map((x) => normalizeRankingEntry(x, findingIds)).filter(Boolean).sort((a, b) => (a.rank ?? Number.MAX_SAFE_INTEGER) - (b.rank ?? Number.MAX_SAFE_INTEGER)), findingOutcomes = normalizedCapabilities.flatMap((cap) => cap.finding_outcomes.map((outcome) => ({
    ...outcome,
    capability: cap.key
  }))), boundedCapabilities = normalizedCapabilities.filter((cap) => cap.bounded), redactedIdentityCount = [
    ...Array.isArray(safeQuery?.identities) ? safeQuery.identities : [],
    ...Array.isArray(safePlan?.identities) ? safePlan.identities : []
  ].filter((x) => x?.redacted === !0).length;
  return {
    contract_version: contractVersion,
    query: safeQuery ?? null,
    // Composition-boundary scrubbed: the raw private authorization context can never ride out on the
    // plan or the snapshot, whichever caller built them.
    plan: safePlan,
    access: effectiveAccess,
    // Identity disclosure state of THIS bundle, so a consumer never has to infer it.
    identity_disclosure: {
      redacted_identity_count: redactedIdentityCount,
      free_text_may_contain_restricted_terms: redactedIdentityCount > 0,
      note: redactedIdentityCount > 0 ? "resolved identities were redacted for this access level; query.raw_input/plan.question are caller-supplied text and may still contain the restricted term" : null
    },
    findings,
    // First-class dependency semantics. These are not ranking labels and never mutate Finding truth.
    finding_outcomes: findingOutcomes,
    ranking: normalizedRanking,
    capability_trace: normalizedCapabilities.map(({ findings: _findings, ...cap }) => cap),
    coverage: summarizeCoverage(normalizedCapabilities),
    // Bounded output: a caller can always tell how much of the source population it actually holds,
    // and how to ask for the rest, instead of silently believing a window is the whole truth.
    output_bounds: {
      truncated: boundedCapabilities.some((cap) => cap.bounded.truncated),
      capabilities: boundedCapabilities.map((cap) => ({ capability: cap.key, ...cap.bounded }))
    },
    resolved_run_snapshot: safeSnapshot,
    next_actions: Array.isArray(nextActions) ? nextActions : [],
    synthesis,
    invariants: {
      universal_finding_only: !0,
      source_native_truth_preserved: !0,
      derivation_is_not_independent_evidence: !0,
      convergence_is_not_automatically_independent: !0,
      negative_result_requires_executed_search: !0,
      missing_adapter_is_not_negative_evidence: !0,
      no_ai_arithmetic_fallback: !0,
      no_auto_canonicalization: !0,
      no_auto_publication: !0,
      access_filtered_is_not_negative_evidence: !0,
      raw_authorization_context_never_in_output: !0,
      personal_identity_text_never_in_output: !0,
      bounded_window_is_not_source_exhaustive: !0
    }
  };
}
function capabilityResult({
  key,
  owner = null,
  status = CAPABILITY_STATUS.EXECUTED,
  findings = [],
  findingOutcomes = [],
  reason = null,
  negativeScope = null,
  sourceRefs = [],
  versionRefs = [],
  cost = null,
  trace = null,
  requested = !0,
  accessClass = ACCESS_CLASS.UNCLASSIFIED,
  semanticClass = null,
  bounded = null
} = {}) {
  return {
    key,
    owner,
    status,
    findings,
    finding_outcomes: findingOutcomes,
    reason,
    negative_scope: negativeScope,
    source_refs: sourceRefs,
    version_refs: versionRefs,
    cost,
    trace,
    requested,
    access_class: accessClass,
    semantic_class: semanticClass,
    bounded
  };
}

// src/lib/research/researchSynthesis.js
var SYNTHESIS_STATUS = Object.freeze({
  COMPOSED: "composed",
  INSUFFICIENT_EVIDENCE: "insufficient_evidence",
  FAILED: "failed"
}), VALID_STATUS = new Set(Object.values(SYNTHESIS_STATUS)), FORBIDDEN_SCORE_KEYS = /* @__PURE__ */ new Set([
  "truth_score",
  "truthScore",
  "accuracy_score",
  "accuracyScore",
  "canonical_score",
  "canonicalScore"
]), clean8 = (v) => v == null ? null : String(v).trim() || null, uniq2 = (v) => [...new Set((Array.isArray(v) ? v : []).map(clean8).filter(Boolean))];
function rejectForbiddenScores(value, seen = /* @__PURE__ */ new WeakSet()) {
  if (!(value == null || typeof value != "object") && !seen.has(value)) {
    if (seen.add(value), Array.isArray(value)) {
      value.forEach((item) => rejectForbiddenScores(item, seen));
      return;
    }
    for (let [key, nested] of Object.entries(value)) {
      if (FORBIDDEN_SCORE_KEYS.has(key))
        throw new TypeError(`researchSynthesis: ${key} is forbidden`);
      rejectForbiddenScores(nested, seen);
    }
  }
}
function supportOf(input = {}, allowed = /* @__PURE__ */ new Set()) {
  let ids = uniq2(input.finding_ids || input.findingIds);
  return ids.forEach((id) => {
    if (!allowed.has(id))
      throw new TypeError(`researchSynthesis: support references unavailable finding ${id}`);
  }), Object.freeze({
    finding_ids: Object.freeze(ids),
    dependency_groups: Object.freeze(uniq2(input.dependency_groups || input.dependencyGroups)),
    derivation_refs: Object.freeze(uniq2(input.derivation_refs || input.derivationRefs)),
    negative_or_control_refs: Object.freeze(uniq2(input.negative_or_control_refs || input.negativeOrControlRefs))
  });
}
function claimOf(input = {}, allowed = /* @__PURE__ */ new Set()) {
  let id = clean8(input.id), text = clean8(input.text);
  if (!id || !text) throw new TypeError("researchSynthesis: every atomic claim requires id + text");
  return Object.freeze({
    id,
    text,
    role: clean8(input.role) || "interpretation",
    motif_key: clean8(input.motif_key || input.motifKey),
    support: supportOf(input.support, allowed)
  });
}
function interpretiveFrameOf(input) {
  return !input || typeof input != "object" || Array.isArray(input) ? Object.freeze({}) : Object.freeze({
    essence: clean8(input.essence),
    power: clean8(input.power),
    shadow: clean8(input.shadow),
    balance: clean8(input.balance),
    action: clean8(input.action)
  });
}
function motifOf(input = {}, claimIds = /* @__PURE__ */ new Set()) {
  let key = clean8(input.key);
  if (!key) throw new TypeError("researchSynthesis: motif key is required");
  let refs = uniq2(input.claim_ids || input.claimIds);
  return refs.forEach((id) => {
    if (!claimIds.has(id)) throw new TypeError(`researchSynthesis: motif references unknown claim ${id}`);
  }), Object.freeze({
    key,
    label: clean8(input.label) || key,
    summary: clean8(input.summary),
    claim_ids: Object.freeze(refs),
    frame: interpretiveFrameOf(input.frame || input.interpretive_frame || input.interpretiveFrame)
  });
}
function explainWhyOf(input) {
  return !input || typeof input != "object" || Array.isArray(input) ? Object.freeze({}) : Object.freeze({
    summary: clean8(input.summary),
    reason: clean8(input.reason),
    error_class: clean8(input.error_class || input.errorClass),
    refs: Object.freeze(uniq2(input.refs))
  });
}
function provenanceOf(input) {
  return !input || typeof input != "object" || Array.isArray(input) ? Object.freeze({}) : Object.freeze({
    source_refs: Object.freeze(uniq2(input.source_refs || input.sourceRefs)),
    version_refs: Object.freeze(uniq2(input.version_refs || input.versionRefs)),
    trace_ref: clean8(input.trace_ref || input.traceRef),
    policy_version: clean8(input.policy_version || input.policyVersion)
  });
}
function normalizeResearchSynthesis(input, {
  allowedFindingIds = [],
  frozenAt = null,
  sourceBundleContractVersion = null
} = {}) {
  if (input == null) return null;
  if (!input || typeof input != "object" || Array.isArray(input))
    throw new TypeError("researchSynthesis: synthesis must be an object");
  rejectForbiddenScores(input);
  let status = clean8(input.status) || SYNTHESIS_STATUS.COMPOSED;
  if (!VALID_STATUS.has(status)) throw new TypeError(`researchSynthesis: invalid status "${status}"`);
  let allowed = new Set(uniq2(allowedFindingIds)), claims = (Array.isArray(input.claims) ? input.claims : []).map((x) => claimOf(x, allowed)), claimIds = new Set(claims.map((x) => x.id));
  if (claimIds.size !== claims.length) throw new TypeError("researchSynthesis: duplicate atomic claim id");
  if (status === SYNTHESIS_STATUS.COMPOSED && claims.length === 0)
    throw new TypeError("researchSynthesis: composed synthesis requires atomic claims");
  let motifs = (Array.isArray(input.motifs) ? input.motifs : []).map((x) => motifOf(x, claimIds)), freezeIn = input.freeze && typeof input.freeze == "object" && !Array.isArray(input.freeze) ? input.freeze : {};
  return Object.freeze({
    contract_version: 1,
    status,
    message: clean8(input.message),
    claims: Object.freeze(claims),
    motifs: Object.freeze(motifs),
    freeze: Object.freeze({
      frozen: freezeIn.frozen === !0,
      frozen_at: clean8(freezeIn.frozen_at || freezeIn.frozenAt) || clean8(frozenAt),
      policy_version: clean8(freezeIn.policy_version || freezeIn.policyVersion) || "research-synthesis-seam-v1",
      source_bundle_contract_version: sourceBundleContractVersion ?? null,
      source_finding_ids: Object.freeze(uniq2(claims.flatMap((x) => x.support.finding_ids)))
    }),
    explain_why: explainWhyOf(input.explain_why || input.explainWhy),
    provenance: provenanceOf(input.provenance),
    invariants: Object.freeze({
      synthesis_is_not_truth: !0,
      no_universal_truth_score: !0,
      support_must_be_bundle_backed: !0,
      interpretive_frame_is_not_evidence: !0,
      no_auto_canonicalization: !0,
      no_auto_publication: !0,
      no_calibration_or_learning_policy_in_this_contract: !0
    })
  });
}
function failedResearchSynthesis(error, {
  frozenAt = null,
  sourceBundleContractVersion = null
} = {}) {
  return Object.freeze({
    contract_version: 1,
    status: SYNTHESIS_STATUS.FAILED,
    message: null,
    claims: Object.freeze([]),
    motifs: Object.freeze([]),
    freeze: Object.freeze({
      frozen: !0,
      frozen_at: clean8(frozenAt),
      policy_version: "research-synthesis-seam-v1",
      source_bundle_contract_version: sourceBundleContractVersion ?? null,
      source_finding_ids: Object.freeze([])
    }),
    explain_why: Object.freeze({
      reason: clean8(error?.message) || "synthesis failed",
      error_class: clean8(error?.name) || "Error",
      refs: Object.freeze([])
    }),
    provenance: Object.freeze({}),
    invariants: Object.freeze({
      synthesis_is_not_truth: !0,
      no_universal_truth_score: !0,
      support_must_be_bundle_backed: !0,
      interpretive_frame_is_not_evidence: !0,
      no_auto_canonicalization: !0,
      no_auto_publication: !0,
      no_calibration_or_learning_policy_in_this_contract: !0
    })
  });
}

// src/lib/research/razielActionContract.js
var RAZIEL_ACTION_CONTRACT_VERSION = 1, RAZIEL_NEXT_ACTION_KEY = "raziel_route", VALID_ROUTE_ACTIONS = new Set(Object.values(RAZIEL_ROUTE_ACTION));
function clean9(value) {
  return value == null ? "" : String(value).trim();
}
function meaningfulContext(plan) {
  return !plan || typeof plan != "object" ? !1 : !!(clean9(plan.question) || plan.primary_identity || plan.surface_context?.subject || plan.surface_context?.target);
}
function synthesisState(synthesis) {
  return !synthesis || typeof synthesis != "object" ? "not_composed" : clean9(synthesis.status) || "unknown";
}
function selectedAction(routeGrammar) {
  if (!routeGrammar || typeof routeGrammar != "object") return null;
  let actions = Array.isArray(routeGrammar.actions) ? routeGrammar.actions : [];
  return actions.find((action) => action?.selected === !0) || actions.find((action) => action?.id === routeGrammar.requested_action) || null;
}
function buildRazielNextAction({
  plan = null,
  synthesis = null,
  coverage = null
} = {}) {
  if (!meaningfulContext(plan)) return null;
  let grammar = plan?.route_grammar, selected = selectedAction(grammar);
  if (!grammar || !selected || !clean9(grammar.requested_action)) return null;
  let state = synthesisState(synthesis), hasCanonicalSynthesisMessage = !!(synthesis && typeof synthesis == "object" && clean9(synthesis.message)), alternatives = (Array.isArray(grammar.actions) ? grammar.actions : []).filter((action) => action && action.id !== selected.id).map((action) => Object.freeze({
    id: clean9(action.id),
    label: clean9(action.label),
    task_mode: clean9(action.task_mode),
    preferred_home: clean9(action.preferred_home)
  }));
  return Object.freeze({
    action: RAZIEL_NEXT_ACTION_KEY,
    contract_version: RAZIEL_ACTION_CONTRACT_VERSION,
    route_action: clean9(selected.id),
    label: clean9(selected.label),
    task_mode: clean9(selected.task_mode),
    preferred_home: clean9(selected.preferred_home) || "current",
    requested_by: clean9(grammar.requested_by) || "unknown",
    surface: clean9(grammar.surface) || "system",
    subject_type: clean9(grammar.subject_type) || null,
    reason_codes: Object.freeze(Array.isArray(selected.hints) ? [...selected.hints] : []),
    delivery: Object.freeze({
      mode: "in_place_first",
      preserve_context: !0,
      exact_return_on_handoff: !0,
      semantic_handoff_only: !0
    }),
    synthesis: Object.freeze({
      state,
      message_authority: hasCanonicalSynthesisMessage ? "bundle.synthesis" : null,
      local_message: null,
      must_not_mint_second_message: !0
    }),
    coverage: Object.freeze({
      requested: Number.isFinite(Number(coverage?.requested)) ? Number(coverage.requested) : null,
      executed: Number.isFinite(Number(coverage?.executed)) ? Number(coverage.executed) : null,
      partial: coverage?.partial === !0,
      complete: coverage?.complete === !0
    }),
    alternatives: Object.freeze(alternatives),
    guards: Object.freeze({
      semantic_action_only: !0,
      no_navigation_execution: !0,
      no_tool_execution: !0,
      no_authorization_decision: !0,
      no_truth_ranking: !0,
      no_local_message_generation: !0,
      same_synthesis_is_message_authority: !0,
      no_second_router: !0,
      one_context_required: !0
    })
  });
}
function mergeRazielNextAction(existingNextActions = [], razielAction = null) {
  let withoutRaziel = (Array.isArray(existingNextActions) ? existingNextActions : []).filter((item) => item?.action !== RAZIEL_NEXT_ACTION_KEY);
  return razielAction ? [...withoutRaziel, razielAction] : withoutRaziel;
}

// src/lib/research/researchComposerW2.js
function executorMap(executors) {
  return executors instanceof Map ? executors : new Map(Object.entries(executors && typeof executors == "object" ? executors : {}));
}
function failureReason(error) {
  return error ? error?.message ? String(error.message) : String(error) : "capability execution failed";
}
async function executeCapability({
  capability,
  executor,
  plan,
  identityResolution,
  intakeTransport,
  signal,
  authorizationContext
}) {
  if (typeof executor != "function")
    return capabilityResult({
      key: capability,
      status: CAPABILITY_STATUS.MISSING_ADAPTER,
      reason: "no canonical capability executor supplied",
      findings: []
    });
  try {
    let out = await executor({
      plan,
      identityResolution,
      intake: intakeTransport,
      capability,
      signal,
      authorizationContext,
      access: plan?.access || null
    }), status = out?.status || CAPABILITY_STATUS.EXECUTED;
    return capabilityResult({
      key: capability,
      owner: out?.owner || null,
      status,
      findings: Array.isArray(out?.findings) ? out.findings : [],
      findingOutcomes: out?.findingOutcomes || out?.finding_outcomes || [],
      reason: out?.reason || null,
      negativeScope: out?.negativeScope ?? out?.negative_scope ?? null,
      sourceRefs: out?.sourceRefs || out?.source_refs || [],
      versionRefs: out?.versionRefs || out?.version_refs || [],
      cost: out?.cost ?? null,
      trace: out?.trace ?? null,
      requested: !0,
      accessClass: out?.accessClass || out?.access_class || void 0,
      semanticClass: out?.semanticClass || out?.semantic_class || null,
      bounded: out?.bounded ?? null
    });
  } catch (error) {
    return capabilityResult({
      key: capability,
      status: CAPABILITY_STATUS.FAILED,
      reason: failureReason(error),
      findings: [],
      trace: { error_class: error?.name || "Error" }
    });
  }
}
async function composeResearchW2({
  question = "",
  intent = "research",
  identityCandidates = [],
  rawInput = null,
  intake = null,
  explicitTextComputation = !1,
  authorizationContext = null,
  contextType = "public_user",
  surfaceContext = null,
  requestedCapabilities = [],
  // Passthrough to buildResearchPlanV2's OPTIONAL capability allowlist seam — see researchPlanV2.js.
  capabilityAllowlist = null,
  requestedDepth = null,
  executors = {},
  ranking = [],
  // OPTIONAL presentation-only resolver. It runs after every capability has returned, so an
  // existing authority (for example gematria_words.lead_rank) can rank admitted Finding IDs
  // without changing engine truth or requiring a second Result Bundle. Failure falls back to the
  // explicit ranking input and may never suppress otherwise valid research evidence.
  rankingResolver = null,
  resolvedRunSnapshot = null,
  nextActions = [],
  synthesizer = null,
  // OPTIONAL, privacy-safe execution observer. Called once per executed capability with timestamps/
  // status/counts ONLY — never raw Findings or content. It must never alter composition semantics:
  // a throwing observer is swallowed and composition proceeds exactly as if it were absent.
  executionObserver = null,
  signal = null
} = {}) {
  let intakeTransport = ensureResearchIntakeTransport(intake), effectiveRawInput = intakeTransport?.raw_input?.value ?? rawInput ?? question, effectiveIdentityCandidates = [
    ...Array.isArray(intakeTransport?.identity_candidates) ? intakeTransport.identity_candidates : [],
    ...Array.isArray(identityCandidates) ? identityCandidates : []
  ], identityResolution = resolveResearchIdentities({
    candidates: effectiveIdentityCandidates,
    rawInput: effectiveRawInput,
    explicitTextComputation
  }), plan = buildResearchPlanV2({
    question,
    intent,
    identityResolution,
    authorizationContext,
    contextType,
    surfaceContext,
    requestedCapabilities,
    capabilityAllowlist,
    requestedDepth
  }), intakeAccess = researchIntakeAccessDecision(intakeTransport, plan.access), safeIntakeLineage = projectResearchIntakeLineage(intakeTransport, plan.access), safeRawInput = intakeTransport ? rawInputForIntakeOutput(intakeTransport, plan.access) : rawInput ?? question, safeQuestion = intakeTransport ? questionForIntakeOutput(question, intakeTransport, plan.access) : question, outputPlan = intakeTransport ? {
    ...plan,
    question: safeQuestion,
    intake_access: {
      allowed_for_execution: intakeAccess.allowed,
      reasons: intakeAccess.reasons
    }
  } : plan, requested = [.../* @__PURE__ */ new Set([
    ...plan.check_order || [],
    ...plan.requested_capabilities || []
  ])], byCapability = executorMap(executors), capabilityResults = [], executorNextActions = [];
  for (let capability of requested) {
    if (signal?.aborted) {
      capabilityResults.push(capabilityResult({
        key: capability,
        status: CAPABILITY_STATUS.SKIPPED,
        reason: "composition aborted",
        findings: []
      }));
      continue;
    }
    if (intakeTransport && !intakeAccess.allowed) {
      capabilityResults.push(capabilityResult({
        key: capability,
        status: CAPABILITY_STATUS.SKIPPED,
        reason: "intake access denied before capability execution",
        findings: [],
        trace: {
          intake_access_denied: !0,
          reasons: intakeAccess.reasons
        }
      }));
      continue;
    }
    let capabilityStartedAt = (/* @__PURE__ */ new Date()).toISOString(), executed = await executeCapability({
      capability,
      executor: byCapability.get(capability),
      plan,
      identityResolution,
      intakeTransport,
      signal,
      authorizationContext
    }), capabilityEndedAt = (/* @__PURE__ */ new Date()).toISOString();
    if (capabilityResults.push(executed), typeof executionObserver == "function")
      try {
        executionObserver(Object.freeze({
          type: "capability",
          capability,
          started_at: capabilityStartedAt,
          ended_at: capabilityEndedAt,
          status: executed.status || null,
          owner: executed.owner || null,
          finding_count: Array.isArray(executed.findings) ? executed.findings.length : 0,
          bounded: executed.bounded ? {
            returned_count: executed.bounded.returned_count ?? null,
            total_count: executed.bounded.total_count ?? null,
            truncated: executed.bounded.truncated === !0
          } : null
        }));
      } catch {
      }
    executed.bounded?.truncated && executed.bounded?.continuation && executorNextActions.push({
      action: "continue_bounded_capability",
      capability,
      reason: `bounded window returned ${executed.bounded.returned_count} of ${executed.bounded.total_count}`,
      continuation: executed.bounded.continuation
    });
  }
  let snapshot = resolvedRunSnapshot || {
    generated_at: (/* @__PURE__ */ new Date()).toISOString(),
    context_type: contextType,
    // Output-safe BY-VALUE access descriptor — never the raw authorization context, which used to be
    // copied verbatim into this snapshot and therefore straight into the returned Bundle.
    access: plan.access,
    resolved_identities: identityResolution.identities.map((x) => ({
      key: x.key,
      type: x.type,
      id: x.id,
      ref: x.ref,
      identity_key: x.identity_key,
      source: x.source,
      confidence: x.confidence,
      // Carried so the composition boundary redacts this reduced shape on exactly the same facts it
      // uses for query.identities/plan.identities — otherwise the same identity could be redacted
      // for two different stated reasons in one Bundle.
      access: x.access ? { tier: x.access.tier ?? null } : null
    })),
    requested_capabilities: requested,
    requested_depth: requestedDepth,
    intake_lineage: safeIntakeLineage
  }, resolvedRanking = Array.isArray(ranking) ? ranking : [];
  if (typeof rankingResolver == "function")
    try {
      let projected = await rankingResolver({
        capabilityResults,
        identityResolution,
        plan: outputPlan
      });
      Array.isArray(projected) && (resolvedRanking = projected);
    } catch {
    }
  let baseBundle = composeResearchResultBundle({
    query: {
      raw_input: safeRawInput,
      raw_input_redacted: !!(intakeTransport?.raw_input && safeRawInput == null),
      question: safeQuestion,
      intent,
      identities: identityResolution.identities,
      intake_lineage: safeIntakeLineage
    },
    plan: outputPlan,
    capabilities: capabilityResults,
    ranking: resolvedRanking,
    resolvedRunSnapshot: snapshot,
    nextActions: mergeRazielNextAction(
      [...Array.isArray(nextActions) ? nextActions : [], ...executorNextActions],
      null
    ),
    synthesis: null,
    accessDescriptor: plan.access
  }), withRazielAction = (bundle, synthesis = null) => {
    let action = buildRazielNextAction({
      plan: bundle?.plan || null,
      synthesis,
      coverage: bundle?.coverage || null
    });
    return {
      ...bundle,
      next_actions: mergeRazielNextAction(bundle?.next_actions, action)
    };
  };
  if (typeof synthesizer != "function") return withRazielAction(baseBundle, null);
  try {
    let rawSynthesis = await synthesizer({ bundle: baseBundle, signal }), synthesis = normalizeResearchSynthesis(rawSynthesis, {
      allowedFindingIds: baseBundle.findings.map((x) => x.id),
      frozenAt: baseBundle.resolved_run_snapshot?.generated_at || null,
      sourceBundleContractVersion: baseBundle.contract_version
    });
    return withRazielAction({ ...baseBundle, synthesis }, synthesis);
  } catch (error) {
    let synthesis = failedResearchSynthesis(error, {
      frozenAt: baseBundle.resolved_run_snapshot?.generated_at || null,
      sourceBundleContractVersion: baseBundle.contract_version
    });
    return withRazielAction({ ...baseBundle, synthesis }, synthesis);
  }
}

// src/lib/research/sequenceLens.js
var DEFAULT_SEQUENCE_BUDGET = Object.freeze({ maxSearchDepth: 25e3, maxOccurrences: 25, windowRadius: 12 }), SEQUENCE_REPRESENTATION = Object.freeze({ DIGIT_STREAM: "digit_stream", TERM_SEQUENCE: "term_sequence" }), SEQUENCE_OPERATION = Object.freeze({
  FIRST: "exact_digit_sequence_first_occurrence",
  ALL: "exact_digit_sequence_all_occurrences",
  TERM_FIRST: "exact_term_first_occurrence",
  TERM_ALL: "exact_term_all_occurrences",
  ZECKENDORF: "zeckendorf_decomposition"
});
function positiveInt(value, fallback, max = Number.MAX_SAFE_INTEGER) {
  let n = Number(value);
  return Number.isInteger(n) && n > 0 ? Math.min(n, max) : fallback;
}
function createSequenceRegistry(adapters = []) {
  let registry = /* @__PURE__ */ new Map();
  for (let adapter of adapters) {
    if (!adapter?.sequenceId || typeof adapter.execute != "function") throw new Error("Invalid sequence adapter");
    if (registry.has(adapter.sequenceId)) throw new Error(`Duplicate sequence adapter: ${adapter.sequenceId}`);
    registry.set(adapter.sequenceId, adapter);
  }
  return Object.freeze({
    get: (id) => registry.get(id) || null,
    list: () => [...registry.values()].map(({ execute, ...meta }) => meta)
  });
}
function normalizeSequenceBudget(input = {}, adapter = {}) {
  let adapterMax = positiveInt(adapter.maxSearchDepth, DEFAULT_SEQUENCE_BUDGET.maxSearchDepth);
  return Object.freeze({
    maxSearchDepth: positiveInt(input.maxSearchDepth, Math.min(DEFAULT_SEQUENCE_BUDGET.maxSearchDepth, adapterMax), adapterMax),
    maxOccurrences: positiveInt(input.maxOccurrences, DEFAULT_SEQUENCE_BUDGET.maxOccurrences, 100),
    windowRadius: positiveInt(input.windowRadius, DEFAULT_SEQUENCE_BUDGET.windowRadius, 100)
  });
}
async function runSequenceLens(registry, request = {}) {
  let sequenceId = String(request.sequenceId || "").trim(), adapter = registry?.get?.(sequenceId);
  if (!adapter) return { status: "error", error: "SEQUENCE_ADAPTER_NOT_REGISTERED", sequence_id: sequenceId || null };
  let budget = normalizeSequenceBudget(request.budget, adapter), operation = request.operation || adapter.defaultOperation || null;
  return adapter.execute({ ...request, operation, budget });
}

// src/lib/research/piSequence.js
var SOURCE = Object.freeze({
  id: "pi",
  version: "chudnovsky-bigint-v1",
  algorithm: "Chudnovsky binary splitting + integer sqrt",
  representation: SEQUENCE_REPRESENTATION.DIGIT_STREAM,
  positionConvention: "one_based_after_decimal_excludes_integer_part",
  maxSearchDepth: 25e3
}), C3_OVER_24 = 10939058860032000n, cachedDigits = "";
function isqrt(n) {
  if (n < 0n) throw new Error("square root of negative");
  if (n < 2n) return n;
  let x0 = 1n << (BigInt(n.toString(2).length) + 1n >> 1n), x1 = x0 + n / x0 >> 1n;
  for (; x1 < x0; )
    x0 = x1, x1 = x0 + n / x0 >> 1n;
  return x0;
}
function binarySplit(a, b) {
  if (b - a === 1) {
    let P = 1n, Q = 1n;
    if (a !== 0) {
      let A = BigInt(a);
      P = BigInt(6 * a - 5) * BigInt(2 * a - 1) * BigInt(6 * a - 1), Q = A * A * A * C3_OVER_24;
    }
    let T = P * BigInt(13591409 + 545140134 * a);
    return a & 1 && (T = -T), [P, Q, T];
  }
  let m = Math.floor((a + b) / 2), [P1, Q1, T1] = binarySplit(a, m), [P2, Q2, T2] = binarySplit(m, b);
  return [P1 * P2, Q1 * Q2, T1 * Q2 + P1 * T2];
}
function piDigitsAfterDecimal(depth) {
  let n = Math.max(1, Math.min(Number(depth) || 1, SOURCE.maxSearchDepth));
  if (cachedDigits.length >= n) return cachedDigits.slice(0, n);
  let precision = n + 20, one = 10n ** BigInt(precision), terms = Math.floor(precision / 14) + 2, [, Q, T] = binarySplit(0, terms), sqrtC = isqrt(10005n * one * one);
  return cachedDigits = (Q * 426880n * sqrtC / T).toString().slice(1, 1 + n), cachedDigits;
}
function windowAround(digits, zeroIndex, queryLength, radius) {
  if (zeroIndex < 0) return null;
  let start = Math.max(0, zeroIndex - radius), end = Math.min(digits.length, zeroIndex + queryLength + radius);
  return { start_position: start + 1, end_position: end, digits: digits.slice(start, end) };
}
var piSequenceAdapter = Object.freeze({
  sequenceId: SOURCE.id,
  sequenceVersion: SOURCE.version,
  representationKind: SOURCE.representation,
  positionConvention: SOURCE.positionConvention,
  maxSearchDepth: SOURCE.maxSearchDepth,
  defaultOperation: SEQUENCE_OPERATION.FIRST,
  operations: Object.freeze([SEQUENCE_OPERATION.FIRST, SEQUENCE_OPERATION.ALL]),
  async execute(request = {}) {
    let query = String(request.query ?? "").trim();
    if (!/^\d+$/.test(query)) return { status: "error", error: "QUERY_MUST_BE_DIGITS", sequence_id: "pi" };
    let operation = request.operation || SEQUENCE_OPERATION.FIRST;
    if (![SEQUENCE_OPERATION.FIRST, SEQUENCE_OPERATION.ALL].includes(operation)) return { status: "error", error: "OPERATION_NOT_SUPPORTED", sequence_id: "pi", operation };
    let searchDepth = request.budget?.maxSearchDepth || SOURCE.maxSearchDepth, digits = piDigitsAfterDecimal(searchDepth), firstIndex = digits.indexOf(query), occurrences = [];
    if (operation === SEQUENCE_OPERATION.ALL && firstIndex >= 0) {
      let from = 0;
      for (; occurrences.length < request.budget.maxOccurrences; ) {
        let i = digits.indexOf(query, from);
        if (i < 0) break;
        occurrences.push(i + 1), from = i + 1;
      }
    }
    let found = firstIndex >= 0;
    return {
      status: "ok",
      sequence_id: SOURCE.id,
      sequence_version: SOURCE.version,
      representation_kind: SOURCE.representation,
      query,
      operation,
      position_convention: SOURCE.positionConvention,
      search_depth: searchDepth,
      result: {
        found,
        first_position: found ? firstIndex + 1 : null,
        occurrences: operation === SEQUENCE_OPERATION.ALL ? occurrences : void 0,
        surrounding_window: found ? windowAround(digits, firstIndex, query.length, request.budget?.windowRadius || 12) : null
      },
      verification: { state: "deterministic_computation", algorithm: SOURCE.algorithm, verified: !0 },
      provenance: {
        request_source: request.provenance?.requestSource || null,
        input_ref: request.provenance?.inputRef || null,
        generated_at: request.provenance?.generatedAt || (/* @__PURE__ */ new Date()).toISOString(),
        source: SOURCE
      }
    };
  }
});

// src/lib/research/fibonacciSequence.js
var SOURCE2 = Object.freeze({
  id: "fibonacci",
  version: "iterative-bigint-f1-f2-v2",
  algorithm: "Iterative BigInt Fibonacci generation",
  representation: SEQUENCE_REPRESENTATION.TERM_SEQUENCE,
  positionConvention: "one_based_terms_F1_1_F2_1",
  maxSearchDepth: 1e4
});
function fibonacciTerms(depth) {
  let n = Math.max(1, Math.min(Number(depth) || 1, SOURCE2.maxSearchDepth)), out = [], a = 1n, b = 1n;
  for (let i = 0; i < n; i += 1)
    out.push(a), [a, b] = [b, a + b];
  return out;
}
function termWindow(terms, zeroIndex, radius) {
  if (zeroIndex < 0) return null;
  let start = Math.max(0, zeroIndex - radius), end = Math.min(terms.length, zeroIndex + radius + 1);
  return {
    start_position: start + 1,
    end_position: end,
    terms: terms.slice(start, end).map(String)
  };
}
function zeckendorfDecomposition(input, depth = SOURCE2.maxSearchDepth) {
  let query = String(input ?? "").trim();
  if (!/^\d+$/.test(query)) throw new TypeError("value must be a non-negative integer");
  let remaining = BigInt(query);
  if (remaining === 0n) return { value: "0", terms: [], sum: "0", complete: !0 };
  let terms = fibonacciTerms(depth), parts = [];
  for (let i = terms.length - 1; i >= 0 && remaining > 0n; i -= 1) {
    let term = terms[i];
    term > remaining || (parts.push({ term: term.toString(), index: i + 1 }), remaining -= term, i -= 1);
  }
  return {
    value: query,
    terms: parts,
    sum: parts.reduce((acc, p) => acc + BigInt(p.term), 0n).toString(),
    complete: remaining === 0n,
    remainder: remaining.toString(),
    position_convention: SOURCE2.positionConvention
  };
}
var fibonacciSequenceAdapter = Object.freeze({
  sequenceId: SOURCE2.id,
  sequenceVersion: SOURCE2.version,
  representationKind: SOURCE2.representation,
  positionConvention: SOURCE2.positionConvention,
  maxSearchDepth: SOURCE2.maxSearchDepth,
  defaultOperation: SEQUENCE_OPERATION.TERM_FIRST,
  operations: Object.freeze([SEQUENCE_OPERATION.TERM_FIRST, SEQUENCE_OPERATION.TERM_ALL, SEQUENCE_OPERATION.ZECKENDORF]),
  async execute(request = {}) {
    let query = String(request.query ?? "").trim();
    if (!/^\d+$/.test(query)) return { status: "error", error: "QUERY_MUST_BE_NON_NEGATIVE_INTEGER", sequence_id: SOURCE2.id };
    let target = BigInt(query), operation = request.operation || SEQUENCE_OPERATION.TERM_FIRST;
    if (![SEQUENCE_OPERATION.TERM_FIRST, SEQUENCE_OPERATION.TERM_ALL, SEQUENCE_OPERATION.ZECKENDORF].includes(operation))
      return { status: "error", error: "OPERATION_NOT_SUPPORTED", sequence_id: SOURCE2.id, operation };
    let searchDepth = request.budget?.maxSearchDepth || SOURCE2.maxSearchDepth;
    if (operation === SEQUENCE_OPERATION.ZECKENDORF) {
      let decomposition = zeckendorfDecomposition(query, searchDepth);
      return {
        status: "ok",
        sequence_id: SOURCE2.id,
        sequence_version: SOURCE2.version,
        representation_kind: SOURCE2.representation,
        query,
        operation,
        position_convention: SOURCE2.positionConvention,
        search_depth: searchDepth,
        result: { found: decomposition.complete, decomposition },
        verification: { state: "deterministic_computation", algorithm: SOURCE2.algorithm, verified: decomposition.complete },
        provenance: {
          request_source: request.provenance?.requestSource || null,
          input_ref: request.provenance?.inputRef || null,
          generated_at: request.provenance?.generatedAt || (/* @__PURE__ */ new Date()).toISOString(),
          source: SOURCE2
        }
      };
    }
    let terms = fibonacciTerms(searchDepth), occurrences = [];
    for (let i = 0; i < terms.length && !(terms[i] === target && (occurrences.push(i + 1), operation === SEQUENCE_OPERATION.TERM_FIRST || occurrences.length >= (request.budget?.maxOccurrences || 25)) || terms[i] > target && target > 1n); i += 1)
      ;
    let firstPosition = occurrences[0] ?? null;
    return {
      status: "ok",
      sequence_id: SOURCE2.id,
      sequence_version: SOURCE2.version,
      representation_kind: SOURCE2.representation,
      query,
      operation,
      position_convention: SOURCE2.positionConvention,
      search_depth: searchDepth,
      result: {
        found: firstPosition !== null,
        first_position: firstPosition,
        occurrences: operation === SEQUENCE_OPERATION.TERM_ALL ? occurrences : void 0,
        surrounding_window: firstPosition ? termWindow(terms, firstPosition - 1, request.budget?.windowRadius || 12) : null
      },
      verification: { state: "deterministic_computation", algorithm: SOURCE2.algorithm, verified: !0 },
      provenance: {
        request_source: request.provenance?.requestSource || null,
        input_ref: request.provenance?.inputRef || null,
        generated_at: request.provenance?.generatedAt || (/* @__PURE__ */ new Date()).toISOString(),
        source: SOURCE2
      }
    };
  }
});

// src/lib/research/numericResearchBase.js
var DEFAULT_NUMERIC_RESEARCH_BUDGET = Object.freeze({
  depth: 2,
  maxLenses: 8,
  sequence: Object.freeze({ maxSearchDepth: 25e3, maxOccurrences: 25, windowRadius: 12 })
}), DEFAULT_PRIORITY_WEIGHTS = Object.freeze({
  convergence: 1,
  engineVerified: 1,
  sourceDiversity: 1,
  relationEvidence: 1,
  openQuestions: 1,
  hotContext: 1
}), NUMERIC_LENS_STATUS = Object.freeze({ READY: "READY", ADAPTER_NEEDED: "ADAPTER_NEEDED" }), DEFAULT_SEQUENCE_ADAPTERS = Object.freeze([piSequenceAdapter, fibonacciSequenceAdapter]), NUMERIC_LENS_ACCESS_CLASS = Object.freeze({
  PUBLIC_SOURCE: "public_source",
  SOURCE_ACCESS_CONTROLLED: "source_access_controlled",
  // SECURITY DEFINER RPC that is anon/authenticated EXECUTABLE but reads tables the caller has no
  // grant on, so it elevates privilege on the caller's behalf. Executability proves nothing about
  // publication authority (truth_axes_foundation_law v3 INVARIANT P3: a row readable through a
  // grant is an ACCESS FACT, not a publication decision — a missing gate is not consent).
  DEFINER_ELEVATED: "definer_elevated",
  SERVER_ONLY: "server_only",
  LOCAL_COMPUTATION: "local_computation"
}), NUMERIC_LENS_SEMANTIC_CLASS = Object.freeze({
  EVIDENCE: "evidence",
  DERIVATION: "derivation",
  CONTEXT: "context",
  PROJECTION: "projection",
  RANKING: "ranking"
}), LC = NUMERIC_LENS_ACCESS_CLASS, SC = NUMERIC_LENS_SEMANTIC_CLASS, numericLensMap = Object.freeze({
  number_lookup: { status: NUMERIC_LENS_STATUS.READY, rpc: "fn_number_lookup", access_class: LC.PUBLIC_SOURCE, client_executable: !0, semantic_class: SC.EVIDENCE, emits_findings: !0 },
  // RECLASSIFIED (GPT challenge 8621de8d finding 3, accepted and independently reverified).
  // fn_number_dossier is STABLE SECURITY DEFINER and anon/auth executable, but it returns
  // decision_ledger human_reason/reason_code/provenance, research_candidates, learned_patterns,
  // relation_evidence including rejected/candidate rows, and topic_cards UNFILTERED BY STATUS —
  // while decision_ledger, research_candidates, learned_patterns, topic_cards and convergences all
  // have anon_select=false AND auth_select=false live. Calling it PUBLIC_SOURCE inferred publication
  // authority from EXECUTE privilege, which INVARIANT P3 forbids. It stays dispatchable (it is the
  // live dossier contract and produces no Findings) but is no longer treated as public material,
  // and its payload never enters the capability trace.
  number_dossier: { status: NUMERIC_LENS_STATUS.READY, rpc: "fn_number_dossier", access_class: LC.DEFINER_ELEVATED, client_executable: !0, publication_authorized: !1, semantic_class: SC.CONTEXT, emits_findings: !1, reason: "SECURITY DEFINER over decision_ledger/research_candidates/learned_patterns/topic_cards, none of which grant anon or authenticated SELECT; composite of several truth families \u2014 context, never one atomic evidence fact, and never public material" },
  // Same shape, found while reverifying finding 3 and NOT in the GPT report: fn_number_journey is
  // SECURITY DEFINER and returns journey_seeds status/readiness/title while journey_seeds grants no
  // anon/auth SELECT. Less sensitive than the dossier, same classification error.
  number_journey: { status: NUMERIC_LENS_STATUS.READY, rpc: "fn_number_journey", access_class: LC.DEFINER_ELEVATED, client_executable: !0, publication_authorized: !1, semantic_class: SC.PROJECTION, emits_findings: !1, reason: "SECURITY DEFINER exposing journey_seeds draft/readiness state which grants no anon or authenticated SELECT; derivation/projection map, not positive evidence" },
  neighbors: { status: NUMERIC_LENS_STATUS.READY, rpc: "number_neighbors", access_class: LC.PUBLIC_SOURCE, client_executable: !0, semantic_class: SC.RANKING, emits_findings: !1, reason: "proximity/weight signal \u2014 ranking, not truth" },
  // anon_exec=false AND auth_exec=false live: only a service-role/server caller can execute this.
  hot_context: { status: NUMERIC_LENS_STATUS.READY, rpc: "fn_hot_context", access_class: LC.SERVER_ONLY, client_executable: !1, semantic_class: SC.RANKING, emits_findings: !1, reason: "SECURITY DEFINER with no anon/authenticated execute; returns hot candidate context and HOT is explicitly not TRUE" },
  research_objects: { status: NUMERIC_LENS_STATUS.READY, source: "research_objects", access_class: LC.SOURCE_ACCESS_CONTROLLED, client_executable: !1, semantic_class: SC.EVIDENCE, emits_findings: !0, reason: "no anon/authenticated table grant; requires an injected access-filtered reader and composition-boundary filtering" },
  relation_candidates: { status: NUMERIC_LENS_STATUS.ADAPTER_NEEDED, reason: "fn_relation_candidate requires two semantic endpoints, not a number-only input" },
  cross_resonance: { status: NUMERIC_LENS_STATUS.ADAPTER_NEEDED, reason: "number_cross_resonance requires p_self + p_pairs contract" },
  source_post_context: { status: NUMERIC_LENS_STATUS.ADAPTER_NEEDED, reason: "no single canonical number-only source/post RPC" },
  els: { status: NUMERIC_LENS_STATUS.ADAPTER_NEEDED, reason: "ELS native adapter exists for Universal Findings, but no safe number-only dispatch contract" },
  // A LOGICAL ALIAS, not a lens of its own: it dispatches number_lookup + number_dossier and owns no
  // RPC, no row and no per-lens result. It must never be reported as if it executed something itself.
  gematria_reverse: { status: NUMERIC_LENS_STATUS.READY, alias_of: ["number_lookup", "number_dossier"], is_logical_alias: !0, via: "fn_number_lookup/fn_number_dossier; do not recalculate in router", access_class: LC.PUBLIC_SOURCE, client_executable: !0, semantic_class: SC.EVIDENCE, emits_findings: !1, reason: "alias \u2014 findings and context come from the two lenses it dispatches" },
  "sequence:pi": { status: NUMERIC_LENS_STATUS.READY, sequence_id: "pi", access_class: LC.LOCAL_COMPUTATION, client_executable: !0, semantic_class: SC.EVIDENCE, emits_findings: !0 },
  "sequence:fibonacci": { status: NUMERIC_LENS_STATUS.READY, sequence_id: "fibonacci", access_class: LC.LOCAL_COMPUTATION, client_executable: !0, semantic_class: SC.EVIDENCE, emits_findings: !0 }
});
function normalizeBudget(input = {}) {
  return {
    depth: Math.min(2, Number.isInteger(input.depth) && input.depth > 0 ? input.depth : DEFAULT_NUMERIC_RESEARCH_BUDGET.depth),
    maxLenses: Math.min(12, Number.isInteger(input.maxLenses) && input.maxLenses > 0 ? input.maxLenses : DEFAULT_NUMERIC_RESEARCH_BUDGET.maxLenses),
    sequence: { ...DEFAULT_NUMERIC_RESEARCH_BUDGET.sequence, ...input.sequence || {} }
  };
}
async function rpcCall(rpc, name, args) {
  if (typeof rpc != "function") return { status: "adapter_needed", error: "RPC_EXECUTOR_NOT_PROVIDED", rpc: name };
  try {
    let out = await rpc(name, args);
    return out?.error ? { status: "error", error: out.error.message || String(out.error), rpc: name } : { status: "ok", data: out?.data ?? out, rpc: name };
  } catch (error) {
    return { status: "error", error: error?.message || String(error), rpc: name };
  }
}
function sequenceUniversalFinding(number, sequenceFinding) {
  return !sequenceFinding || sequenceFinding.status !== "ok" ? null : makeUniversalFinding({
    kind: "sequence",
    // stage deliberately NOT set here — see reconciliation note at the top of this file
    // (INVARIANT PR1: a projection adapter does not own epistemic type).
    subject: { type: "number", key: String(number), label: String(number), value: number },
    source: { engine: "sequence", adapter: "sequence-lens-v1", sourceRef: `${sequenceFinding.sequence_id}:${sequenceFinding.sequence_version || "adapter"}`, method: sequenceFinding.operation || null, corpus: null },
    identity: { sourceIdentity: `${sequenceFinding.sequence_id}:${sequenceFinding.operation || "operation"}:${sequenceFinding.query ?? number}:${sequenceFinding.result?.first_position ?? "not-found"}@${sequenceFinding.search_depth ?? "bounded"}` },
    // HG-3, same pattern as canonicalGematria.js/elsStateToUniversalFindings: no claim was
    // submitted for this deterministic computation, so nothing was "matched" — the honest
    // state is "not_tested", declared explicitly because the adapter genuinely knows it, while
    // the engine's own output is fully recorded below.
    verification: {
      claimed_expression: null,
      claimed_method: null,
      claimed_value: null,
      engine_method_tested: sequenceFinding.sequence_id,
      engine_result: sequenceFinding.result,
      verification_state: "not_tested"
    },
    evidence: { facts: [{ type: "sequence-search", sequence_id: sequenceFinding.sequence_id, query: sequenceFinding.query ?? String(number), operation: sequenceFinding.operation || null, position_convention: sequenceFinding.position_convention || null, search_depth: sequenceFinding.search_depth ?? null, result: sequenceFinding.result, verification: sequenceFinding.verification || null }] },
    provenance: { createdBy: "ENGINE:sequence", createdAt: sequenceFinding.provenance?.generated_at || (/* @__PURE__ */ new Date()).toISOString(), inputRef: sequenceFinding.provenance?.input_ref || null },
    projection: { dimensions: { sequence_id: sequenceFinding.sequence_id, representation_kind: sequenceFinding.representation_kind || null } }
  });
}
function relationCandidate(number, sequenceFinding, positionContext, universalFinding) {
  let pos = sequenceFinding?.result?.first_position;
  return pos == null ? null : {
    stage: "candidate",
    type: "sequence_position_context",
    from: { type: "number", value: number },
    to: { type: "number", value: pos },
    relation: "occurs_at_sequence_position",
    sequence_id: sequenceFinding.sequence_id,
    verification: sequenceFinding.verification || null,
    evidence: { finding_id: universalFinding?.id || null, sequence_finding: sequenceFinding, position_context: positionContext || null },
    canonical: !1,
    published: !1
  };
}
function derivedNumericRoot(number, sequenceFinding, positionContext, universalFinding) {
  let value = sequenceFinding?.result?.first_position;
  return value == null ? null : {
    stage: "candidate",
    type: "derived_numeric_root",
    root: { type: "number", value },
    traversable: !0,
    derivation: {
      from: { type: "number", value: number },
      lens: `sequence:${sequenceFinding.sequence_id}`,
      operation: sequenceFinding.operation || null,
      relation: "sequence_position"
    },
    verification: sequenceFinding.verification || null,
    provenance: {
      finding_id: universalFinding?.id || null,
      sequence_id: sequenceFinding.sequence_id,
      sequence_version: sequenceFinding.sequence_version || null,
      position_convention: sequenceFinding.position_convention || null,
      search_depth: sequenceFinding.search_depth ?? null
    },
    context: positionContext || null,
    canonical: !1,
    published: !1
  };
}
function deriveNumericResearchPriority({ dossier, researchObjects = [], hotContext = null, weights = {} } = {}) {
  let signals = {
    convergence_count: dossier?.facts?.convergences?.length || 0,
    engine_verified_findings: researchObjects.filter((x) => x?.engine_verified === !0).length,
    source_diversity: new Set(researchObjects.map((x) => x?.source).filter(Boolean)).size,
    relation_evidence: dossier?.evidence?.length || 0,
    open_questions: researchObjects.filter((x) => x?.kind === "question" && x?.status !== "dismissed").length,
    hot_context_signal: Math.max(0, Number(hotContext?.score || hotContext?.priority || 0) || 0)
  }, w = { ...DEFAULT_PRIORITY_WEIGHTS, ...weights };
  return {
    score: signals.convergence_count * w.convergence + signals.engine_verified_findings * w.engineVerified + signals.source_diversity * w.sourceDiversity + signals.relation_evidence * w.relationEvidence + signals.open_questions * w.openQuestions + signals.hot_context_signal * w.hotContext,
    rank_basis: signals,
    weights: w,
    policy: "router_local_configurable_v1_not_canonical",
    truth_status: "NOT_A_TRUTH_SIGNAL"
  };
}
var DEFAULT_NUMBER_LOOKUP_WINDOW = Object.freeze({ limit: 50, maxLimit: 500 });
function orderNumberLookupRowsGovernedFirst(rows) {
  let rank = (row) => [
    row?.method_governed === !0 ? 0 : 1,
    clean10(row?.atomic_or_composite) === "composite" ? 1 : 0,
    clean10(row?.method) || "",
    clean10(row?.phrase) || "",
    clean10(row?.bid_id) || ""
  ];
  return [...Array.isArray(rows) ? rows : []].sort((a, b) => {
    let ra = rank(a), rb = rank(b);
    for (let i = 0; i < ra.length; i++)
      if (ra[i] !== rb[i])
        return ra[i] < rb[i] ? -1 : 1;
    return 0;
  });
}
function boundNumberLookupRows(rows, { limit, afterBidId = null, offset = 0 } = {}) {
  let ordered = orderNumberLookupRowsGovernedFirst(rows), total = ordered.length, size = Math.max(1, Math.min(Number(limit) || DEFAULT_NUMBER_LOOKUP_WINDOW.limit, DEFAULT_NUMBER_LOOKUP_WINDOW.maxLimit)), start = Number.isSafeInteger(Number(offset)) && Number(offset) > 0 ? Number(offset) : 0;
  if (afterBidId) {
    let at = ordered.findIndex((row) => clean10(row?.bid_id) === clean10(afterBidId));
    start = at >= 0 ? at + 1 : start;
  }
  let window = ordered.slice(start, start + size), lastBidId = window.length ? clean10(window[window.length - 1]?.bid_id) : null, consumed = start + window.length, truncated = consumed < total;
  return {
    rows: window,
    bounded: {
      total_count: total,
      returned_count: window.length,
      truncated,
      window: { limit: size, offset: start, after_bid_id: afterBidId || null },
      ordering: "governed_first__then_atomic_before_composite__then_method__phrase__bid_id",
      continuation: truncated ? { lens: "number_lookup", after_bid_id: lastBidId, offset: consumed, limit: size, remaining: total - consumed } : null,
      // Stated so no downstream reader can mistake a window for the whole source population.
      source_exhaustive: !truncated
    }
  };
}
async function researchNumber(numberInput, options = {}) {
  let number = Number(numberInput);
  if (!Number.isSafeInteger(number) || number < 0) throw new Error("number must be a non-negative safe integer");
  let budget = normalizeBudget(options.budget), requested = (options.lenses?.length ? options.lenses : ["number_lookup", "number_dossier", "research_objects", "sequence:pi"]).slice(0, budget.maxLenses), perLens = {}, rpc = options.rpc, lookupBounds = null, wantsLookup = requested.includes("number_lookup") || requested.includes("gematria_reverse"), wantsDossier = requested.includes("number_dossier") || requested.includes("gematria_reverse"), wantsJourney = requested.includes("number_journey"), wantsNeighbors = requested.includes("neighbors"), wantsHotContext = requested.includes("hot_context"), wantsResearchObjects = requested.includes("research_objects"), [lookup, dossierResult, journeyResult, neighborsResult, hotContextResult, researchObjectsResult] = await Promise.all([
    wantsLookup ? rpcCall(rpc, "fn_number_lookup", { p_value: number }) : null,
    wantsDossier ? rpcCall(rpc, "fn_number_dossier", { p_value: number }) : null,
    wantsJourney ? rpcCall(rpc, "fn_number_journey", { p_value: number }) : null,
    wantsNeighbors ? rpcCall(rpc, "number_neighbors", { p_value: number, p_limit: Math.min(25, options.neighborLimit || 12) }) : null,
    wantsHotContext ? rpcCall(rpc, "fn_hot_context", { p_values: [number], p_scope: options.scope || "numeric-router-v1" }) : null,
    wantsResearchObjects ? typeof options.fetchResearchObjects == "function" ? options.fetchResearchObjects(number, { limit: Math.min(50, options.researchObjectLimit || 25) }) : Promise.resolve({ status: "adapter_needed", error: "RESEARCH_OBJECT_FETCHER_NOT_PROVIDED" }) : null
  ]);
  if (lookup)
    if (lookup.status === "ok" && Array.isArray(lookup.data)) {
      let { rows, bounded } = boundNumberLookupRows(lookup.data, options.lookupWindow || {});
      lookupBounds = bounded, perLens.number_lookup = { ...lookup, data: rows, bounded };
    } else
      perLens.number_lookup = lookup;
  dossierResult && (perLens.number_dossier = dossierResult), journeyResult && (perLens.number_journey = journeyResult), neighborsResult && (perLens.neighbors = neighborsResult), hotContextResult && (perLens.hot_context = hotContextResult), researchObjectsResult && (perLens.research_objects = researchObjectsResult);
  for (let id of requested.filter((id2) => numericLensMap[id2]?.status === NUMERIC_LENS_STATUS.ADAPTER_NEEDED)) perLens[id] = { status: "adapter_needed", ...numericLensMap[id] };
  let registry = createSequenceRegistry([...DEFAULT_SEQUENCE_ADAPTERS, ...options.sequenceAdapters || []]), sequenceLensIds = requested.filter((id) => id.startsWith("sequence:")), universalFindings = [];
  Array.isArray(perLens.number_lookup?.data) && universalFindings.push(...numberLookupRowsToUniversalFindings(perLens.number_lookup.data, { requestedValue: number }));
  let relationCandidates = [], derivedNumericRoots = [];
  for (let lensId of sequenceLensIds) {
    let sequenceId = lensId.slice(9), sequenceFinding = await runSequenceLens(registry, {
      sequenceId,
      query: String(number),
      operation: options.sequenceOperations?.[sequenceId] || options.sequenceOperation,
      budget: budget.sequence,
      provenance: options.provenance
    });
    perLens[lensId] = sequenceFinding;
    let universalFinding = sequenceUniversalFinding(number, sequenceFinding);
    universalFinding && universalFindings.push(universalFinding);
    let positionContext = null;
    budget.depth >= 2 && sequenceFinding?.result?.first_position != null && (positionContext = await rpcCall(rpc, "fn_number_lookup", { p_value: sequenceFinding.result.first_position }), perLens[`${lensId}:position_context`] = positionContext);
    let candidate = relationCandidate(number, sequenceFinding, positionContext, universalFinding);
    candidate && relationCandidates.push(candidate);
    let derivedRoot = derivedNumericRoot(number, sequenceFinding, positionContext, universalFinding);
    derivedRoot && derivedNumericRoots.push(derivedRoot);
  }
  let objects = Array.isArray(perLens.research_objects?.data) ? perLens.research_objects.data : Array.isArray(perLens.research_objects) ? perLens.research_objects : [], dossier = perLens.number_dossier?.data || null, hotContext = perLens.hot_context?.data || null;
  return {
    v: 1,
    root: { type: "number", value: number },
    context: options.context || null,
    requested_lenses: requested,
    budget,
    per_lens: perLens,
    bounds: { number_lookup: lookupBounds },
    universal_findings: universalFindings,
    relation_candidates: relationCandidates,
    derived_numeric_roots: derivedNumericRoots,
    priority: deriveNumericResearchPriority({ dossier, researchObjects: objects, hotContext, weights: options.priorityWeights }),
    provenance: { request_source: options.provenance?.requestSource || null, input_ref: options.provenance?.inputRef || null },
    truth_lifecycle: { automatic_canonical_promotion: !1, automatic_publication: !1, human_gate_required: !0 }
  };
}
function clean10(value) {
  return value == null ? null : String(value).trim() || null;
}
var LOOKUP_ACCESS_REASON = "canonical Number lookup contract behind the public /number surface; non-definer and restricted to is_verified rows";
function lookupIdentity(row) {
  let bidId = clean10(row?.bid_id);
  if (bidId) return { key: bidId, sourceIdentity: { bidId, table: "bidim" }, keyed_on: "bid_id" };
  let composite = [clean10(row?.word_id), clean10(row?.method), row?.value ?? null].filter((v) => v != null).join("|");
  return composite ? {
    key: `bidim-composite:${composite}`,
    sourceIdentity: { table: "bidim", wordId: clean10(row?.word_id), method: clean10(row?.method), value: row?.value ?? null, bidId: null },
    keyed_on: "composite_fallback_bid_id_absent"
  } : null;
}
function lookupVerification(row) {
  let method = clean10(row?.method), value = row?.value ?? null;
  return row?.verified_mismatch_value != null ? {
    claimed_expression: clean10(row?.phrase),
    claimed_method: method,
    claimed_value: value,
    engine_method_tested: method,
    engine_result: row.verified_mismatch_value,
    statement_lang: "he",
    verification_state: "mismatch"
  } : row?.verified_at != null ? {
    claimed_expression: clean10(row?.phrase),
    claimed_method: method,
    claimed_value: value,
    engine_method_tested: method,
    engine_result: value,
    statement_lang: "he",
    verification_state: "match"
  } : clean10(row?.row_provenance_state) === "governed" && clean10(row?.engine_run_id) ? {
    claimed_expression: null,
    claimed_method: null,
    claimed_value: null,
    engine_method_tested: method,
    engine_result: value,
    statement_lang: null,
    verification_state: "not_tested"
  } : {
    claimed_expression: null,
    claimed_method: null,
    claimed_value: null,
    engine_method_tested: method,
    engine_result: value,
    statement_lang: null,
    verification_state: null
  };
}
function numberLookupRowToUniversalFinding(row, { requestedValue = null } = {}) {
  let method = clean10(row?.method), phrase = clean10(row?.phrase), value = row?.value ?? requestedValue ?? null;
  if (!method || !phrase || value == null) return null;
  let identity = lookupIdentity(row);
  if (!identity) return null;
  let nodeId = clean10(row?.node_id), provenanceState = clean10(row?.row_provenance_state);
  return makeUniversalFinding({
    kind: "gematria",
    // INVARIANT PR1 — epistemic type stays a Human-Gate decision.
    stage: null,
    // AXIS 3 GOVERNANCE — honestly null. A bidim row carries no Human-Gate acceptance state, and
    // provenance_state is NOT one (see the note above). It travels on the provenance axis instead.
    status: null,
    // Source-native subject: the row is a statement about a PHRASE. The number is the query, and is
    // carried as an anchor/dimension so the Finding still joins the number's lens.
    subject: { type: "phrase", key: phrase, label: phrase, value: Number(value), lang: "he" },
    source: {
      engine: "gematria",
      adapter: "number-lookup-v1",
      sourceRef: identity.sourceIdentity.bidId ? `bidim:${identity.sourceIdentity.bidId}` : null,
      method,
      corpus: null,
      lang: "he"
    },
    identity: {
      sourceIdentity: identity.sourceIdentity,
      occurrence: null,
      entityRef: nodeId ? `node:${nodeId}` : null,
      relationRef: null
    },
    verification: lookupVerification(row),
    evidence: {
      refs: identity.sourceIdentity.bidId ? [`bidim:${identity.sourceIdentity.bidId}`] : [],
      facts: [{
        type: "gematria-lookup-row",
        method,
        phrase,
        value: Number(value),
        method_version: row?.method_version ?? null,
        provenance_state: provenanceState,
        engine_run_id: clean10(row?.engine_run_id),
        computed_at: row?.computed_at ?? null,
        dependency_version_snapshot: row?.dependency_version_snapshot ?? null,
        verified_run_id: clean10(row?.verified_run_id),
        verified_at: row?.verified_at ?? null,
        verified_method_version: row?.verified_method_version ?? null,
        verified_mismatch_value: row?.verified_mismatch_value ?? null
      }],
      score: null,
      confidence: null
    },
    // The source contract itself is public, so this is a fact about the source, not a fabricated
    // publication claim. It is what lets the composition-boundary access filter pass the row.
    access: { tier: "public", reason: LOOKUP_ACCESS_REASON },
    provenance: {
      createdBy: provenanceState === "governed" ? "ENGINE:gematria" : null,
      createdAt: row?.computed_at || row?.verified_at || void 0,
      inputRef: `number:${Number(value)}`,
      // The row's computation/verification history lives HERE, on the provenance axis — not on the
      // governance axis. Named explicitly so no consumer re-reads it as a Human-Gate state.
      rowProvenanceState: provenanceState,
      engineRunId: clean10(row?.engine_run_id),
      verifiedRunId: clean10(row?.verified_run_id)
    },
    projection: {
      anchors: [{ space: "number", value: Number(value) }],
      relations: [],
      dimensions: {
        numberLookup: {
          value: Number(value),
          method,
          identityKeyedOn: identity.keyed_on,
          methodGoverned: row?.method_governed ?? null,
          methodActive: row?.method_active ?? null,
          methodScannable: row?.method_scannable ?? null,
          methodExecutable: row?.method_executable ?? null,
          methodEngineVerified: row?.method_engine_verified ?? null,
          methodEvidenceClass: clean10(row?.method_evidence_class),
          mathematicalFamily: clean10(row?.mathematical_family),
          atomicOrComposite: clean10(row?.atomic_or_composite),
          provenanceState
        }
      }
    },
    view: { rendererHints: { role: "number-lookup-row" } }
  });
}
function numberLookupRowsToUniversalFindings(rows, options = {}) {
  return (Array.isArray(rows) ? rows : []).map((row) => numberLookupRowToUniversalFinding(row, options)).filter(Boolean);
}

// src/lib/research/numericResearch.js
function clean11(value) {
  return value == null ? null : String(value).trim() || null;
}
function normalizedLookupWindow(input = {}) {
  return {
    limit: Math.max(1, Math.min(
      Number(input.limit) || DEFAULT_NUMBER_LOOKUP_WINDOW.limit,
      DEFAULT_NUMBER_LOOKUP_WINDOW.maxLimit
    )),
    afterBidId: clean11(input.afterBidId ?? input.after_bid_id)
  };
}
function serverBoundedFromRows(rows, window, legacyBounded = null, transportFallback = !1) {
  let list = Array.isArray(rows) ? rows : [], serverTotalRaw = (list[0] || null)?.total_count, legacyTotalRaw = legacyBounded?.total_count, total = serverTotalRaw != null ? Number(serverTotalRaw) : legacyTotalRaw != null ? Number(legacyTotalRaw) : window.afterBidId ? null : list.length, returned = list.length, truncated = window.afterBidId ? returned === window.limit : Number.isFinite(total) ? returned < total : returned === window.limit, lastBidId = returned ? clean11(list[returned - 1]?.bid_id) : null;
  return {
    total_count: Number.isFinite(total) ? total : null,
    returned_count: returned,
    truncated,
    window: {
      limit: window.limit,
      after_bid_id: window.afterBidId,
      // Honest transport: a legacy fallback is NOT server paging and must not be reported as if
      // the rows had been bounded before they crossed the wire.
      transport: transportFallback ? "client_window_legacy_fallback" : serverTotalRaw != null ? "server_keyset" : "server_keyset_compat_fallback"
    },
    ordering: "governed_first__then_atomic_before_composite__then_method__phrase__bid_id",
    continuation: truncated && lastBidId ? {
      lens: "number_lookup",
      after_bid_id: lastBidId,
      limit: window.limit,
      remaining: window.afterBidId ? null : Number.isFinite(total) ? Math.max(0, total - returned) : null
    } : null,
    source_exhaustive: !truncated
  };
}
async function researchNumber2(numberInput, options = {}) {
  let originalRpc = options.rpc, window = normalizedLookupWindow(options.lookupWindow || {}), transportFallback = !1, looksLikeMissingOverload = (error) => {
    if (!error) return !1;
    let code = String(error.code || ""), message = String(error.message || error);
    return code === "PGRST202" || /could not find the function/i.test(message) || /function .* does not exist/i.test(message);
  }, result = await researchNumber(numberInput, {
    ...options,
    rpc: typeof originalRpc != "function" ? originalRpc : async (name, args) => {
      if (name !== "fn_number_lookup") return originalRpc(name, args);
      let legacyArgs = { ...args || {} };
      if (transportFallback) return originalRpc(name, legacyArgs);
      let paged;
      try {
        paged = await originalRpc(name, {
          ...legacyArgs,
          p_limit: window.limit,
          p_after_bid_id: window.afterBidId
        });
      } catch (error) {
        if (!looksLikeMissingOverload(error)) throw error;
        return transportFallback = !0, originalRpc(name, legacyArgs);
      }
      return paged?.error && looksLikeMissingOverload(paged.error) ? (transportFallback = !0, originalRpc(name, legacyArgs)) : paged;
    },
    // The base router still applies its deterministic order/window as a defensive second boundary.
    // Since the real server now returns <= limit rows and excludes the cursor row, this does not
    // refetch or widen anything. For legacy/mock readers that ignore the new args, the base window
    // continues to protect memory and its total_count is preserved below.
    lookupWindow: { limit: window.limit, afterBidId: window.afterBidId }
  }), lookup = result?.per_lens?.number_lookup;
  if (lookup?.status === "ok" && Array.isArray(lookup.data)) {
    let legacyBounded = result?.bounds?.number_lookup || lookup.bounded || null, bounded = serverBoundedFromRows(lookup.data, window, legacyBounded, transportFallback);
    lookup.bounded = bounded, result.bounds = { ...result.bounds || {}, number_lookup: bounded };
  }
  return result;
}

// src/lib/research/researchObjectPresentation.js
function clean12(value) {
  return value == null ? null : String(value).trim() || null;
}
function objectValue(value) {
  return value && typeof value == "object" && !Array.isArray(value) ? value : {};
}
var HEBREW_KIND_LABEL = Object.freeze({
  fact: "\u05DE\u05DE\u05E6\u05D0 \u05DE\u05E1\u05D5\u05D2 \u05E2\u05D5\u05D1\u05D3\u05D4",
  relation: "\u05E7\u05E9\u05E8 \u05DE\u05D7\u05E7\u05E8\u05D9",
  observation: "\u05EA\u05E6\u05E4\u05D9\u05EA",
  hypothesis: "\u05D4\u05E9\u05E2\u05E8\u05D4",
  question: "\u05E9\u05D0\u05DC\u05EA \u05DE\u05D7\u05E7\u05E8",
  calculation: "\u05D7\u05D9\u05E9\u05D5\u05D1",
  interpretation: "\u05E4\u05E8\u05E9\u05E0\u05D5\u05EA"
}), SOURCE_LABELS = Object.freeze({
  research_triage: "\u05DE\u05D9\u05D5\u05DF \u05DE\u05D7\u05E7\u05E8 \u05E4\u05E0\u05D9\u05DE\u05D9",
  channel_updates: "\u05D4\u05D5\u05D3\u05E2\u05D5\u05EA \u05DE\u05E7\u05D5\u05E8",
  wordpress: "\u05E4\u05D5\u05E1\u05D8 \u05DE\u05E7\u05D5\u05E8",
  posts: "\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD",
  gematria_engine: "\u05DE\u05E0\u05D5\u05E2 \u05D4\u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D4",
  "canonical Gematria Engine + post 5112": "\u05DE\u05E0\u05D5\u05E2 \u05D4\u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D4 + \u05E4\u05D5\u05E1\u05D8 \u05D4\u05DE\u05D8\u05D5\u05E1",
  video_semantic_map: "\u05DE\u05E4\u05EA \u05EA\u05D5\u05DB\u05DF \u05D5\u05D9\u05D3\u05D0\u05D5",
  family_input: "\u05DE\u05D9\u05D3\u05E2 \u05DE\u05E9\u05E4\u05D7\u05EA\u05D9",
  uploaded_docx: "\u05DE\u05E1\u05DE\u05DA \u05E9\u05D4\u05D5\u05E2\u05DC\u05D4 \u05DC\u05DE\u05D7\u05E7\u05E8",
  root_gate_repair: "\u05D1\u05D3\u05D9\u05E7\u05EA \u05EA\u05D9\u05E7\u05D5\u05DF \u05DE\u05E2\u05E8\u05DB\u05EA",
  pre_els_finite_closure: "\u05DE\u05D7\u05E7\u05E8 \u05D4\u05DB\u05E0\u05D4 \u05DC\u05E6\u05E4\u05E0\u05D9\u05DD",
  ranked_enrichment_pilot_v1: "\u05E4\u05D9\u05D9\u05DC\u05D5\u05D8 \u05D4\u05E2\u05E9\u05E8\u05EA \u05DE\u05D7\u05E7\u05E8",
  amit_existing_corpus_stress_test: "\u05E7\u05D5\u05E8\u05E4\u05D5\u05E1 \u05E2\u05DE\u05D9\u05EA \u2014 \u05D1\u05D3\u05D9\u05E7\u05EA \u05E2\u05D5\u05DE\u05E1",
  "SOD1820 research synthesis": "\u05E1\u05D9\u05E0\u05EA\u05D6\u05EA \u05DE\u05D7\u05E7\u05E8 \u05E9\u05DC \u05E1\u05D5\u05D3 1820",
  zuriel_research_corpus: "\u05E7\u05D5\u05E8\u05E4\u05D5\u05E1 \u05D4\u05DE\u05D7\u05E7\u05E8 \u05E9\u05DC \u05E6\u05D5\u05E8\u05D9\u05D0\u05DC",
  zuriel_live_interview: "\u05E8\u05D0\u05D9\u05D5\u05DF \u05DE\u05D7\u05E7\u05E8 \u05D7\u05D9 \u05E2\u05DD \u05E6\u05D5\u05E8\u05D9\u05D0\u05DC",
  "Zuriel live interview + historical corpus": "\u05E8\u05D0\u05D9\u05D5\u05DF \u05D7\u05D9 \u05E2\u05DD \u05E6\u05D5\u05E8\u05D9\u05D0\u05DC + \u05E7\u05D5\u05E8\u05E4\u05D5\u05E1 \u05D4\u05D9\u05E1\u05D8\u05D5\u05E8\u05D9",
  ZURIEL_RESEARCH_DIRECTION: "\u05DB\u05D9\u05D5\u05D5\u05DF \u05DE\u05D7\u05E7\u05E8 \u05E9\u05DC \u05E6\u05D5\u05E8\u05D9\u05D0\u05DC",
  "ai:messianic_model_v1": "\u05DE\u05D5\u05D3\u05DC \u05DE\u05D7\u05E7\u05E8 \u05DE\u05E9\u05D9\u05D7\u05D9",
  "GPT cross-domain research synthesis from canonical SOD1820 data + external mathematics": "\u05E1\u05D9\u05E0\u05EA\u05D6\u05EA \u05DE\u05D7\u05E7\u05E8 \u05DE\u05E2\u05E8\u05DB\u05EA\u05D9\u05EA \u05E9\u05DC \u05E1\u05D5\u05D3 1820 \u05D5\u05DE\u05EA\u05DE\u05D8\u05D9\u05E7\u05D4",
  "Itzhak Bentov \u2014 A Brief Tour of Higher Consciousness (2nd ed., 2000)": "\u05D9\u05E6\u05D7\u05E7 \u05D1\u05E0\u05D8\u05D5\u05D1 \u2014 \u05DE\u05E1\u05E2 \u05E7\u05E6\u05E8 \u05D0\u05DC \u05D4\u05EA\u05D5\u05D3\u05E2\u05D4 \u05D4\u05D2\u05D1\u05D5\u05D4\u05D4",
  "\u05E1\u05E4\u05E8 \u05D4\u05E4\u05DC\u05D9\u05D0\u05D4 \u2014 HebrewBooks 6355": "\u05E1\u05E4\u05E8 \u05D4\u05E4\u05DC\u05D9\u05D0\u05D4 \u2014 \u05D4\u05D9\u05D1\u05E8\u05D5\u05D1\u05D5\u05E7\u05E1 6355",
  "HebrewBooks 23968 \u2014 exact canonical Supabase digital object": "\u05DE\u05E7\u05D5\u05E8 \u05E1\u05E4\u05E8\u05D5\u05EA\u05D9 \u2014 \u05D4\u05D9\u05D1\u05E8\u05D5\u05D1\u05D5\u05E7\u05E1 23968",
  "\u05E1\u05E4\u05E8 \u05D9\u05E6\u05D9\u05E8\u05D4 \u2014 institutional witness Q 18/3545": "\u05E1\u05E4\u05E8 \u05D9\u05E6\u05D9\u05E8\u05D4 \u2014 \u05E2\u05D3\u05D5\u05EA \u05DB\u05EA\u05D1\u05BE\u05D9\u05D3 18/3545"
}), OCCURRENCE_LABELS = Object.freeze({
  channel_updates: "\u05D4\u05D5\u05D3\u05E2\u05EA \u05DE\u05E7\u05D5\u05E8",
  research_contributions: "\u05EA\u05E8\u05D5\u05DE\u05EA \u05DE\u05D7\u05E7\u05E8",
  work_log: "\u05E8\u05E9\u05D5\u05DE\u05EA \u05DE\u05D7\u05E7\u05E8 \u05E4\u05E0\u05D9\u05DE\u05D9\u05EA",
  post: "\u05E4\u05D5\u05E1\u05D8 \u05DE\u05E7\u05D5\u05E8",
  posts: "\u05E4\u05D5\u05E1\u05D8 \u05DE\u05E7\u05D5\u05E8",
  wp: "\u05E4\u05D5\u05E1\u05D8 \u05DE\u05E7\u05D5\u05E8",
  book: "\u05E7\u05D8\u05E2 \u05DE\u05E7\u05D5\u05E8",
  video: "\u05E7\u05D8\u05E2 \u05D5\u05D9\u05D3\u05D0\u05D5",
  gallery_image: "\u05E4\u05E8\u05D9\u05D8 \u05DE\u05D3\u05D9\u05D4",
  family_relation: "\u05E7\u05E9\u05E8 \u05DE\u05E9\u05E4\u05D7\u05EA\u05D9"
});
function normalizeResearchPresentationLocale(locale = "he") {
  return clean12(locale)?.toLowerCase().replace(/_/g, "-") || "he";
}
function researchKindLabel(kind) {
  return HEBREW_KIND_LABEL[clean12(kind)] || "\u05DE\u05DE\u05E6\u05D0 \u05DE\u05D7\u05E7\u05E8";
}
function normalizeResearchDisplayText(value) {
  let text = value == null ? "" : String(value).replace(/\r\n?/g, `
`).replace(/\u00a0/g, " ");
  if (!text.trim()) return null;
  let lines = text.split(`
`).map((line) => line.replace(/[\t ]+/g, " ").trim()), out = [], blanks = 0;
  for (let line of lines) {
    if (!line) {
      blanks += 1, blanks <= 1 && out.length && out.push("");
      continue;
    }
    blanks = 0, out.push(line);
  }
  for (; out.length && !out[out.length - 1]; ) out.pop();
  return out.join(`
`).trim() || null;
}
function inferStatementLanguage(statement) {
  let text = clean12(statement) || "", hasHebrew = /[א-ת]/.test(text), hasLatin = /[A-Za-z]/.test(text);
  return hasHebrew && !hasLatin ? "he" : null;
}
function variantForLocale(variants, locale) {
  let requested = normalizeResearchPresentationLocale(locale), base = requested.split("-")[0];
  for (let candidate of [.../* @__PURE__ */ new Set([requested, base])]) {
    let variant = objectValue(variants[candidate]), title = clean12(variant.title), summary = clean12(variant.summary);
    if (title || summary) return { locale: candidate, variant };
  }
  return { locale: null, variant: {} };
}
function isTechnicalToken(value) {
  let text = clean12(value) || "";
  return !text || /^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(text) || /^\+?\d{8,}$/.test(text) || /^(?:research_|work_log|channel_updates|wa_bot_log|video_semantic_map|ai:|api:|rpc:)/i.test(text) || /^[A-Za-z0-9_.:/#-]+$/.test(text) && /[_:/#]/.test(text);
}
function hebrewClip(value, max = 118) {
  let text = clean12(value)?.replace(/\s+/g, " ") || "";
  return text && (text.length > max ? `${text.slice(0, max - 1).trim()}\u2026` : text) || null;
}
function hebrewOnlyLabel(value) {
  let text = clean12(value) || "";
  if (!text) return null;
  let withoutLatin = text.replace(/[A-Za-z][A-Za-z0-9_.:/#()'’-]*/g, " ").replace(/\s+/g, " ").replace(/\s+([·:;,—-])/g, "$1").trim();
  return /[א-ת]/.test(withoutLatin) ? hebrewClip(withoutLatin) : null;
}
function humanizeResearchSource(source, sourceRef = null) {
  let raw = clean12(source);
  if (raw && SOURCE_LABELS[raw]) return SOURCE_LABELS[raw];
  if (raw) {
    let hb = raw.match(/^HebrewBooks\s+(\d+)/i);
    if (hb) return `\u05D4\u05D9\u05D1\u05E8\u05D5\u05D1\u05D5\u05E7\u05E1 ${hb[1]}`;
    let hebrew = hebrewOnlyLabel(raw);
    if (hebrew && !isTechnicalToken(raw)) return hebrew;
  }
  let ref = clean12(sourceRef) || "";
  return /^channel_updates:/i.test(ref) ? "\u05D4\u05D5\u05D3\u05E2\u05D5\u05EA \u05DE\u05E7\u05D5\u05E8" : /^(?:posts?|wp):/i.test(ref) ? "\u05E4\u05D5\u05E1\u05D8 \u05DE\u05E7\u05D5\u05E8" : /^book:/i.test(ref) ? "\u05DE\u05E7\u05D5\u05E8 \u05E1\u05E4\u05E8\u05D5\u05EA\u05D9" : /^video/i.test(ref) ? "\u05D5\u05D9\u05D3\u05D0\u05D5 \u05DE\u05E7\u05D5\u05E8" : /^work_log:/i.test(ref) ? "\u05DE\u05D7\u05E7\u05E8 \u05E4\u05E0\u05D9\u05DE\u05D9" : "\u05DE\u05E7\u05D5\u05E8 \u05DE\u05D7\u05E7\u05E8";
}
function researchOccurrenceLabel(sourceRef) {
  let ref = clean12(sourceRef);
  if (!ref) return "\u05DE\u05E7\u05D5\u05DD \u05D1\u05DE\u05E7\u05D5\u05E8 \u05DC\u05D0 \u05E6\u05D5\u05D9\u05DF";
  let prefix = ref.split(":")[0];
  return OCCURRENCE_LABELS[prefix] || "\u05DE\u05E7\u05D5\u05DD \u05D1\u05DE\u05E7\u05D5\u05E8";
}
function formatHebrewDate(value) {
  if (!value) return null;
  let date = new Date(value);
  if (!Number.isFinite(date.getTime())) return null;
  try {
    return new Intl.DateTimeFormat("he-IL", {
      day: "numeric",
      month: "numeric",
      year: "numeric",
      timeZone: "UTC"
    }).format(date);
  } catch {
    return date.toISOString().slice(0, 10);
  }
}
function contextualFallbackTitle(row, rawStatement, { typeLabel, sourceLabel } = {}) {
  let text = clean12(rawStatement) || "", value = row?.value != null && row?.value !== "" ? String(row.value) : null, caseStudy = text.match(/^CASE\s+STUDY\s*[—-]\s*(\d+)\s*\/\s*([^:]+)(?::|$)/i);
  if (caseStudy) {
    let topic = hebrewOnlyLabel(caseStudy[2]);
    return topic ? `\u05DE\u05D7\u05E7\u05E8 \u05DE\u05E7\u05E8\u05D4: ${caseStudy[1]} \u2014 ${topic}` : `\u05DE\u05D7\u05E7\u05E8 \u05DE\u05E7\u05E8\u05D4 \u05E1\u05D1\u05D9\u05D1 ${caseStudy[1]}`;
  }
  let numberDefinition = text.match(/^NUMBER\s+DEFINITION\s+CANDIDATE\s*[—-]\s*(\d+)/i);
  if (numberDefinition) return `\u05D4\u05D2\u05D3\u05E8\u05EA \u05DE\u05E1\u05E4\u05E8 \u05DE\u05D5\u05E2\u05DE\u05D3\u05EA: ${numberDefinition[1]}`;
  let speaker = text.match(/^Speaker of the phrase\s+["“]?([^"”]+)["”]?/i);
  if (speaker) {
    let phrase = hebrewOnlyLabel(speaker[1]);
    if (phrase) return `${typeLabel}: \u05D9\u05D9\u05D7\u05D5\u05E1 \u05D4\u05D3\u05D5\u05D1\u05E8 \u05DC\u05D1\u05D9\u05D8\u05D5\u05D9 \u201E${phrase}\u201D`;
  }
  if (/\bbinary\s*\(/i.test(text)) return value ? `\u05D9\u05D9\u05E6\u05D5\u05D2 \u05D1\u05D9\u05E0\u05D0\u05E8\u05D9 \u05E1\u05D1\u05D9\u05D1 ${value}` : "\u05D1\u05D3\u05D9\u05E7\u05EA \u05D9\u05D9\u05E6\u05D5\u05D2 \u05D1\u05D9\u05E0\u05D0\u05E8\u05D9";
  if (/^Zuriel research thread:/i.test(text)) return value ? `\u05E6\u05D9\u05E8 \u05D4\u05DE\u05D7\u05E7\u05E8 \u05E9\u05DC \u05E6\u05D5\u05E8\u05D9\u05D0\u05DC \u05E1\u05D1\u05D9\u05D1 ${value}` : "\u05E6\u05D9\u05E8 \u05D4\u05DE\u05D7\u05E7\u05E8 \u05E9\u05DC \u05E6\u05D5\u05E8\u05D9\u05D0\u05DC";
  if (/^[\s"'“”׳״(\d.,:;—-]*[א-ת]/u.test(text)) {
    let line = text.split(/\n|(?<=[.!?])\s+/u)[0], clipped = hebrewClip(line);
    if (clipped) return clipped;
  }
  let hebrew = hebrewOnlyLabel(text);
  return hebrew && text.search(/[א-ת]/) < 24 ? hebrew : value ? `${typeLabel} \u05E1\u05D1\u05D9\u05D1 ${value}` : sourceLabel && sourceLabel !== "\u05DE\u05E7\u05D5\u05E8 \u05DE\u05D7\u05E7\u05E8" ? `${typeLabel} \u05DE\u05EA\u05D5\u05DA ${sourceLabel}` : typeLabel || "\u05DE\u05DE\u05E6\u05D0 \u05DE\u05D7\u05E7\u05E8";
}
function presentationAttribution(row) {
  let meta = objectValue(row?.meta), ext = objectValue(meta.ext), waIntake = objectValue(ext.wa_channel_intake), contributor = clean12(row?.contributor), explicitType = clean12(meta.attribution_type), explicitContributorId = clean12(meta.contributor_id), trustedIntakeContributorId = waIntake.trusted_author === !0 ? clean12(waIntake.contributor_id) : null, contributorId = explicitContributorId || trustedIntakeContributorId, hasValidContributorId = !!(contributorId && /^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(contributorId)), attributionIsExplicit = !!(explicitType && explicitContributorId), attributionIsTrustedIntake = !!trustedIntakeContributorId, displayName = contributor === "ZURIEL" ? "\u05E6\u05D5\u05E8\u05D9\u05D0\u05DC" : contributor === "GPT" || contributor === "CLAUDE" ? "\u05DE\u05E2\u05E8\u05DB\u05EA \u05D4\u05DE\u05D7\u05E7\u05E8" : hebrewOnlyLabel(contributor);
  return hasValidContributorId && (attributionIsExplicit || attributionIsTrustedIntake) ? {
    state: "resolved",
    contributorId,
    label: displayName ? `\u05D9\u05D9\u05D7\u05D5\u05E1 \u05DE\u05E7\u05D5\u05E8 \u05DE\u05D0\u05D5\u05DE\u05EA: ${displayName}` : "\u05D9\u05D9\u05D7\u05D5\u05E1 \u05DE\u05E7\u05D5\u05E8 \u05DE\u05D0\u05D5\u05DE\u05EA"
  } : contributor ? {
    state: "unresolved",
    contributorId: null,
    label: displayName ? `\u05EA\u05D5\u05D5\u05D9\u05EA \u05D9\u05D9\u05D7\u05D5\u05E1 \u05D1\u05DE\u05E7\u05D5\u05E8: ${displayName} \xB7 \u05D6\u05D4\u05D5\u05EA \u05D4\u05DE\u05D7\u05D1\u05E8 \u05DC\u05D0 \u05D4\u05D5\u05DB\u05E8\u05E2\u05D4` : "\u05E7\u05D9\u05D9\u05DE\u05EA \u05EA\u05D5\u05D5\u05D9\u05EA \u05D9\u05D9\u05D7\u05D5\u05E1 \u05D1\u05DE\u05E7\u05D5\u05E8 \xB7 \u05D6\u05D4\u05D5\u05EA \u05D4\u05DE\u05D7\u05D1\u05E8 \u05DC\u05D0 \u05D4\u05D5\u05DB\u05E8\u05E2\u05D4"
  } : { state: "unknown", contributorId: null, label: "\u05D6\u05D4\u05D5\u05EA \u05D4\u05DE\u05D7\u05D1\u05E8 \u05DC\u05D0 \u05E6\u05D5\u05D9\u05E0\u05D4" };
}
function safeHebrewPrimaryTitle(title, fallback) {
  let text = clean12(title);
  return text ? /[A-Za-z]/.test(text) ? hebrewOnlyLabel(text) || fallback : text : fallback;
}
function resolveResearchObjectPresentation(row, { locale = "he" } = {}) {
  let meta = objectValue(row?.meta), ext = objectValue(meta.ext), presentation = objectValue(ext.presentation), variants = objectValue(presentation.variants), requestedLocale = normalizeResearchPresentationLocale(locale), requestedBase = requestedLocale.split("-")[0], resolved = variantForLocale(variants, requestedLocale), rawStatement = clean12(row?.statement), humanTitle = clean12(resolved.variant.title), humanSummary = clean12(resolved.variant.summary), sourceLabelRaw = clean12(resolved.variant.source_label) || clean12(meta.source_label), sourceLabel = requestedBase === "he" ? safeHebrewPrimaryTitle(sourceLabelRaw, null) || humanizeResearchSource(row?.source, row?.source_ref) : sourceLabelRaw || clean12(row?.source), statementLang = clean12(presentation.statement_lang) || inferStatementLanguage(rawStatement), sourceWitnessLang = clean12(presentation.source_witness_lang), sourceWitnessLangBasis = clean12(presentation.source_witness_lang_basis), hasHumanPresentation = !!(resolved.locale && (humanTitle || humanSummary)), typeLabel = researchKindLabel(row?.kind), fallbackTitle = requestedBase === "he" ? contextualFallbackTitle(row, rawStatement, { typeLabel, sourceLabel }) : rawStatement || `Research object ${row?.id || ""}`.trim(), title = requestedBase === "he" ? safeHebrewPrimaryTitle(humanTitle, fallbackTitle) : humanTitle || fallbackTitle, occurrenceLabel = researchOccurrenceLabel(row?.source_ref), dateLabel = formatHebrewDate(row?.created_at), attribution = presentationAttribution(row), storedContextLine = clean12(resolved.variant.context_line), contextLine = requestedBase === "he" ? safeHebrewPrimaryTitle(storedContextLine, null) || [...new Set([typeLabel, sourceLabel, occurrenceLabel, dateLabel].filter(Boolean))].join(" \xB7 ") : storedContextLine;
  return {
    requestedLocale,
    resolvedLocale: hasHumanPresentation ? resolved.locale : null,
    title,
    summary: hasHumanPresentation ? humanSummary : null,
    sourceLabel,
    typeLabel,
    contextLine,
    attributionLabel: attribution.label,
    attributionState: attribution.state,
    occurrenceLabel,
    dateLabel,
    statementLang,
    sourceWitnessLang,
    sourceWitnessLangBasis,
    statementRole: clean12(presentation.statement_role) || null,
    hasHumanPresentation,
    fallbackMode: hasHumanPresentation ? null : "raw_statement",
    originalText: rawStatement,
    displayText: normalizeResearchDisplayText(rawStatement),
    originalLanguage: statementLang,
    compiled: objectValue(presentation.compiled)
  };
}

// src/lib/research/researchObjectFinding.js
var VALID_VERIFICATION = new Set(VALID_VERIFICATION_STATES);
function clean13(v) {
  return v == null ? null : String(v).trim() || null;
}
function verificationFrom(row) {
  let detail = row?.engine_detail && typeof row.engine_detail == "object" ? row.engine_detail : {}, explicit = clean13(detail.verification_state), verification_state = explicit && VALID_VERIFICATION.has(explicit) ? explicit : null, trace = detail.trace && typeof detail.trace == "object" && !Array.isArray(detail.trace) ? detail.trace : {};
  return {
    claimed_expression: detail.claimed_expression ?? null,
    claimed_method: detail.claimed_method ?? null,
    claimed_value: detail.claimed_value ?? detail.source_claimed_value ?? null,
    engine_method_tested: detail.engine_method_tested ?? detail.engine ?? detail.method_key ?? trace.method_key ?? null,
    engine_result: detail.engine_result ?? detail.engine_value ?? detail.result ?? trace.result ?? null,
    statement_lang: detail.statement_lang ?? null,
    verification_state
  };
}
function asObject(value) {
  return value && typeof value == "object" && !Array.isArray(value) ? value : {};
}
function finiteNumber(value) {
  if (value == null || value === "") return null;
  let n = Number(value);
  return Number.isFinite(n) ? n : null;
}
function methodRef(token, basis) {
  let value = clean13(token);
  return value ? {
    token: value,
    namespace: /^[a-z0-9_+.-]+$/i.test(value) ? "db_column_or_alias" : "method_key",
    basis,
    registryResolutionRequired: !0
  } : null;
}
function verifiedCompoundOperationShape(compound) {
  if (!compound || typeof compound != "object" || Array.isArray(compound) || !Object.keys(compound).length) return null;
  let raw = clean13(compound.raw) || clean13(compound.text) || clean13(compound.origRaw), verifiedComposite = clean13(compound.status) === "ENGINE_VERIFIED_COMPOSITE", factors = [], addFactor = (value) => {
    let n = finiteNumber(value);
    n == null || factors.includes(n) || factors.push(n);
  }, quantity = finiteNumber(compound.quantity);
  if (quantity != null && addFactor(quantity), verifiedComposite && raw) {
    for (let match of raw.matchAll(/(?:×|x)\s*(\d+(?:\.\d+)?)/gi)) addFactor(match[1]);
    for (let match of raw.matchAll(/(\d+(?:\.\d+)?)\s*(?:×|x)/gi)) addFactor(match[1]);
    for (let match of raw.matchAll(/(\d+(?:\.\d+)?)\s*פעמים/g)) addFactor(match[1]);
  }
  let operators = [], compoundKind = clean13(compound.kind);
  return compoundKind && /product/i.test(compoundKind) && operators.push("multiply"), verifiedComposite && raw && /×|x/i.test(raw) && !operators.includes("multiply") && operators.push("multiply"), verifiedComposite && raw && /\+/.test(raw) && operators.push("add"), {
    kind: compoundKind,
    multiplier: quantity,
    factors,
    operators,
    result: finiteNumber(compound.result),
    computedTotal: finiteNumber(compound.computedTotal),
    linkCount: finiteNumber(compound.linkCount),
    status: clean13(compound.status),
    basis: verifiedComposite ? "verified_engine_compound" : "structured_compound"
  };
}
function researchObjectFacetDimensions(row, { registryRows = [], sourceOccurrence = null } = {}) {
  let detail = asObject(row?.engine_detail), compound = asObject(detail.compound), ext = asObject(row?.meta?.ext), spatial = asObject(ext.spatial_research), mediaProfile = asObject(ext.source_media_profile), duplicate = asObject(ext.exact_duplicate_lineage), gematria = asObject(ext.gematria), methodRefs = [], addMethod = (token, basis) => {
    let ref = methodRef(token, basis);
    !ref || methodRefs.some((item) => item.token === ref.token && item.namespace === ref.namespace) || methodRefs.push(ref);
  };
  addMethod(detail.claimed_method, "engine_detail.claimed_method"), addMethod(detail.engine_method_tested, "engine_detail.engine_method_tested"), addMethod(detail.method, "engine_detail.method"), addMethod(detail.verification?.method, "engine_detail.verification.method"), addMethod(detail.trace?.method_key, "engine_detail.trace.method_key"), addMethod(gematria.method_key, "meta.ext.gematria.method_key"), addMethod(gematria.method, "meta.ext.gematria.method"), addMethod(compound?.operand?.method, "engine_detail.compound.operand.method");
  for (let operand of Array.isArray(compound.operands) ? compound.operands : [])
    addMethod(operand?.method, "engine_detail.compound.operands[].method");
  for (let component of Array.isArray(detail.method_components) ? detail.method_components : [])
    addMethod(component?.method_key || component?.method, "engine_detail.method_components[].method_key");
  let registryByMethodKey = /* @__PURE__ */ new Map(), registryByDbColumn = /* @__PURE__ */ new Map();
  for (let registryRow of Array.isArray(registryRows) ? registryRows : []) {
    let methodKey = clean13(registryRow?.method_key), dbColumn = clean13(registryRow?.db_column);
    methodKey && registryByMethodKey.set(methodKey, registryRow), dbColumn && registryByDbColumn.set(dbColumn, registryRow);
  }
  let canonicalMethodMap = /* @__PURE__ */ new Map();
  for (let ref of methodRefs) {
    let registry = registryByMethodKey.get(ref.token) || registryByDbColumn.get(ref.token) || null, methodKey = clean13(registry?.method_key);
    if (!methodKey) continue;
    let current = canonicalMethodMap.get(methodKey) || {
      methodKey,
      dbColumn: clean13(registry?.db_column),
      displayLabel: clean13(registry?.display_label) || methodKey,
      refs: [],
      registryResolved: !0
    };
    current.refs.push({ token: ref.token, namespace: ref.namespace, basis: ref.basis }), canonicalMethodMap.set(methodKey, current);
  }
  let canonicalMethods = [...canonicalMethodMap.values()], methodComponents = (Array.isArray(detail.method_components) ? detail.method_components : []).map((component) => {
    let rawMethod = clean13(component?.method_key || component?.method);
    if (!rawMethod) return null;
    let registry = registryByMethodKey.get(rawMethod) || registryByDbColumn.get(rawMethod) || null;
    return {
      methodKey: clean13(registry?.method_key) || rawMethod,
      dbColumn: clean13(registry?.db_column) || null,
      displayLabel: clean13(registry?.display_label) || rawMethod,
      registryResolved: !!registry,
      expression: clean13(component?.expression) || null,
      claimedValue: finiteNumber(component?.claimed_value),
      engineResult: finiteNumber(component?.engine_result),
      verificationState: clean13(component?.verification_state) || null,
      verifiedVia: clean13(component?.verified_via) || null,
      claimedTransform: clean13(component?.claimed_transform) || null,
      engineTransform: clean13(component?.engine_transform) || null,
      valueVerificationState: clean13(component?.value_verification_state) || null,
      transformVerificationState: clean13(component?.transform_verification_state) || null,
      sourceMethodLabel: clean13(component?.source_method_label) || null
    };
  }).filter(Boolean), sourceMethods = (Array.isArray(sourceOccurrence?.methodMentions) ? sourceOccurrence.methodMentions : []).map((mention) => ({
    token: clean13(mention?.token),
    methodKey: clean13(mention?.methodKey),
    displayLabel: clean13(mention?.displayLabel) || clean13(mention?.token),
    state: clean13(mention?.state),
    sourceAttested: mention?.sourceAttested === !0,
    appliesToFinding: mention?.appliesToFinding === !0
  })).filter((mention) => mention.token && mention.sourceAttested), operation = verifiedCompoundOperationShape(compound), family = Object.keys(spatial).length ? {
    key: clean13(spatial.research_focus_key),
    cluster: clean13(spatial.cluster),
    role: clean13(spatial.role),
    classification: clean13(spatial.classification)
  } : null, sourceOccurrenceRef = clean13(row?.source_ref) || clean13(spatial.source_ref) || clean13(mediaProfile.source_ref), occurrenceRefs = [], addOccurrence = (value) => {
    let ref = clean13(value);
    ref && !occurrenceRefs.includes(ref) && occurrenceRefs.push(ref);
  };
  addOccurrence(row?.source_ref), addOccurrence(spatial.source_ref), addOccurrence(mediaProfile.source_ref);
  for (let ref of Array.isArray(compound.occurrences) ? compound.occurrences : []) addOccurrence(ref);
  for (let ref of Array.isArray(ext.source_refs) ? ext.source_refs : []) addOccurrence(ref);
  for (let ref of Array.isArray(row?.meta?.source_refs) ? row.meta.source_refs : []) addOccurrence(ref);
  let duplicateOccurrenceCount = finiteNumber(duplicate.occurrence_count), spatialRole = family?.role || null, mediaClass = clean13(mediaProfile.class), spatial3d = [spatialRole, mediaClass].some((value) => /(?:^|_)3D(?:_|$)/i.test(value || "")), facets = {
    methods: methodRefs,
    canonicalMethods,
    methodComponents,
    sourceMethods,
    operation,
    family,
    spatial: family || mediaClass ? {
      role: spatialRole,
      cluster: family?.cluster || null,
      mediaClass,
      is3d: spatial3d,
      loadBearingVisualCandidate: mediaProfile.load_bearing_visual_candidate === !0
    } : null,
    sourceOccurrence: sourceOccurrenceRef || occurrenceRefs.length ? {
      ref: sourceOccurrenceRef,
      refs: occurrenceRefs,
      duplicateOccurrenceCount
    } : null
  };
  return facets.methods.length || facets.canonicalMethods.length || facets.methodComponents.length || facets.sourceMethods.length || facets.operation || facets.family || facets.spatial || facets.sourceOccurrence ? facets : null;
}
var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function resolveExplicitAttribution(row) {
  let meta = row?.meta && typeof row.meta == "object" ? row.meta : {}, type = clean13(meta.attribution_type), contributorId = clean13(meta.contributor_id), validId = contributorId && UUID_RE.test(contributorId) ? contributorId.toLowerCase() : null;
  return {
    type,
    contributorId: validId,
    resolved: !!(type && validId)
  };
}
function researchObjectToUniversalFinding(row, { locale = "he", methodRegistry = [] } = {}) {
  if (!row?.id) return null;
  let sourceRef = clean13(row.source_ref), promotedNodeId = clean13(row.promoted_node_id), terms = Array.isArray(row.terms) ? row.terms.filter(Boolean) : [], presentation = resolveResearchObjectPresentation(row, { locale }), attribution = resolveExplicitAttribution(row), rawStatementRef = { researchObjectId: String(row.id), field: "statement" }, researchFacets = researchObjectFacetDimensions(row, { registryRows: methodRegistry });
  return makeUniversalFinding({
    kind: "research-object",
    stage: null,
    status: row.status ?? null,
    subject: {
      type: "research-object",
      key: String(row.id),
      label: presentation.title,
      value: row.value ?? null,
      lang: presentation.hasHumanPresentation ? presentation.resolvedLocale : presentation.statementLang || null
    },
    source: {
      engine: null,
      adapter: "research-object-v1",
      sourceRef,
      method: null,
      corpus: clean13(row.source),
      // Source witness language is distinct from the research statement/presentation language.
      // Unknown stays null; a Latin-script statement is never silently called English.
      lang: presentation.sourceWitnessLang
    },
    identity: {
      sourceIdentity: { researchObjectId: String(row.id) },
      entityRef: promotedNodeId ? `node:${promotedNodeId}` : null,
      relationRef: null
    },
    verification: verificationFrom(row),
    evidence: {
      refs: sourceRef ? [sourceRef] : [],
      facts: terms.map((term) => ({ type: "term", value: term })),
      score: row.confidence ?? null,
      confidence: row.confidence ?? null
    },
    access: {
      tier: row.privacy_scope ?? null,
      reason: null
    },
    provenance: {
      createdBy: null,
      createdAt: row.created_at || void 0,
      inputRef: sourceRef
    },
    projection: {
      anchors: promotedNodeId ? [{ space: "reality-graph", id: promotedNodeId }] : [],
      relations: [],
      dimensions: {
        researchObjectKind: row.kind ?? null,
        ...researchFacets ? { researchFacets } : {},
        ...attribution.type || attribution.contributorId ? { attribution: { type: attribution.type, contributorId: attribution.contributorId, resolved: attribution.resolved, explicit: attribution.resolved } } : {},
        presentation: {
          requestedLocale: presentation.requestedLocale,
          resolvedLocale: presentation.resolvedLocale,
          hasHumanPresentation: presentation.hasHumanPresentation,
          fallbackMode: presentation.fallbackMode,
          statementLang: presentation.statementLang,
          statementRole: presentation.statementRole,
          sourceWitnessLang: presentation.sourceWitnessLang,
          sourceWitnessLangBasis: presentation.sourceWitnessLangBasis,
          rawStatementRef,
          sourceLocator: sourceRef,
          displayText: presentation.displayText,
          typeLabel: presentation.typeLabel,
          contextLine: presentation.contextLine,
          attributionLabel: presentation.attributionLabel,
          attributionState: presentation.attributionState,
          occurrenceLabel: presentation.occurrenceLabel,
          dateLabel: presentation.dateLabel,
          originalLanguage: presentation.originalLanguage
        }
      }
    },
    view: {
      rendererHints: {
        presentation: {
          title: presentation.title,
          summary: presentation.summary,
          sourceLabel: presentation.sourceLabel,
          locale: presentation.resolvedLocale,
          fallbackMode: presentation.fallbackMode,
          typeLabel: presentation.typeLabel,
          contextLine: presentation.contextLine,
          attributionLabel: presentation.attributionLabel,
          attributionState: presentation.attributionState,
          occurrenceLabel: presentation.occurrenceLabel,
          dateLabel: presentation.dateLabel,
          displayText: presentation.displayText,
          rawStatementRef
        }
      }
    }
  });
}
function researchObjectsToUniversalFindings(rows, options = {}) {
  return (Array.isArray(rows) ? rows : []).map((row) => researchObjectToUniversalFinding(row, options)).filter(Boolean);
}

// src/lib/research/researchW2ExecutorsBase.js
var SAFE_W2_NUMERIC_LENSES = Object.freeze([
  "number_lookup",
  "number_dossier",
  "number_journey",
  "neighbors",
  "hot_context",
  "gematria_reverse"
]), SAFE_W2_NUMERIC_LENS_SET = new Set(SAFE_W2_NUMERIC_LENSES), DEFAULT_W2_NUMERIC_LENSES = Object.freeze([
  "number_lookup",
  "number_dossier",
  "number_journey",
  "neighbors"
]);
function parseCanonicalNumber(raw) {
  if (typeof raw == "number") return Number.isSafeInteger(raw) && raw >= 0 ? raw : null;
  if (typeof raw != "string") return null;
  let text = raw.trim();
  if (!/^\d+$/.test(text)) return null;
  let number = Number(text);
  return Number.isSafeInteger(number) && number >= 0 ? number : null;
}
function numberFromIdentity(identityResolution) {
  let identities = identityResolution?.identities || [];
  for (let identity of identities) {
    if (identity?.type !== "number") continue;
    let raw = identity?.value ?? identity?.ref ?? identity?.key ?? identity?.label, number = parseCanonicalNumber(raw);
    if (number != null) return number;
  }
  return null;
}
function windowForNumber(lookupWindow, number) {
  if (!lookupWindow || typeof lookupWindow != "object") return;
  if (lookupWindow instanceof Map) return lookupWindow.get(number) || lookupWindow.get(String(number)) || void 0;
  let keyed = lookupWindow[number] ?? lookupWindow[String(number)];
  if (keyed && typeof keyed == "object") return keyed;
  if ("limit" in lookupWindow || "afterBidId" in lookupWindow || "after_bid_id" in lookupWindow) return lookupWindow;
}
function rpcExecutor(supabase) {
  return async (name, args) => supabase.rpc(name, args);
}
function graphNodeRefFromIdentity(identityResolution) {
  let identities = identityResolution?.identities || [];
  for (let identity of identities) {
    let candidates = [identity?.node_id, identity?.nodeId, identity?.ref, identity?.identity_key, identity?.key];
    for (let candidate of candidates) {
      if (typeof candidate != "string") continue;
      let text = candidate.trim();
      if (text.startsWith("node:")) {
        let id = text.slice(5).trim();
        if (id) return id;
      }
      if ((candidate === identity?.node_id || candidate === identity?.nodeId) && /^[0-9a-fA-F-]{36}$/.test(text)) return text;
    }
  }
  return null;
}
async function resolveNumericRuleVersions(source) {
  let out = /* @__PURE__ */ new Map();
  try {
    let resolved = typeof source == "function" ? await source(NUMERIC_SYSTEM_METHOD_RULE_IDS) : source;
    if (!resolved) return out;
    let entries = resolved instanceof Map ? [...resolved.entries()] : Array.isArray(resolved) ? resolved.map((row) => [row?.rule_id, row?.rule_version]) : Object.entries(resolved);
    for (let [ruleId, version] of entries) {
      let id = typeof ruleId == "string" ? ruleId.trim() : "", v = Number(version);
      id && Number.isFinite(v) && out.set(id, v);
    }
  } catch {
    return /* @__PURE__ */ new Map();
  }
  return out;
}
var NUMERIC_SYSTEM_METHOD_RULE_IDS = Object.freeze([
  "zero_scale_law",
  "shitat_haechad_alef_law",
  "zero_navigation",
  "moment_clock_law"
]);
function ruleApplicationFinding(number, app) {
  return makeUniversalFinding({
    kind: "numeric-operator",
    stage: null,
    status: null,
    subject: { type: "number", key: String(number), label: String(number), value: number },
    source: {
      engine: app.engineRef,
      adapter: "numeric-rule-application-v1",
      sourceRef: `${app.ruleId}:v${app.ruleVersion}`,
      method: app.ruleId,
      corpus: null,
      lang: null
    },
    identity: {
      // Source-native, stable and reproducible: rule + version + operation + exact input.
      sourceIdentity: { ruleId: app.ruleId, ruleVersion: app.ruleVersion, operation: app.operation, input: app.input },
      occurrence: null,
      entityRef: `number:${number}`,
      relationRef: null
    },
    verification: {
      claimed_expression: null,
      claimed_method: null,
      claimed_value: null,
      engine_method_tested: app.engineRef,
      engine_result: app.output,
      statement_lang: null,
      verification_state: "not_tested"
    },
    evidence: {
      refs: [`${app.ruleId}:v${app.ruleVersion}`],
      facts: [{
        type: "rule-application",
        rule_id: app.ruleId,
        rule_version: app.ruleVersion,
        rule_version_source: app.versionSource,
        operation: app.operation,
        input: app.input,
        output: app.output,
        engine_ref: app.engineRef,
        family: "zuriel_numeric_research_laws",
        public_family_name: "\u05E9\u05D9\u05D8\u05D5\u05EA \u05D4\u05DE\u05E2\u05E8\u05DB\u05EA",
        boundary: "rule application never changes raw engine truth, canonical status or publication status"
      }],
      score: null,
      confidence: null
    },
    access: { tier: "public", reason: "System Method rules are public canonical rules in nodes" },
    provenance: { createdBy: `RULE:${app.ruleId}@v${app.ruleVersion}`, inputRef: `number:${number}` },
    projection: {
      anchors: [{ space: "number", value: number }],
      relations: [],
      dimensions: { ruleApplication: { ruleId: app.ruleId, ruleVersion: app.ruleVersion, operation: app.operation } }
    },
    view: { rendererHints: { role: "rule-application" } }
  });
}
function validateNumericLenses(input, { serverContext = !1 } = {}) {
  let lenses = Array.isArray(input) && input.length ? [...new Set(input)] : [...DEFAULT_W2_NUMERIC_LENSES], unsafe = lenses.filter((id) => !SAFE_W2_NUMERIC_LENS_SET.has(id));
  if (unsafe.length) throw new TypeError(`W2 numeric bridge cannot bypass capability adapters: ${unsafe.join(", ")}`);
  if (!serverContext) {
    let serverOnly = lenses.filter((id) => numericLensMap[id]?.client_executable === !1);
    if (serverOnly.length)
      throw new TypeError(`W2 numeric bridge cannot dispatch server-only lenses from a client context: ${serverOnly.join(", ")} (pass serverContext:true only when the caller genuinely holds a service-role/server path)`);
  }
  return lenses;
}
function numericLensStatusToCapability(perLens, requested) {
  let missing = requested.filter((id) => perLens?.[id]?.status === "adapter_needed"), failed = requested.filter((id) => perLens?.[id]?.status === "error");
  return failed.length ? { status: CAPABILITY_STATUS.FAILED, reason: `numeric lenses failed: ${failed.join(", ")}` } : missing.length && missing.length === requested.length ? { status: CAPABILITY_STATUS.MISSING_ADAPTER, reason: `numeric adapters missing: ${missing.join(", ")}` } : { status: CAPABILITY_STATUS.EXECUTED, reason: missing.length ? `partial numeric coverage; missing: ${missing.join(", ")}` : null };
}
function summarizeLens(value) {
  if (!value || typeof value != "object") return { status: "unknown" };
  let summary = { status: value.status || "unknown" };
  return value.rpc && (summary.rpc = value.rpc), value.error && (summary.error = String(value.error)), Array.isArray(value.data) ? summary.row_count = value.data.length : value.data != null && (summary.has_data = !0), summary;
}
function sequenceExpectedness(number, lensId, sequence) {
  if (lensId !== "sequence:pi")
    return { expectedness: "sequence_specific_not_estimated", expectednessModel: null, baseRate: null };
  let depth = Number(sequence?.search_depth), digits = String(number).length;
  if (!Number.isSafeInteger(depth) || depth <= 0 || digits <= 0)
    return { expectedness: "unknown", expectednessModel: "uniform_digit_stream_heuristic_v1", baseRate: null };
  let windows = Math.max(0, depth - digits + 1), singleWindowRate = 10 ** -digits, baseRate = windows === 0 ? 0 : 1 - Math.pow(1 - singleWindowRate, windows);
  return { expectedness: baseRate >= 0.95 ? "near_certain_under_uniform_digit_heuristic" : baseRate >= 0.5 ? "high_under_uniform_digit_heuristic" : baseRate >= 0.05 ? "moderate_under_uniform_digit_heuristic" : "low_under_uniform_digit_heuristic", expectednessModel: "uniform_digit_stream_heuristic_v1", baseRate };
}
function sequenceCapabilityFromResearch(number, lensId, result) {
  let sequence = result?.per_lens?.[lensId];
  if (!sequence) return { owner: "research_strategy_layer_law", status: CAPABILITY_STATUS.FAILED, reason: `${lensId} returned no result`, findings: [] };
  if (sequence.status === "error") return { owner: "research_strategy_layer_law", status: CAPABILITY_STATUS.FAILED, reason: sequence.error || `${lensId} failed`, findings: [], trace: { lens: lensId, status: "error" } };
  if (sequence.status === "adapter_needed") return { owner: "research_strategy_layer_law", status: CAPABILITY_STATUS.MISSING_ADAPTER, reason: sequence.error || `${lensId} adapter missing`, findings: [], trace: { lens: lensId, status: "adapter_needed" } };
  let foundState = sequence?.result?.found;
  if (foundState === !1)
    return {
      owner: "research_strategy_layer_law",
      status: CAPABILITY_STATUS.NEGATIVE_RESULT,
      reason: `${number} not found in bounded ${sequence.sequence_id || lensId} search`,
      negativeScope: {
        sequence_id: sequence.sequence_id || lensId.replace("sequence:", ""),
        operation: sequence.operation || null,
        search_depth: sequence.search_depth ?? null,
        position_convention: sequence.position_convention || null
      },
      findings: [],
      sourceRefs: [result?.provenance?.input_ref || `number:${number}`],
      versionRefs: [sequence.sequence_version || `${lensId}:unknown-version`],
      trace: { lens: lensId, status: "ok", found: !1 }
    };
  if (foundState !== !0)
    return {
      owner: "research_strategy_layer_law",
      status: CAPABILITY_STATUS.UNVERIFIED,
      reason: `${lensId} did not return an explicit found=true/false outcome`,
      findings: [],
      trace: { lens: lensId, status: sequence.status || "unknown", found: null }
    };
  let findings = result.universal_findings || [], expectedness = sequenceExpectedness(number, lensId, sequence), isHighBaseRatePi = lensId === "sequence:pi" && expectedness.baseRate != null && expectedness.baseRate >= 0.95;
  return {
    owner: "research_strategy_layer_law",
    status: CAPABILITY_STATUS.EXECUTED,
    findings,
    accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
    semanticClass: SEMANTIC_CLASS.EVIDENCE,
    findingOutcomes: findings.map((finding) => ({
      findingId: finding.id,
      evidenceRelation: EVIDENCE_RELATION.INDEPENDENT_EVIDENCE,
      reason: isHighBaseRatePi ? "independent sequence-engine lineage; occurrence is high-base-rate under a uniform-digit heuristic and is not corroboration by itself" : "independent sequence-engine computation lineage; semantic relevance is not implied",
      expectedness: expectedness.expectedness,
      expectednessModel: expectedness.expectednessModel,
      baseRate: expectedness.baseRate
    })),
    sourceRefs: [`number:${number}`],
    versionRefs: [sequence.sequence_version || `${lensId}:unknown-version`],
    trace: {
      lens: lensId,
      status: "ok",
      found: !0,
      first_position: sequence?.result?.first_position ?? null,
      search_depth: sequence.search_depth ?? null,
      expectedness: expectedness.expectedness,
      expectedness_model: expectedness.expectednessModel,
      base_rate: expectedness.baseRate
    }
  };
}
function createCanonicalNumberW2Executors({
  supabase,
  numericLenses = null,
  serverContext = !1,
  // W2.2b seams. All THREE are dependency-injected on purpose: this bridge must not grow its own
  // research-object reader, its own graph resolver or its own rule registry.
  //   fetchResearchObjects   — an ACCESS-FILTERED reader for research_objects (see below).
  //   graph                  — { fetchEntityFindings } = the EXISTING canonical adapter
  //                            src/lib/research/entityGraphFinding.js. No second graph/resolver.
  //   numericRuleVersions    — live rule_id -> rule_version attestation read from the canonical
  //                            nodes rule registry. Without it, no rule application is emitted.
  fetchResearchObjects = null,
  graph = null,
  numericRuleVersions = null,
  // W2.2d closure: the server-side keyset page is only useful if a caller can actually ASK for the
  // next page. Accepts either one window applied to every anchor, or a per-number map so a
  // multi-anchor continuation can be resumed anchor by anchor.
  lookupWindow = null
} = {}) {
  if (typeof supabase?.rpc != "function") throw new Error("canonical Supabase RPC client required");
  let lenses = validateNumericLenses(numericLenses, { serverContext }), numericExecutor = async ({ identityResolution }) => {
    let number = numberFromIdentity(identityResolution);
    if (number == null) return { owner: "research_strategy_layer_law", status: CAPABILITY_STATUS.SKIPPED, reason: "no canonical number identity resolved", findings: [] };
    let result = await researchNumber2(number, {
      lenses,
      rpc: rpcExecutor(supabase),
      lookupWindow: windowForNumber(lookupWindow, number),
      provenance: { requestSource: "research-composer-w2", inputRef: `number:${number}` }
    }), capabilityState = numericLensStatusToCapability(result.per_lens, lenses), perLens = Object.fromEntries(Object.entries(result.per_lens || {}).map(([key, value]) => [key, summarizeLens(value)]));
    return {
      owner: "research_strategy_layer_law",
      ...capabilityState,
      findings: result.universal_findings || [],
      // number_lookup rows come from a public, anon-executable contract over is_verified rows.
      accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
      semanticClass: SEMANTIC_CLASS.EVIDENCE,
      bounded: result.bounds?.number_lookup || null,
      sourceRefs: [`number:${number}`],
      versionRefs: ["numericResearch:v1"],
      trace: {
        root: result.root,
        requested_lenses: result.requested_lenses,
        per_lens: perLens,
        priority: result.priority,
        // Honest per-lens classification travels with the trace so a consumer can see WHY only
        // number_lookup produced Findings and the other lenses stayed context/ranking.
        lens_classes: Object.fromEntries(result.requested_lenses.map((id) => [id, {
          access_class: numericLensMap[id]?.access_class ?? null,
          semantic_class: numericLensMap[id]?.semantic_class ?? null,
          emits_findings: numericLensMap[id]?.emits_findings ?? null
        }]))
      }
    };
  }, makeSequenceExecutor = (lensId) => async ({ identityResolution }) => {
    let number = numberFromIdentity(identityResolution);
    if (number == null) return { owner: "research_strategy_layer_law", status: CAPABILITY_STATUS.SKIPPED, reason: "no canonical number identity resolved", findings: [] };
    let result = await researchNumber2(number, {
      lenses: [lensId],
      rpc: rpcExecutor(supabase),
      budget: { depth: 1 },
      provenance: { requestSource: "research-composer-w2", inputRef: `number:${number}` }
    });
    return sequenceCapabilityFromResearch(number, lensId, result);
  };
  return {
    numeric: numericExecutor,
    numeric_operators: async ({ identityResolution }) => {
      let number = numberFromIdentity(identityResolution);
      if (number == null)
        return {
          owner: "numeric_rule_family_index",
          status: CAPABILITY_STATUS.SKIPPED,
          reason: "no canonical number identity resolved",
          findings: []
        };
      let attested = await resolveNumericRuleVersions(numericRuleVersions), applications = [], skipped = [], zero = await rpcExecutor(supabase)("fn_zero_scale", { p_value: number }), zeroData = zero?.error ? null : zero?.data ?? zero;
      if (zeroData?.applicable === !0 && zeroData?.method_id && zeroData?.version != null) {
        let chain = Array.isArray(zeroData.scale_chain) ? zeroData.scale_chain : [];
        applications.push({
          ruleId: "zero_scale_law",
          ruleVersion: zeroData.version,
          versionSource: "fn_zero_scale.version",
          operation: "zero_scale_chain",
          input: number,
          output: { core_root: zeroData.core_root ?? null, scale_chain: chain },
          engineRef: "fn_zero_scale"
        });
      } else
        skipped.push({ rule_id: "zero_scale_law", reason: zero?.error ? "fn_zero_scale failed" : "not applicable to this value" });
      let digits = String(number);
      if (digits.length === 4 && digits.startsWith("1")) {
        let version = attested.get("shitat_haechad_alef_law");
        version == null ? skipped.push({ rule_id: "shitat_haechad_alef_law", reason: "rule_version not attested by the live rule registry \u2014 refusing to fabricate a version" }) : applications.push({
          ruleId: "shitat_haechad_alef_law",
          ruleVersion: version,
          versionSource: "nodes.rule_version",
          operation: "leading_one_split",
          input: number,
          output: { leading_unit: 1e3, remainder: number - 1e3 },
          engineRef: null
        });
      } else
        skipped.push({ rule_id: "shitat_haechad_alef_law", reason: "value is not a 4-digit value beginning with 1" });
      if (number % 10 === 0 && number >= 10) {
        let version = attested.get("zero_navigation");
        version == null ? skipped.push({ rule_id: "zero_navigation", reason: "rule_version not attested by the live rule registry \u2014 refusing to fabricate a version" }) : applications.push({
          ruleId: "zero_navigation",
          ruleVersion: version,
          versionSource: "nodes.rule_version",
          operation: "strip_trailing_zero",
          input: number,
          output: { core: number / 10 },
          engineRef: null
        });
      } else
        skipped.push({ rule_id: "zero_navigation", reason: "value does not end in 0" });
      skipped.push({ rule_id: "moment_clock_law", reason: "requires an original temporal input (timezone + representation); a bare number carries none" });
      let findings = applications.map((app) => ruleApplicationFinding(number, app));
      return findings.length ? {
        owner: "numeric_rule_family_index",
        status: CAPABILITY_STATUS.EXECUTED,
        findings,
        accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
        semanticClass: SEMANTIC_CLASS.DERIVATION,
        findingOutcomes: findings.map((finding, i) => ({
          findingId: finding.id,
          evidenceRelation: EVIDENCE_RELATION.DERIVATION,
          reason: `rule application of ${applications[i].ruleId} v${applications[i].ruleVersion} \u2014 a transform of an existing value, never independent corroboration of it`
        })),
        sourceRefs: [`number:${number}`],
        versionRefs: applications.map((app) => `${app.ruleId}:v${app.ruleVersion}`),
        trace: { applied: applications.map((a) => ({ rule_id: a.ruleId, rule_version: a.ruleVersion, operation: a.operation, version_source: a.versionSource })), skipped }
      } : {
        owner: "numeric_rule_family_index",
        status: CAPABILITY_STATUS.UNVERIFIED,
        reason: "no System Method rule application could be attested for this value",
        findings: [],
        accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
        semanticClass: SEMANTIC_CLASS.DERIVATION,
        sourceRefs: [`number:${number}`],
        trace: { applied: [], skipped }
      };
    },
    graph: async ({ identityResolution }) => {
      let number = numberFromIdentity(identityResolution), nodeRef = graphNodeRefFromIdentity(identityResolution);
      if (typeof graph?.fetchEntityFindings != "function")
        return {
          owner: "unified_graph_law",
          status: CAPABILITY_STATUS.MISSING_ADAPTER,
          reason: "inject graph.fetchEntityFindings = fetchCanonicalGraphEntityFindings from src/lib/research/entityGraphFinding.js \u2014 W2 owns no graph engine and must not build a second resolver",
          findings: [],
          accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
          semanticClass: SEMANTIC_CLASS.CONTEXT,
          versionRefs: ["entityGraphFinding:canonical-adapter-required"]
        };
      if (!nodeRef)
        return {
          owner: "unified_graph_law",
          status: CAPABILITY_STATUS.CONTEXT_REQUIRED,
          reason: "no canonical graph node identity was handed off by the identity resolver",
          findings: [],
          accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
          semanticClass: SEMANTIC_CLASS.CONTEXT,
          sourceRefs: number == null ? [] : [`number:${number}`],
          trace: { identity_handoff: "absent" }
        };
      try {
        let findings = await graph.fetchEntityFindings(nodeRef), list = Array.isArray(findings) ? findings : [];
        return {
          owner: "unified_graph_law",
          status: CAPABILITY_STATUS.EXECUTED,
          findings: list,
          accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
          // Graph existence is identity/structure — it is not verification or governance.
          semanticClass: SEMANTIC_CLASS.CONTEXT,
          sourceRefs: [`node:${nodeRef}`],
          versionRefs: ["entityGraphFinding:entity-graph-v1"],
          trace: { node_id: nodeRef, finding_count: list.length }
        };
      } catch (error) {
        return {
          owner: "unified_graph_law",
          status: CAPABILITY_STATUS.FAILED,
          reason: error?.message ? String(error.message) : "canonical graph adapter failed",
          findings: [],
          accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
          semanticClass: SEMANTIC_CLASS.CONTEXT,
          trace: { node_id: nodeRef, error_class: error?.name || "Error" }
        };
      }
    },
    research_objects: async ({ identityResolution }) => {
      let number = numberFromIdentity(identityResolution);
      if (number == null)
        return {
          owner: "research_strategy_layer_law",
          status: CAPABILITY_STATUS.SKIPPED,
          reason: "no canonical number identity resolved",
          findings: []
        };
      if (typeof fetchResearchObjects != "function")
        return {
          owner: "research_strategy_layer_law",
          status: CAPABILITY_STATUS.CONTEXT_REQUIRED,
          reason: "research_objects are deliberately refused until a canonical access-filtered W2 adapter resolves authorization/privacy context",
          findings: [],
          accessClass: ACCESS_CLASS.SOURCE_ACCESS_CONTROLLED,
          semanticClass: SEMANTIC_CLASS.EVIDENCE,
          sourceRefs: [`number:${number}`],
          versionRefs: ["research_objects:canonical-access-filter-required"],
          trace: { access: "refused_fail_closed", reason: "canonical_access_filter_required" }
        };
      let rows;
      try {
        rows = await fetchResearchObjects(number, { limit: 25 });
      } catch (error) {
        return {
          owner: "research_strategy_layer_law",
          status: CAPABILITY_STATUS.CONTEXT_REQUIRED,
          reason: "access-filtered research_objects reader refused the request",
          findings: [],
          accessClass: ACCESS_CLASS.SOURCE_ACCESS_CONTROLLED,
          semanticClass: SEMANTIC_CLASS.EVIDENCE,
          sourceRefs: [`number:${number}`],
          versionRefs: ["research_objects:access-filtered-reader-v1"],
          trace: { access: "refused_by_reader", error_class: error?.name || "Error" }
        };
      }
      let list = Array.isArray(rows) ? rows : Array.isArray(rows?.data) ? rows.data : [], findings = researchObjectsToUniversalFindings(list);
      return {
        owner: "research_strategy_layer_law",
        status: findings.length ? CAPABILITY_STATUS.EXECUTED : CAPABILITY_STATUS.EXECUTED,
        findings,
        accessClass: ACCESS_CLASS.SOURCE_ACCESS_CONTROLLED,
        semanticClass: SEMANTIC_CLASS.EVIDENCE,
        sourceRefs: [`number:${number}`],
        versionRefs: ["research_objects:access-filtered-reader-v1"],
        // Counts only. Raw rows, statements, contributor names and privacy scopes never enter the
        // trace — the trace is returned to the caller exactly like the Bundle is.
        trace: { access: "access_filtered_reader", row_count: list.length, projected_findings: findings.length }
      };
    },
    els: async ({ identityResolution }) => numberFromIdentity(identityResolution) == null ? {
      owner: "els_single_engine_law",
      status: CAPABILITY_STATUS.SKIPPED,
      reason: "number-only W2 bridge does not own text/phrase ELS execution",
      findings: []
    } : {
      owner: "els_single_engine_law",
      status: CAPABILITY_STATUS.MISSING_ADAPTER,
      reason: numericLensMap.els?.reason || "no safe number-only ELS dispatch contract",
      findings: [],
      versionRefs: ["numericResearch:els:ADAPTER_NEEDED"]
    },
    "sequence:pi": makeSequenceExecutor("sequence:pi"),
    "sequence:fibonacci": makeSequenceExecutor("sequence:fibonacci")
  };
}
var createCanonicalW2Executors = createCanonicalNumberW2Executors;

// src/lib/research/gematriaMethodProfileW2Executor.js
var GEMATRIA_METHOD_PROFILE_ADAPTER_VERSION = "fn-method-profile-w2-v1", GEMATRIA_METHOD_PROFILE_MAX_METHODS = 32, clean14 = (value) => value == null ? "" : String(value).trim(), finiteNumber2 = (value) => {
  if (value == null || value === "") return null;
  let number = Number(value);
  return Number.isFinite(number) ? number : null;
};
function dependencyRule(rule) {
  if (!rule || typeof rule != "object" || Array.isArray(rule)) return null;
  let type = clean14(rule.type);
  return type ? {
    type,
    to: clean14(rule.to) || null,
    condition: clean14(rule.condition) || null,
    operator: clean14(rule.operator) || null,
    components: Array.isArray(rule.components) ? rule.components.map(clean14).filter(Boolean).slice(0, 8) : []
  } : null;
}
function methodProfileRow(row, registryRow = null) {
  return {
    methodKey: clean14(row?.method_key),
    displayLabel: clean14(row?.display_label || row?.method_key) || "\u05E9\u05D9\u05D8\u05D4",
    category: clean14(row?.category) || null,
    mathematicalFamily: clean14(row?.mathematical_family) || null,
    atomicOrComposite: clean14(row?.atomic_or_composite) || null,
    computedValue: finiteNumber2(row?.computed_value),
    definitionVersion: finiteNumber2(row?.definition_version),
    derivedFrom: Array.isArray(registryRow?.derived_from) ? registryRow.derived_from.map(clean14).filter(Boolean).slice(0, 8) : [],
    dependencyRules: Array.isArray(registryRow?.dependency_rules) ? registryRow.dependency_rules.map(dependencyRule).filter(Boolean).slice(0, 12) : [],
    dependencyVersion: finiteNumber2(registryRow?.dependency_version)
  };
}
function profileFinding(expression, row, registryRow, createdAt) {
  let method = methodProfileRow(row, registryRow);
  if (!method.methodKey || !Number.isFinite(method.computedValue)) return null;
  let value = Number(method.computedValue);
  return makeUniversalFinding({
    kind: "gematria-method-value",
    subject: { type: "phrase", key: expression, label: expression, value, lang: "he" },
    source: {
      engine: "gematria",
      adapter: GEMATRIA_METHOD_PROFILE_ADAPTER_VERSION,
      sourceRef: null,
      method: method.methodKey,
      corpus: null,
      lang: "he"
    },
    identity: {
      sourceIdentity: { methodKey: method.methodKey, expression, value },
      occurrence: null,
      entityRef: null,
      relationRef: null
    },
    verification: {
      claimed_expression: null,
      claimed_method: null,
      claimed_value: null,
      engine_method_tested: method.methodKey,
      engine_result: value,
      verification_state: "not_tested"
    },
    evidence: {
      refs: [],
      facts: [{
        type: "gematria-method-profile-value",
        method: method.methodKey,
        label: method.displayLabel,
        value,
        category: method.category,
        mathematical_family: method.mathematicalFamily,
        atomic_or_composite: method.atomicOrComposite,
        method_version: method.definitionVersion,
        derived_from: method.derivedFrom,
        dependency_rules: method.dependencyRules,
        dependency_version: method.dependencyVersion
      }],
      score: null,
      confidence: null
    },
    access: { tier: "public", reason: "ephemeral caller-scoped canonical method profile" },
    provenance: {
      createdBy: "ENGINE:fn_method_profile",
      createdAt,
      inputRef: null
    },
    projection: {
      anchors: [],
      relations: [],
      dimensions: { numeric: { methodKey: method.methodKey, value } }
    },
    view: { rendererHints: { role: "method-result" } }
  });
}
function createGematriaMethodProfileW2Executor({
  supabase,
  readMethodRegistry = null,
  maxMethods = GEMATRIA_METHOD_PROFILE_MAX_METHODS
} = {}) {
  if (typeof supabase?.rpc != "function") throw new Error("canonical Supabase RPC client required");
  let limit = Math.max(1, Math.min(Number(maxMethods) || GEMATRIA_METHOD_PROFILE_MAX_METHODS, GEMATRIA_METHOD_PROFILE_MAX_METHODS));
  return async ({ identityResolution }) => {
    let representation = expandResearchTextRepresentations(identityResolution, { maxRepresentations: 1 })[0];
    if (!representation?.text)
      return {
        owner: "research_strategy_layer_law",
        status: CAPABILITY_STATUS.SKIPPED,
        reason: "no eligible expression resolved for canonical method-profile execution",
        findings: [],
        accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
        semanticClass: SEMANTIC_CLASS.EVIDENCE,
        versionRefs: [GEMATRIA_METHOD_PROFILE_ADAPTER_VERSION],
        cost: { certainty: "not_billable", ai_calls: 0, rpc_calls: 0, retry_count: 0 }
      };
    try {
      let registryPromise = typeof readMethodRegistry == "function" ? Promise.resolve().then(() => readMethodRegistry()).catch(() => ({ rows: [], status: "unavailable" })) : Promise.resolve({ rows: [], status: "not_requested" }), [response, registryRead] = await Promise.all([
        supabase.rpc("fn_method_profile", {
          p_phrase: representation.text,
          p_depth: "value"
        }),
        registryPromise
      ]);
      if (response?.error) throw response.error;
      let rawRows = Array.isArray(response?.data ?? response) ? response?.data ?? response : [], registryRows = Array.isArray(registryRead?.rows) ? registryRead.rows : [], registryByMethod = new Map(registryRows.map((row) => [clean14(row?.method_key), row])), createdAt = (/* @__PURE__ */ new Date()).toISOString(), findings = rawRows.slice(0, limit).map((row) => profileFinding(
        clean14(representation.text),
        row,
        registryByMethod.get(clean14(row?.method_key)) || null,
        createdAt
      )).filter(Boolean);
      return {
        owner: "research_strategy_layer_law",
        status: findings.length ? CAPABILITY_STATUS.EXECUTED : CAPABILITY_STATUS.NEGATIVE_RESULT,
        reason: findings.length ? null : "fn_method_profile returned no reportable method values",
        findings,
        accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
        semanticClass: SEMANTIC_CLASS.EVIDENCE,
        sourceRefs: [],
        versionRefs: [GEMATRIA_METHOD_PROFILE_ADAPTER_VERSION, "fn_method_profile:canonical", "canonical_methods_registry_law:v6"],
        cost: {
          certainty: "not_billable",
          ai_calls: 0,
          rpc_calls: 1,
          rest_calls: typeof readMethodRegistry == "function" ? 1 : 0,
          retry_count: 0
        },
        bounded: {
          total_count: rawRows.length,
          returned_count: findings.length,
          truncated: rawRows.length > limit,
          ordering: "fn_method_profile_registry_order",
          continuation: null
        },
        trace: {
          representation_count: 1,
          method_count: findings.length,
          profile_source: "fn_method_profile",
          registry_source: "public.gematria_methods",
          registry_status: clean14(registryRead?.status) || "unavailable",
          registry_row_count: registryRows.length
        }
      };
    } catch (error) {
      return {
        owner: "research_strategy_layer_law",
        status: CAPABILITY_STATUS.FAILED,
        reason: error instanceof Error ? error.message : String(error),
        findings: [],
        accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
        semanticClass: SEMANTIC_CLASS.EVIDENCE,
        versionRefs: [GEMATRIA_METHOD_PROFILE_ADAPTER_VERSION],
        cost: { certainty: "not_billable", ai_calls: 0, rpc_calls: 1, retry_count: 0 }
      };
    }
  };
}

// src/theme.js
var C = {
  bg: "#0C0818",
  bgGlow: "#1A1230",
  gold: "#d4af37",
  goldLight: "#e8c840",
  goldBright: "#f6e27a",
  goldDim: "#9a7818",
  goldDark: "#3a2200",
  goldDeep: "#1a0e00",
  crimson: "#7a1320",
  crimsonLight: "#a01f2e",
  royal: "'Assistant', Arial, sans-serif",
  royalLight: "#6b3fa0",
  surface: "#0d0a0e",
  surface2: "#140f0c",
  border: "rgba(212,175,55,0.18)",
  borderGold: "rgba(212,175,55,0.38)",
  muted: "#cfc9d6",
  faint: "#1a0f0a",
  danger: "#8B2020"
};
var GEM = { \u05D0: 1, \u05D1: 2, \u05D2: 3, \u05D3: 4, \u05D4: 5, \u05D5: 6, \u05D6: 7, \u05D7: 8, \u05D8: 9, \u05D9: 10, \u05DB: 20, \u05DA: 20, \u05DC: 30, \u05DE: 40, \u05DD: 40, \u05E0: 50, \u05DF: 50, \u05E1: 60, \u05E2: 70, \u05E4: 80, \u05E3: 80, \u05E6: 90, \u05E5: 90, \u05E7: 100, \u05E8: 200, \u05E9: 300, \u05EA: 400 };
var POST_CONTENT_CSS = `
  .sod-post-content { direction: rtl; color: #ede4d3; overflow-x: hidden; font-family: 'Heebo', sans-serif; text-align: center; }
  .sod-post-content h1, .sod-post-content h2, .sod-post-content h3,
  .sod-post-content h4, .sod-post-content h5 {
    font-family: 'Heebo', sans-serif;
    font-weight: 700;
    line-height: 1.3;
    margin: 2.4em 0 0.9em;
    letter-spacing: 0;
    text-align: center;
  }
  .sod-post-content h1 {
    color: ${C.goldBright};
    font-size: clamp(18px, 2.6vw, 27px);
    text-shadow: 0 0 40px ${C.goldDeep};
  }
  .sod-post-content h2 {
    color: ${C.goldLight};
    font-size: clamp(14px, 2.1vw, 22px);
  }
  .sod-post-content h3 {
    color: ${C.gold};
    font-size: clamp(14px, 1.8vw, 19px);
  }
  .sod-post-content p {
    color: #ede4d3;
    font-family: 'Heebo', sans-serif;
    font-size: 16.5px;
    line-height: 2.1;
    margin: 0 0 1.4em;
  }
  .sod-post-content a {
    color: ${C.gold} !important;
    text-decoration: underline !important;
    text-underline-offset: 3px;
    display: inline-block;
    transition: color 0.18s, transform 0.16s ease, text-shadow 0.18s ease;
    -webkit-tap-highlight-color: transparent;
  }
  .sod-post-content a:hover,
  .sod-post-content a:focus {
    color: ${C.goldBright} !important;
    transform: scale(1.07);
    text-shadow: 0 0 12px ${C.gold};
  }
  .sod-post-content a:active {
    color: #fff !important;
    transform: scale(0.95);
    opacity: 0.85;
  }
  .sod-post-content a:visited { color: ${C.goldLight} !important; }
  /* canonical_colors_law \u2014 \u05DB\u05E4\u05EA\u05D5\u05E8\u05D9 \u05D6\u05D4\u05D1 \u05D1\u05E4\u05D5\u05E1\u05D8: \u05D8\u05E7\u05E1\u05D8 \u05DB\u05D4\u05D4, \u05DC\u05E2\u05D5\u05DC\u05DD \u05DC\u05D0 \u05D6\u05D4\u05D1-\u05E2\u05DC-\u05D6\u05D4\u05D1 */
  .sod-post-content a[style*="gradient"],
  .sod-post-content a[style*="#e9c84a"],
  .sod-post-content a[style*="#d4af37"],
  .sod-post-content a[style*="#caa030"],
  .sod-post-content a[style*="#ffe9a8"],
  .sod-post-content a[style*="#e8c840"] {
    color: #1a0e00 !important;
    text-shadow: none !important;
  }
  .sod-post-content a[style*="gradient"]:hover,
  .sod-post-content a[style*="#e9c84a"]:hover {
    color: #1a0e00 !important; text-shadow: none !important;
  }
  /* \u{1F451} sod-post-cta \u2014 \u05DB\u05E4\u05EA\u05D5\u05E8 \u05E7\u05E8\u05D9\u05D0\u05D4-\u05DC\u05E4\u05E2\u05D5\u05DC\u05D4 \u05E7\u05E0\u05D5\u05E0\u05D9 \u05D1\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD (post_cta_law). \u05DE\u05D7\u05DC\u05D9\u05E3 \u05D0\u05EA \u05D4\u05D6\u05D9\u05D4\u05D5\u05D9-\u05DC\u05E4\u05D9-hex
     \u05D4\u05E9\u05D1\u05D9\u05E8 \u05DC\u05DE\u05E2\u05DC\u05D4: \u05E7\u05DC\u05D0\u05E1 \u05D3\u05D8\u05E8\u05DE\u05D9\u05E0\u05D9\u05E1\u05D8\u05D9, \u05EA\u05D9\u05D1\u05EA-\u05D6\u05D4\u05D1 + \u05D8\u05E7\u05E1\u05D8 \u05DB\u05D4\u05D4, \u05E7\u05E8\u05D9\u05D0 \u05D1\u05E9\u05E0\u05D9 \u05D4\u05DE\u05E6\u05D1\u05D9\u05DD.
     \u05E9\u05D9\u05DE\u05D5\u05E9: <a class="sod-post-cta" href="/codes">\u{1F4DA} \u05D8\u05E7\u05E1\u05D8 \u2190</a>. \u26A0\uFE0F \u05E7\u05E0\u05D5\u05E0\u05D9 \u05D1\u05E9\u05E0\u05D9 \u05E2\u05D5\u05EA\u05E7\u05D9 POST_CONTENT_CSS. */
  .sod-post-content a.sod-post-cta {
    display: inline-flex !important; align-items: center; gap: 8px;
    background: linear-gradient(180deg, #e8c84a, #c9a227) !important;
    color: #1a0e00 !important; text-decoration: none !important;
    border: none !important; border-radius: 999px; padding: 13px 28px; margin: 8px auto;
    font-weight: 800; font-size: 16px; box-shadow: 0 4px 16px rgba(0,0,0,.28);
    transform: none !important; text-shadow: none !important;
  }
  .sod-post-content a.sod-post-cta:hover { color: #1a0e00 !important; filter: brightness(1.06); transform: translateY(-1px) !important; text-shadow: none !important; }
  [data-theme="light"] .sod-post-content.clean a.sod-post-cta,
  [data-theme="light"] .sod-post-content a.sod-post-cta { color: #1a0e00 !important; background: linear-gradient(180deg, #e8c84a, #c9a227) !important; }
  .sod-post-content img {
    max-width: 100%;
    height: auto;
    display: block;
    margin: 2em auto;
    border-radius: 2px;
    border: 1px solid ${C.border};
    filter: brightness(0.85) sepia(0.15);
  }
  .sod-post-content ul, .sod-post-content ol {
    padding-right: 1.6em;
    margin: 0 0 1.4em;
  }
  .sod-post-content li {
    color: #ede4d3;
    font-family: 'Heebo', sans-serif;
    font-size: 16.5px;
    line-height: 2;
    margin-bottom: 0.4em;
  }
  .sod-post-content blockquote {
    border-right: 3px solid ${C.gold};
    margin: 2em 0;
    padding: 16px 24px;
    background: ${C.surface};
    border-radius: 0 2px 2px 0;
  }
  .sod-post-content blockquote p {
    color: ${C.goldLight};
    font-style: italic;
    margin: 0;
  }
  .sod-post-content code {
    background: ${C.faint};
    color: ${C.goldLight};
    padding: 2px 6px;
    border-radius: 2px;
    font-family: 'Courier New', monospace;
    font-size: 13px;
  }
  .sod-post-content pre {
    background: ${C.surface};
    border: 1px solid ${C.border};
    border-radius: 2px;
    padding: 20px;
    overflow-x: auto;
    margin: 1.6em 0;
  }
  .sod-post-content pre code { background: none; padding: 0; }
  .sod-post-content hr {
    border: none;
    border-top: 1px solid ${C.border};
    margin: 2.5em 0;
  }
  .sod-post-content strong { color: ${C.goldLight}; font-weight: 700; }
  .sod-post-content em { font-style: italic; color: ${C.gold}; }
  .sod-post-content figure { margin: 2em 0; }
  .sod-post-content figcaption {
    text-align: center;
    font-size: 14px;
    color: ${C.muted};
    font-family: 'Heebo', sans-serif;
    margin-top: 8px;
    letter-spacing: 1px;
  }
  .sod-post-content .wp-block-quote { border-right: 3px solid ${C.gold}; }

  /* \u2500\u2500 iframes & embeds \u2500\u2500 */
  .sod-post-content iframe {
    display: block;
    width: 100% !important;
    max-width: 100% !important;
    aspect-ratio: 16/9;
    height: auto !important;
    margin: 1.5em auto !important;
    border: none;
    direction: ltr;
  }
  .sod-post-content .wp-block-embed,
  .sod-post-content figure.wp-block-embed {
    max-width: 100%;
    margin: 2em auto;
    direction: ltr;
  }
  .sod-post-content .wp-block-embed__wrapper {
    position: relative;
    padding-bottom: 56.25%;
    height: 0;
    overflow: hidden;
  }
  .sod-post-content .wp-block-embed__wrapper iframe {
    position: absolute;
    top: 0; left: 0;
    width: 100% !important;
    height: 100% !important;
    aspect-ratio: unset;
    margin: 0 !important;
  }
  .sod-post-content .embed-youtube,
  .sod-post-content span.embed-youtube {
    display: block !important;
    max-width: 100% !important;
    margin: 1.5em auto !important;
    text-align: center;
  }
  .sod-post-content .embed-youtube iframe {
    width: 100% !important;
    max-width: 100% !important;
    aspect-ratio: 16/9;
    height: auto !important;
  }
  .sod-post-content .wp-video {
    width: auto !important;
    max-width: min(100%, 360px) !important;
    margin: 1.5em auto !important;
    display: block !important;
  }
  .sod-post-content .post-author {
    display: block;
    text-align: right;
    color: #c9a535;
    font-style: italic;
    font-family: 'Heebo', sans-serif;
    font-size: 14px;
    letter-spacing: 1px;
    margin: 6px 0;
    opacity: 0.92;
  }
  .sod-post-content:not(.clean) div[style*="height"] { height: auto !important; max-height: 24px !important; }
  .sod-post-content:not(.clean) div[style*="min-height"] { min-height: 0 !important; }
  .sod-post-content .elementor-spacer,
  .sod-post-content .elementor-spacer-inner { height: 16px !important; }
  /* \u2500\u2500 \u05E8\u05D9\u05D1\u05D5\u05E2 \u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D4 \u05E7\u05E0\u05D5\u05E0\u05D9 (post_gematria_box_law) \u2500\u2500
     \u05E4\u05EA\u05E8\u05D5\u05DF \u05E9\u05D5\u05E8\u05E9 \u05DC-legacy_content_protocol \xA71: \u05DB\u05DC \u05D4\u05E1\u05D2\u05E0\u05D5\u05DF (\u05DB\u05D5\u05DC\u05DC line-height) \u05D7\u05D9 \u05D1\u05E7\u05DC\u05D0\u05E1,
     \u05DB\u05DA \u05E9\u05D4-div\u05D9\u05DD \u05D0\u05D9\u05E0\u05DD \u05DE\u05DB\u05D9\u05DC\u05D9\u05DD "height" \u05D1-inline \u05D5\u05DC\u05D0 \u05E0\u05EA\u05E4\u05E1\u05D9\u05DD \u05D1\u05DB\u05DC\u05DC \u05D4\u05E0\u05D9\u05E7\u05D5\u05D9 \u05E9\u05DE\u05D5\u05D7\u05E5 \u05DC-24px.
     \u05D4-override \u05DC\u05DE\u05D8\u05D4 (\u05E1\u05E4\u05E6\u05D9\u05E4\u05D9\u05D5\u05EA 0,3,1 > 0,2,1 \u05E9\u05DC \u05D4\u05DB\u05DC\u05DC \u05D4\u05DE\u05D5\u05D7\u05E5) \u05D4\u05D5\u05D0 \u05D4\u05D2\u05E0\u05D4 \u05E0\u05D5\u05E1\u05E4\u05EA \u05D0\u05DD \u05D1\u05DB\u05DC \u05D6\u05D0\u05EA
     \u05D9\u05D9\u05DB\u05E0\u05E1 height inline. \u05E9\u05D9\u05DE\u05D5\u05E9: <div class="sod-gematria-box"> \u2026 </div>. */
  .sod-post-content .sod-gematria-box {
    max-width: 560px; margin: 30px auto; padding: 16px 18px; border-radius: 14px;
    background: linear-gradient(135deg, rgba(212,175,55,0.10), rgba(8,5,16,0.40));
    border: 1px solid rgba(212,175,55,0.45); direction: rtl; text-align: right;
  }
  .sod-post-content .sod-gematria-box div[style*="height"] { max-height: none !important; height: auto !important; }
  .sod-post-content .sod-gematria-box .gb-title { font-weight: 800; color: ${C.goldBright}; font-size: 1.02em; margin-bottom: 10px; }
  .sod-post-content .sod-gematria-box .gb-rows { color: #e6e0d2; line-height: 1.95; }
  .sod-post-content .sod-gematria-box .gb-rows > div { margin-top: 6px; }
  .sod-post-content .sod-gematria-box .gb-rows > div:first-child { margin-top: 0; }
  .sod-post-content .sod-gematria-box .gb-note { margin-top: 10px; font-size: 0.85em; color: #a59b80; line-height: 1.6; }
  .sod-post-content .sod-gematria-box b { color: ${C.goldBright}; }
  /* convergence_display_law (\u05D7\u05E7\u05D5\u05E7): \u05DB\u05DC \u05E9\u05D5\u05E8\u05D4 = \u05D1\u05D9\u05D8\u05D5\u05D9 \u05D0\u05D7\u05D3 + \u05D4\u05E2\u05E8\u05DA \u05E9\u05DC\u05D5 \u05DE\u05D9\u05DE\u05D9\u05DF (\u05D2\u05DC\u05D5\u05DC\u05EA-\u05D6\u05D4\u05D1). */
  .sod-post-content .sod-gematria-box .gb-line { display: flex; align-items: baseline; gap: 10px; margin-top: 8px; }
  .sod-post-content .sod-gematria-box .gb-line:first-child { margin-top: 0; }
  .sod-post-content .sod-gematria-box .gb-val { flex: 0 0 auto; min-width: 56px; text-align: center; font-weight: 800; color: #241a02 !important; background: linear-gradient(135deg, #ffd86b, #d8b34a); border-radius: 8px; padding: 2px 9px; font-size: 0.94em; font-variant-numeric: tabular-nums; }
  .sod-post-content .sod-gematria-box .gb-line .gb-val a { color: #241a02 !important; text-decoration: none !important; border: 0 !important; }
  .sod-post-content .sod-gematria-box .gb-phrase { flex: 1 1 auto; line-height: 1.55; min-width: 0; }

  /* \u{1F4DC} \u05E4\u05E1\u05D5\u05E7 \u2014 \u05E7\u05D5\u05E4\u05E1\u05EA \u05E6\u05D9\u05D8\u05D5\u05D8 \u05E7\u05E0\u05D5\u05E0\u05D9\u05EA (post_verse_law): \u05EA\u05E7\u05D9\u05DF \u05D1\u05E9\u05E0\u05D9 \u05D4\u05DE\u05E6\u05D1\u05D9\u05DD (\u05DB\u05D4\u05D4+\u05D1\u05D4\u05D9\u05E8) \u05D1\u05DC\u05D9 inline.
     \u05E9\u05D9\u05DE\u05D5\u05E9: <blockquote class="sod-verse">\u2026\xAB\u05E4\u05E1\u05D5\u05E7\xBB\u2026 <b>\u05DE\u05D9\u05DC\u05D9\u05DD \u05DE\u05D5\u05D3\u05D2\u05E9\u05D5\u05EA</b></blockquote>. */
  .sod-post-content .sod-verse {
    max-width: 620px; margin: 18px auto; padding: 12px 18px; border-radius: 8px;
    border-inline-start: 3px solid ${C.goldBright}; direction: rtl; text-align: right;
    background: rgba(212,175,55,0.06); color: #f0e9d6;
    font-size: 1.05em; line-height: 2.05; font-weight: 500;
  }
  .sod-post-content .sod-verse b { color: ${C.goldBright}; font-weight: 700; }
  [data-theme="light"] .sod-post-content .sod-verse {
    border-inline-start-color: #b07d12; background: rgba(176,125,18,0.07); color: #2a2416;
  }
  [data-theme="light"] .sod-post-content .sod-verse b { color: #8a6410; }

  /* post_text_colors_law v3 (\u05D7\u05E7\u05D5\u05E7): \u05E2\u05D9\u05E6\u05D5\u05D1 \u05D1\u05E8\u05D9\u05E8\u05EA-\u05D4\u05DE\u05D7\u05D3\u05DC \u05E9\u05DC \u05E4\u05D5\u05E1\u05D8 \xAB\u05E9\u05DC \u05D4\u05DE\u05E6\u05D9\u05D0\u05D5\u05EA\xBB \u2014 \u05DC\u05D0 \u05D5\u05D5\u05E8\u05D3\u05E4\u05E8\u05E1.
     \u05D8\u05E7\u05E1\u05D8 \u05E8\u05E5: \u05DC\u05D1\u05DF \u05E8\u05DA, \u05DE\u05E9\u05E7\u05DC \u05E8\u05D2\u05D9\u05DC, \u05E0\u05E2\u05D9\u05DD \u05DC\u05E2\u05D9\u05DF. \u05D6\u05D4\u05D1 \u05E9\u05DE\u05D5\u05E8 \u05DC\u05E2\u05E8\u05DB\u05D9\u05DD \u05D5\u05DC\u05D0\u05E7\u05E1\u05E0\u05D8\u05D9\u05DD \u2014 \u05DC\u05D0 \u05D4\u05DB\u05DC \u05E6\u05D4\u05D5\u05D1.
     \u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D4 = data-gem \u2192 \u05E4\u05D5\u05EA\u05D7\u05EA \u05D0\u05EA \u05DE\u05D2\u05D9\u05E8\u05EA \u05D4\u05DE\u05E1\u05E4\u05E8 \u05D1\u05EA\u05D5\u05DA \u05D4\u05D3\u05E3 (\u05DC\u05D0 \u05E0\u05D9\u05D5\u05D5\u05D8 \u05D4\u05D7\u05D5\u05E6\u05D4).
     \u05D1\u05D9\u05D8\u05D5\u05D9: \u05D1\u05E6\u05D1\u05E2 \u05D4\u05D8\u05E7\u05E1\u05D8 + \u05E7\u05D5-\u05D6\u05D4\u05D1 \u05DE\u05E0\u05D5\u05E7\u05D3 \u05E2\u05D3\u05D9\u05DF \xB7 \u05E2\u05E8\u05DA \u05DE\u05E1\u05E4\u05E8\u05D9: \u05D6\u05D4\u05D1. \u05DE\u05E6\u05D1 \u05D1\u05D4\u05D9\u05E8: \u05D8\u05E7\u05E1\u05D8 \u05DB\u05D4\u05D4, \u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D4 \u05D0\u05D3\u05D5\u05DE\u05D4. */
  .sod-post-content.clean { color: #ffffff; }
  .sod-post-content.clean p { color: #ffffff; font-size: 16.5px; line-height: 2.1; font-weight: 400; }
  [data-theme="light"] .sod-post-content.clean p { color: #1c1c1c; }
  /* \u{1F41B} \u05E4\u05E8\u05D9\u05D8\u05D9-\u05E8\u05E9\u05D9\u05DE\u05D4: \u05DC-li \u05D9\u05E9 color:#ede4d3 \u05E7\u05D1\u05D5\u05E2 (\u05D8\u05D5\u05D1 \u05DC\u05DC\u05D9\u05DC\u05D4) \u05D1\u05DC\u05D9 override \u05DC\u05D9\u05D5\u05DD \u2192 \u05E0\u05D1\u05DC\u05E2 \u05E7\u05E8\u05DD-\u05E2\u05DC-\u05E7\u05E8\u05DD (post_theme_safe_colors_law). */
  .sod-post-content.clean li { color: #ede4d3; }
  [data-theme="light"] .sod-post-content.clean li { color: #1c1c1c; }
  .sod-post-content.clean .sod-gemlink { color: inherit !important; font-weight: 600; border-bottom: 1px dotted rgba(255,216,107,.6); }
  .sod-post-content.clean .sod-numlink { color: #ffd86b !important; font-weight: 700; }
  .sod-post-content.clean .sod-gematria-box .gb-rows { font-weight: 400; line-height: 2.05; }
  .sod-post-content.clean .sod-gematria-box .gb-rows b { color: #ffd86b; }
  .sod-post-content.clean a[href^="/number/"] { color: #ffd86b !important; font-weight: 600; text-decoration: none !important; border-bottom: 1px dotted rgba(255,216,107,.55); display: inline; }
  [data-theme="light"] .sod-post-content.clean { color: #1c1c1c; }
  [data-theme="light"] .sod-post-content.clean .sod-gemlink { border-bottom-color: rgba(200,16,46,.55); }
  [data-theme="light"] .sod-post-content.clean .sod-numlink { color: #c8102e !important; }
  [data-theme="light"] .sod-post-content.clean .sod-gematria-box .gb-rows b { color: #c8102e; }
  [data-theme="light"] .sod-post-content.clean a[href^="/number/"] { color: #c8102e !important; border-bottom-color: rgba(200,16,46,.5); }
  /* \u05D0\u05D9\u05D9\u05DD \u05DB\u05D4\u05D9\u05DD (sgx/sgl \u2014 \u05E8\u05E7\u05E2 \u05DB\u05D4\u05D4 \u05E7\u05D1\u05D5\u05E2): \u05E0\u05E9\u05D0\u05E8\u05D9\u05DD \u05D1\u05E2\u05D5\u05DC\u05DD \u05D4\u05D6\u05D4\u05D1 \u05D2\u05DD \u05D1\u05DE\u05E6\u05D1 \u05D1\u05D4\u05D9\u05E8 */
  [data-theme="light"] .sod-post-content.clean .sgx .sod-numlink, [data-theme="light"] .sod-post-content.clean .sgl .sod-numlink { color: #ffd86b !important; }
  [data-theme="light"] .sod-post-content.clean .sgx .sod-gemlink, [data-theme="light"] .sod-post-content.clean .sgl .sod-gemlink { border-bottom-color: rgba(255,216,107,.55); }
  /* \u{1F517} \u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D4 \u05DC\u05D7\u05D9\u05E6\u05D4 \u2014 \u05E1\u05DE\u05DF-\u05D9\u05D3 \u05D1\u05DC\u05D1\u05D3 (\u05E4\u05D5\u05EA\u05D7 \u05DE\u05D2\u05D9\u05E8\u05EA-\u05DE\u05E1\u05E4\u05E8). \u26A0\uFE0F \u05D0\u05E1\u05D5\u05E8 \u05DC\u05DB\u05E4\u05D5\u05EA \u05DB\u05D0\u05DF \u05E6\u05D1\u05E2\u05D9-sgx: \u05E4\u05D5\u05E1\u05D8 \u05D2\u05E8\u05E4\u05D9 \u05D4\u05D5\u05D0
     self-contained \u05E2\u05DD <style> \u05DE\u05D5\u05D8\u05DE\u05E2 \u05DE\u05D5\u05D3\u05E2-\u05EA\u05DE\u05D4 \u05DE\u05E9\u05DC\u05D5 (\u05E8\u05E7\u05E2+\u05E6\u05D1\u05E2\u05D9\u05DD \u05DC\u05D9\u05D5\u05DD/\u05DC\u05D9\u05DC\u05D4) \u2014 \u05DB\u05DC\u05DC \u05E7\u05E0\u05D5\u05E0\u05D9 \u05D1\u05E1\u05E4\u05E6\u05D9\u05E4\u05D9\u05D5\u05EA \u05D2\u05D1\u05D5\u05D4\u05D4
     \u05D9\u05D3\u05E8\u05D5\u05E1 \u05D0\u05D5\u05EA\u05D5 \u05D5\u05D9\u05D4\u05E8\u05D5\u05E1 \u05D0\u05EA \u05D4\u05E2\u05D9\u05E6\u05D5\u05D1. \u05D4\u05E6\u05D1\u05E2\u05D9\u05DD \u05E0\u05E9\u05D0\u05E8\u05D9\u05DD \u05E9\u05DC \u05D4\u05E4\u05D5\u05E1\u05D8/\u05D4\u05E7\u05E0\u05D5\u05E0\u05D9 \u05D4\u05E7\u05D9\u05D9\u05DD. (post_text_colors_law v6) */
  .sod-post-content.clean [data-gem] { cursor: pointer; }
  /* \u{1F4CF} \u05E9\u05D5\u05E8\u05D4-\u05DC\u05D7\u05D9\u05E6\u05D4 \u05E9\u05DC\u05DE\u05D4 \u05E9\u05E4\u05D5\u05EA\u05D7\u05EA \u05D0\u05EA \u05D7\u05DC\u05D5\u05E0\u05D9\u05EA \u05D4\u05DE\u05E1\u05E4\u05E8 \u2014 <div class="sod-numrow" data-gem="\u05E2\u05E8\u05DA">\u2026\u05E9\u05D5\u05E8\u05D4\u2026</div>.
     \u05DB\u05DC \u05D4\u05E9\u05D5\u05E8\u05D4 \u05DC\u05D7\u05D9\u05E6\u05D4 (data-gem \u05EA\u05D5\u05E4\u05E1 \u05D0\u05D5\u05EA\u05D4 \u05D3\u05E8\u05DA openNumberDrawer), \u05E2\u05DD \u05D0\u05E4\u05E7\u05D8-\u05E8\u05D9\u05D7\u05D5\u05E3 \u05E2\u05D3\u05D9\u05DF \u05D5\u05E7\u05D5-\u05E6\u05D3 \u05DE\u05D5\u05D1\u05D9\u05DC. */
  .sod-post-content.clean .sod-numrow { cursor: pointer; display: block; border-inline-start: 3px solid rgba(212,175,55,.5); padding: 4px 12px; margin: 6px 0; border-radius: 6px; transition: background .15s ease; }
  .sod-post-content.clean .sod-numrow:hover { background: rgba(212,175,55,.10); }
  [data-theme="light"] .sod-post-content.clean .sod-numrow { border-inline-start-color: rgba(200,16,46,.45); }
  [data-theme="light"] .sod-post-content.clean .sod-numrow:hover { background: rgba(200,16,46,.07); }
  /* \u{1F3A8} \u05E6\u05D1\u05E2\u05D9-\u05DE\u05D9\u05DC\u05D4 \u05DE\u05D5\u05D3\u05E2\u05D9-\u05EA\u05DE\u05D4 (\u05DB\u05E4\u05EA\u05D5\u05E8\u05D9 \u05D4\u05E6\u05D1\u05E2 \u05D1\u05E2\u05D5\u05E8\u05DA) \u2014 \u05E0\u05E9\u05DE\u05E8\u05D9\u05DD \u05DB\u05E7\u05DC\u05D0\u05E1, \u05DC\u05D0 inline, \u05DB\u05D3\u05D9 \u05DC\u05E2\u05D1\u05D5\u05D3 \u05D9\u05D5\u05DD+\u05DC\u05D9\u05DC\u05D4.
     \u05E2\u05E8\u05DA \u05D6\u05D4\u05D4 \u05D1\u05E9\u05E0\u05D9 \u05D4\u05DE\u05E6\u05D1\u05D9\u05DD \u05D4\u05D9\u05DB\u05DF \u05E9\u05D4\u05E0\u05D9\u05D2\u05D5\u05D3\u05D9\u05D5\u05EA \u05DE\u05E1\u05E4\u05D9\u05E7\u05D4; \u05D0\u05D3\u05D5\u05DD/\u05DB\u05D7\u05D5\u05DC/\u05D9\u05E8\u05D5\u05E7 \u05DE\u05E7\u05D1\u05DC\u05D9\u05DD \u05D2\u05D5\u05D5\u05DF \u05DB\u05D4\u05D4 \u05D9\u05D5\u05EA\u05E8 \u05D1\u05D1\u05D4\u05D9\u05E8. */
  .sod-post-content.clean .sc-gold  { color: #ffd86b !important; }
  .sod-post-content.clean .sc-red   { color: #ff7a6b !important; }
  .sod-post-content.clean .sc-blue  { color: #6fbcff !important; }
  .sod-post-content.clean .sc-green { color: #7fe0a0 !important; }
  .sod-post-content.clean .sc-violet{ color: #c9a4ff !important; }
  .sod-post-content.clean .sc-white { color: #ffffff !important; }
  .sod-post-content.clean .sc-hl    { background: rgba(212,175,55,.22); border-radius: 4px; padding: 0 3px; }
  [data-theme="light"] .sod-post-content.clean .sc-gold  { color: #9a7818 !important; }
  [data-theme="light"] .sod-post-content.clean .sc-red   { color: #c8102e !important; }
  [data-theme="light"] .sod-post-content.clean .sc-blue  { color: #1863c8 !important; }
  [data-theme="light"] .sod-post-content.clean .sc-green { color: #1a8a48 !important; }
  [data-theme="light"] .sod-post-content.clean .sc-violet{ color: #6a3fd0 !important; }
  [data-theme="light"] .sod-post-content.clean .sc-white { color: #1c1c1c !important; }
  [data-theme="light"] .sod-post-content.clean .sc-hl    { background: rgba(200,16,46,.14); }
  /* \u{1F317} post_theme_safe_colors_law \u2014 \u05D4\u05E9\u05DC\u05DE\u05EA \u05DE\u05E6\u05D1-\u05D1\u05D4\u05D9\u05E8 \u05DE\u05DC\u05D0\u05D4 \u05DC\u05E4\u05D5\u05E1\u05D8 \u05E0\u05E7\u05D9. \u05DB\u05DC \u05D0\u05DC\u05D4 \u05D4\u05D9\u05D5 \u05D6\u05D4\u05D1 *\u05D1\u05DC\u05D9*
     \u05D2\u05E8\u05E1\u05EA-\u05D1\u05D4\u05D9\u05E8 \u21D2 \u05E0\u05D1\u05DC\u05E2\u05D5 \u05E2\u05DC \u05E8\u05E7\u05E2 \u05E7\u05E8\u05DD: \u05DB\u05D5\u05EA\u05E8\u05D5\u05EA (h1/h2/h3), \u05DE\u05D5\u05D3\u05D2\u05E9 (strong), \u05E0\u05D8\u05D5\u05D9 (em), \u05E7\u05D9\u05E9\u05D5\u05E8\u05D9\u05DD
     \u05E9\u05D0\u05D9\u05E0\u05DD /number/ (\xAB\u05E8\u05D0\u05D5 \u05D2\u05DD\xBB \u05D5\u05DB\u05D5'), \u05DB\u05D9\u05EA\u05D5\u05D1\u05D9\u05DD, \u05E7\u05E8\u05D3\u05D9\u05D8-\u05DB\u05D5\u05EA\u05D1, \u05EA\u05D0\u05D9-\u05D8\u05D1\u05DC\u05D4. \u05E2\u05DB\u05E9\u05D9\u05D5 \u05E7\u05E8\u05D9\u05D0\u05D9\u05DD \u05D1\u05E9\u05E0\u05D9 \u05D4\u05DE\u05E6\u05D1\u05D9\u05DD.
     \u26A0\uFE0F \u05E7\u05E0\u05D5\u05E0\u05D9 \u05D1\u05E9\u05E0\u05D9 \u05E2\u05D5\u05EA\u05E7\u05D9 POST_CONTENT_CSS: legacy.jsx + theme.js \u2014 \u05DC\u05E2\u05D3\u05DB\u05DF \u05D0\u05EA \u05E9\u05E0\u05D9\u05D4\u05DD. */
  [data-theme="light"] .sod-post-content.clean h1,
  [data-theme="light"] .sod-post-content.clean h2,
  [data-theme="light"] .sod-post-content.clean h3 { color: #7a5e12; text-shadow: none; }
  [data-theme="light"] .sod-post-content.clean strong { color: #7a5e12; }
  [data-theme="light"] .sod-post-content.clean em { color: #7a5e12; }
  [data-theme="light"] .sod-post-content.clean a { color: #a5561a !important; }
  [data-theme="light"] .sod-post-content.clean a:visited { color: #7a4a12 !important; }
  [data-theme="light"] .sod-post-content.clean a:hover,
  [data-theme="light"] .sod-post-content.clean a:focus { color: #c8102e !important; }
  [data-theme="light"] .sod-post-content.clean figcaption { color: #6b6250; }
  [data-theme="light"] .sod-post-content.clean .post-author { color: #7a4a12; }
  [data-theme="light"] .sod-post-content.clean td { color: #33301f; }

  /* \u{1F524} \u05E2\u05E8\u05DB\u05EA \xAB\u05D2\u05E8\u05E4\u05D9\u05E7\u05EA-\u05E7\u05D5\u05D3\xBB \u05E7\u05E0\u05D5\u05E0\u05D9\u05EA (sgx) \u2014 \u05D0\u05E0\u05D9\u05DE\u05E6\u05D9\u05D5\u05EA CSS \u05DC\u05E4\u05D5\u05E1\u05D8\u05D9\u05DD \u05D2\u05E8\u05E4\u05D9\u05D9\u05DD (\u05E8"\u05EA/\u05E1"\u05EA, \u05D0\u05EA\u05D1"\u05E9, \u05D0\u05E0\u05D2\u05E8\u05DE\u05D5\u05EA).
     \u05D7\u05D9\u05D4 \u05DB\u05D0\u05DF \u05DB\u05DE\u05D5 sod-gematria-box: \u05D4\u05E4\u05D5\u05E1\u05D8 \u05DE\u05E9\u05EA\u05DE\u05E9 \u05D1\u05E7\u05DC\u05D0\u05E1\u05D9\u05DD \u05D1\u05DC\u05D1\u05D3, \u05D1\u05DC\u05D9 <style> \u05DE\u05E9\u05DC\u05D5 \u2014 \u05E4\u05EA\u05E8\u05D5\u05DF \u05DE\u05E2\u05E8\u05DB\u05EA\u05D9.
     \u05E9\u05D9\u05DE\u05D5\u05E9 \u05E8\u05D0\u05E9\u05D5\u05DF: \u05E4\u05D5\u05E1\u05D8 \u05D4\u05E7\u05D5\u05D3 \u05E9\u05DC \u05D4\u05E8\u05D1 \u05E2\u05DE\u05D5\u05E1 \u05D2\u05D5\u05D0\u05D8\u05D4 (id 5008). \u26A0\uFE0F \u05E9\u05E0\u05D9 \u05E2\u05D5\u05EA\u05E7\u05D9\u05DD: legacy.jsx + theme.js. */
  .sod-post-content .sgx { background: linear-gradient(170deg, #16112a, #0e0a1a); border: 1px solid rgba(232,200,74,.35); border-radius: 16px; padding: 26px 14px; margin: 26px 0; text-align: center; direction: rtl; overflow: hidden; }
  .sod-post-content .sgx-cap { color: #b6ab92; font-size: 13.5px; line-height: 1.9; margin-top: 14px; }
  .sod-post-content .sgx-cap b { color: #f0dc9a; }
  .sod-post-content .sgx-step { display: inline-block; background: rgba(232,200,74,.12); border: 1px solid rgba(232,200,74,.45); color: #e8c84a; border-radius: 999px; padding: 3px 14px; font-size: 12px; font-weight: 800; letter-spacing: 1px; margin-bottom: 14px; }
  .sod-post-content .sgx1-name { font-size: clamp(34px, 9vw, 52px); font-weight: 800; color: #ded5c2; letter-spacing: 2px; }
  .sod-post-content .sgx1-name .rt, .sod-post-content .sgx1-name .st { display: inline-block; animation: sgx-glow 2.6s ease-in-out infinite; }
  .sod-post-content .sgx1-name .rt { color: #ffd86b; text-shadow: 0 0 18px rgba(255,216,107,.7); }
  .sod-post-content .sgx1-name .st { color: #7fd4ff; text-shadow: 0 0 18px rgba(127,212,255,.7); animation-delay: -1.3s; }
  .sod-post-content .sgx1-out { margin-top: 16px; }
  .sod-post-content .sgx1-out i { display: inline-block; font-style: normal; font-size: clamp(26px, 7vw, 38px); font-weight: 800; margin: 0 4px; padding: 6px 14px; border-radius: 12px; background: rgba(232,200,74,.1); border: 1px solid rgba(232,200,74,.5); color: #f0dc9a; animation: sgx-pop 7s ease infinite; }
  .sod-post-content .sgx1-out i:nth-child(1) { animation-delay: -0.0s; color: #ffd86b; }
  .sod-post-content .sgx1-out i:nth-child(2) { animation-delay: -5.8s; color: #ffd86b; }
  .sod-post-content .sgx1-out i:nth-child(3) { animation-delay: -4.6s; color: #7fd4ff; border-color: rgba(127,212,255,.5); background: rgba(127,212,255,.08); }
  .sod-post-content .sgx1-out i:nth-child(4) { animation-delay: -3.4s; color: #7fd4ff; border-color: rgba(127,212,255,.5); background: rgba(127,212,255,.08); }
  .sod-post-content .sgx2-row { display: flex; gap: 10px; justify-content: center; flex-wrap: wrap; perspective: 700px; }
  .sod-post-content .sgx2-card { width: clamp(56px, 16vw, 76px); aspect-ratio: 3/4; position: relative; }
  .sod-post-content .sgx2-in { position: absolute; inset: 0; transform-style: preserve-3d; animation: sgx-flip 7s ease-in-out infinite; }
  .sod-post-content .sgx2-card:nth-child(1) .sgx2-in { animation-delay: -0.0s; }
  .sod-post-content .sgx2-card:nth-child(2) .sgx2-in { animation-delay: -0.4s; }
  .sod-post-content .sgx2-card:nth-child(3) .sgx2-in { animation-delay: -0.8s; }
  .sod-post-content .sgx2-card:nth-child(4) .sgx2-in { animation-delay: -1.2s; }
  .sod-post-content .sgx2-f, .sod-post-content .sgx2-b { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; border-radius: 12px; font-size: clamp(28px, 8vw, 40px); font-weight: 800; backface-visibility: hidden; -webkit-backface-visibility: hidden; }
  .sod-post-content .sgx2-f { background: rgba(232,200,74,.1); border: 1px solid rgba(232,200,74,.5); color: #f0dc9a; }
  .sod-post-content .sgx2-b { background: rgba(200,16,46,.14); border: 1px solid rgba(255,110,130,.55); color: #ff9caa; transform: rotateY(180deg); }
  .sod-post-content .sgx3-stage { position: relative; min-height: 150px; }
  .sod-post-content .sgx3-rowA, .sod-post-content .sgx3-rowB { position: absolute; inset-inline: 0; top: 0; display: flex; gap: 8px; justify-content: center; align-items: center; flex-wrap: wrap; }
  .sod-post-content .sgx3-rowA { animation: sgx-showA 10s ease infinite; }
  .sod-post-content .sgx3-rowB { animation: sgx-showB 10s ease infinite; }
  .sod-post-content .sgx3-tile { display: inline-flex; align-items: center; justify-content: center; width: clamp(40px, 11vw, 54px); aspect-ratio: 1; border-radius: 11px; font-size: clamp(22px, 6vw, 30px); font-weight: 800; background: rgba(232,200,74,.1); border: 1px solid rgba(232,200,74,.5); color: #f0dc9a; }
  .sod-post-content .sgx3-red { background: rgba(200,16,46,.16); border-color: rgba(255,110,130,.6); color: #ff9caa; }
  .sod-post-content .sgx3-plus { color: #8d8270; font-size: 22px; font-weight: 800; }
  .sod-post-content .sgx3-lbl { width: 100%; color: #b6ab92; font-size: 12.5px; margin-top: 10px; }
  .sod-post-content .sgx3-lbl b { color: #f0dc9a; }
  .sod-post-content .sgx-date { direction: ltr; unicode-bidi: isolate; font-size: clamp(30px, 9vw, 46px); font-weight: 800; color: #ffd86b; text-shadow: 0 0 30px rgba(255,216,107,.55); animation: sgx-beat 2.4s ease-in-out infinite; display: inline-block; }
  @keyframes sgx-glow { 0%,100% { transform: none; } 50% { transform: translateY(-7px) scale(1.12); } }
  @keyframes sgx-pop { 0%, 8% { opacity: 0; transform: translateY(16px) scale(.7); } 14%, 88% { opacity: 1; transform: none; } 96%, 100% { opacity: 0; transform: translateY(-10px) scale(.85); } }
  @keyframes sgx-flip { 0%, 34% { transform: rotateY(0); } 48%, 84% { transform: rotateY(180deg); } 100% { transform: rotateY(360deg); } }
  @keyframes sgx-showA { 0%, 38% { opacity: 1; transform: none; } 46%, 92% { opacity: 0; transform: translateY(-14px); } 100% { opacity: 1; transform: none; } }
  @keyframes sgx-showB { 0%, 40% { opacity: 0; transform: translateY(16px); } 50%, 90% { opacity: 1; transform: none; } 98%, 100% { opacity: 0; } }
  @media (prefers-reduced-motion: reduce) {
    .sod-post-content .sgx1-out i, .sod-post-content .sgx2-in, .sod-post-content .sgx3-rowA, .sod-post-content .sgx3-rowB,
    .sod-post-content .sgx1-name .rt, .sod-post-content .sgx1-name .st, .sod-post-content .sgx-date { animation: none !important; }
    .sod-post-content .sgx3-rowA { position: static; margin-bottom: 12px; }
    .sod-post-content .sgx3-rowB { position: static; }
  }
  /* ai_box_theme_aware \u2014 \u05DE\u05E6\u05D1 \u05D1\u05D4\u05D9\u05E8 (\u05D9\u05D5\u05DD): \u05E7\u05D5\u05E4\u05E1\u05D4 \u05D1\u05D4\u05D9\u05E8\u05D4 + \u05D8\u05E7\u05E1\u05D8 \u05DB\u05D4\u05D4 \u05D1\u05DE\u05E7\u05D5\u05DD \u05E0\u05D9\u05D5\u05D5\u05D9 \u05DB\u05D4\u05D4 \u05E2\u05DC \u05E7\u05DC\u05E3 */
  [data-theme="light"] .sod-post-content .sod-gematria-box {
    background: linear-gradient(135deg, rgba(176,125,18,0.10), rgba(255,255,255,0.72));
    border-color: rgba(176,125,18,0.5);
  }
  [data-theme="light"] .sod-post-content .sod-gematria-box .gb-title,
  [data-theme="light"] .sod-post-content .sod-gematria-box b { color: #8a6410; }
  [data-theme="light"] .sod-post-content .sod-gematria-box .gb-rows { color: #33301f; }
  [data-theme="light"] .sod-post-content .sod-gematria-box .gb-note { color: #756a52; }
  .sod-post-content:not(.clean) [style*="color:#000"],
  .sod-post-content:not(.clean) [style*="color: #000"],
  .sod-post-content:not(.clean) [style*="color:black"],
  .sod-post-content:not(.clean) [style*="color: black"],
  .sod-post-content:not(.clean) [style*="color:#111"],
  .sod-post-content:not(.clean) [style*="color:#222"],
  .sod-post-content:not(.clean) [style*="color:#333"] {
    color: #ede4d3 !important;
  }
  .sod-post-content:not(.clean) [style*="color:#0000ff"],
  .sod-post-content:not(.clean) [style*="color: #0000ff"],
  .sod-post-content:not(.clean) [style*="color:blue"],
  .sod-post-content:not(.clean) [style*="color: blue"] {
    color: ${C.goldBright} !important;
  }
  .sod-post-content video {
    max-width: min(100%, 360px) !important;
    width: auto !important;
    height: auto !important;
    display: block !important;
    margin: 1.5em auto !important;
  }
  .sod-post-content table {
    width: 100%; border-collapse: collapse; margin: 1.6em 0;
  }
  .sod-post-content th {
    background: ${C.goldDark}; color: ${C.goldBright};
    font-family: 'Heebo', sans-serif; font-size: 13.5px;
    padding: 10px 14px; text-align: right;
    border: 1px solid ${C.borderGold};
  }
  .sod-post-content td {
    color: ${C.goldDim}; padding: 9px 14px;
    border: 1px solid ${C.border};
    font-family: 'Heebo', sans-serif; font-size: 14px;
  }
  .sod-post-content tr:nth-child(even) td { background: ${C.surface}; }
`;

// src/lib/gematria.js
var onlyHeb = (s) => [...s || ""].filter((c) => GEM[c] != null), normalizeForCalc = (input) => String(input || "").replace(/[֑-ׇ]/g, "").replace(/[׳״"'‘’“”]/g, "").replace(/[,.;:()?!]/g, " ").replace(/\s+/g, " ").trim(), FINAL = { \u05DA: 500, \u05DD: 600, \u05DF: 700, \u05E3: 800, \u05E5: 900 };
var ORD = { \u05D0: 1, \u05D1: 2, \u05D2: 3, \u05D3: 4, \u05D4: 5, \u05D5: 6, \u05D6: 7, \u05D7: 8, \u05D8: 9, \u05D9: 10, \u05DB: 11, \u05DA: 11, \u05DC: 12, \u05DE: 13, \u05DD: 13, \u05E0: 14, \u05DF: 14, \u05E1: 15, \u05E2: 16, \u05E4: 17, \u05E3: 17, \u05E6: 18, \u05E5: 18, \u05E7: 19, \u05E8: 20, \u05E9: 21, \u05EA: 22 }, KID = { \u05D0: 1, \u05D1: 3, \u05D2: 6, \u05D3: 10, \u05D4: 15, \u05D5: 21, \u05D6: 28, \u05D7: 36, \u05D8: 45, \u05D9: 55, \u05DB: 75, \u05DA: 75, \u05DC: 105, \u05DE: 145, \u05DD: 145, \u05E0: 195, \u05DF: 195, \u05E1: 255, \u05E2: 325, \u05E4: 405, \u05E3: 405, \u05E6: 495, \u05E5: 495, \u05E7: 595, \u05E8: 795, \u05E9: 1095, \u05EA: 1495 }, ATB = { \u05D0: 400, \u05D1: 300, \u05D2: 200, \u05D3: 100, \u05D4: 90, \u05D5: 80, \u05D6: 70, \u05D7: 60, \u05D8: 50, \u05D9: 40, \u05DB: 30, \u05DA: 30, \u05DC: 20, \u05DE: 10, \u05DD: 10, \u05E0: 9, \u05DF: 9, \u05E1: 8, \u05E2: 7, \u05E4: 6, \u05E3: 6, \u05E6: 5, \u05E5: 5, \u05E7: 4, \u05E8: 3, \u05E9: 2, \u05EA: 1 }, ALB = { \u05D0: 30, \u05D1: 40, \u05D2: 50, \u05D3: 60, \u05D4: 70, \u05D5: 80, \u05D6: 90, \u05D7: 100, \u05D8: 200, \u05D9: 300, \u05DB: 400, \u05DA: 400, \u05DC: 1, \u05DE: 2, \u05DD: 2, \u05E0: 3, \u05DF: 3, \u05E1: 4, \u05E2: 5, \u05E4: 6, \u05E3: 6, \u05E6: 7, \u05E5: 7, \u05E7: 8, \u05E8: 9, \u05E9: 10, \u05EA: 20 }, ATBACH_L = { \u05D0: "\u05D8", \u05D1: "\u05D7", \u05D2: "\u05D6", \u05D3: "\u05D5", \u05D4: "\u05D4", \u05D5: "\u05D3", \u05D6: "\u05D2", \u05D7: "\u05D1", \u05D8: "\u05D0", \u05D9: "\u05E6", \u05DB: "\u05E4", \u05DC: "\u05E2", \u05DE: "\u05E1", \u05E0: "\u05E0", \u05E1: "\u05DE", \u05E2: "\u05DC", \u05E4: "\u05DB", \u05E6: "\u05D9", \u05E7: "\u05EA", \u05E8: "\u05E9", \u05E9: "\u05E8", \u05EA: "\u05E7", \u05DA: "\u05DA", \u05DD: "\u05E1", \u05DF: "\u05E0", \u05E3: "\u05DB", \u05E5: "\u05D9" }, ATBACH = Object.fromEntries(Object.keys(ATBACH_L).map((c) => [c, GEM[ATBACH_L[c]] || 0])), SHIFT_AFTER_L = { \u05D0: "\u05D1", \u05D1: "\u05D2", \u05D2: "\u05D3", \u05D3: "\u05D4", \u05D4: "\u05D5", \u05D5: "\u05D6", \u05D6: "\u05D7", \u05D7: "\u05D8", \u05D8: "\u05D9", \u05D9: "\u05DB", \u05DB: "\u05DC", \u05DA: "\u05DC", \u05DC: "\u05DE", \u05DE: "\u05E0", \u05DD: "\u05E0", \u05E0: "\u05E1", \u05DF: "\u05E1", \u05E1: "\u05E2", \u05E2: "\u05E4", \u05E4: "\u05E6", \u05E3: "\u05E6", \u05E6: "\u05E7", \u05E5: "\u05E7", \u05E7: "\u05E8", \u05E8: "\u05E9", \u05E9: "\u05EA", \u05EA: "\u05D0" }, SHIFT_BEFORE_L = { \u05D0: "\u05EA", \u05D1: "\u05D0", \u05D2: "\u05D1", \u05D3: "\u05D2", \u05D4: "\u05D3", \u05D5: "\u05D4", \u05D6: "\u05D5", \u05D7: "\u05D6", \u05D8: "\u05D7", \u05D9: "\u05D8", \u05DB: "\u05D9", \u05DA: "\u05D9", \u05DC: "\u05DB", \u05DE: "\u05DC", \u05DD: "\u05DC", \u05E0: "\u05DE", \u05DF: "\u05DE", \u05E1: "\u05E0", \u05E2: "\u05E1", \u05E4: "\u05E2", \u05E3: "\u05E2", \u05E6: "\u05E4", \u05E5: "\u05E4", \u05E7: "\u05E6", \u05E8: "\u05E7", \u05E9: "\u05E8", \u05EA: "\u05E9" }, shiftVals = (Lmap) => Object.fromEntries(Object.keys(Lmap).map((c) => [c, GEM[Lmap[c]] || 0])), SHIFT_AFTER = shiftVals(SHIFT_AFTER_L), SHIFT_BEFORE = shiftVals(SHIFT_BEFORE_L), MILUI = { \u05D0: 111, \u05D1: 412, \u05D2: 83, \u05D3: 434, \u05D4: 15, \u05D5: 22, \u05D6: 67, \u05D7: 418, \u05D8: 419, \u05D9: 20, \u05DB: 100, \u05DA: 100, \u05DC: 74, \u05DE: 80, \u05DD: 80, \u05E0: 106, \u05DF: 106, \u05E1: 120, \u05E2: 130, \u05E4: 81, \u05E3: 81, \u05E6: 104, \u05E5: 104, \u05E7: 186, \u05E8: 510, \u05E9: 360, \u05EA: 416 }, SQR = Object.fromEntries(Object.entries(GEM).map(([c, v]) => [c, v * v])), SQR_GADOL = Object.fromEntries(Object.keys(GEM).map((c) => {
  let v = FINAL[c] || GEM[c];
  return [c, v * v];
})), KID_GADOL = { ...KID, \u05DA: 1995, \u05DD: 2595, \u05DF: 3295, \u05E3: 4095, \u05E5: 4995 }, MDM = { \u05D0: 266, \u05D1: 848, \u05D2: 257, \u05D3: 924, \u05D4: 35, \u05D5: 64, \u05D6: 193, \u05D7: 854, \u05D8: 855, \u05D9: 476, \u05DB: 181, \u05DA: 181, \u05DC: 588, \u05DE: 160, \u05DD: 160, \u05E0: 234, \u05DF: 234, \u05E1: 300, \u05E2: 256, \u05E4: 192, \u05E3: 192, \u05E6: 558, \u05E5: 558, \u05E7: 289, \u05E8: 890, \u05E9: 486, \u05EA: 458 }, MDM_GADOL = { \u05D0: 986, \u05D1: 848, \u05D2: 817, \u05D3: 924, \u05D4: 35, \u05D5: 64, \u05D6: 1493, \u05D7: 854, \u05D8: 855, \u05D9: 476, \u05DB: 901, \u05DA: 901, \u05DC: 1148, \u05DE: 1280, \u05DD: 1280, \u05E0: 1534, \u05DF: 1534, \u05E1: 2060, \u05E2: 1556, \u05E4: 912, \u05E3: 912, \u05E6: 558, \u05E5: 558, \u05E7: 1009, \u05E8: 1540, \u05E9: 1786, \u05EA: 458 }, sumBy = (w, map) => onlyHeb(w).reduce((s, c) => s + (map[c] || 0), 0), gadol = (w) => onlyHeb(w).reduce((s, c) => s + (FINAL[c] || GEM[c] || 0), 0), ribuaWord = (word, val) => {
  let s = 0, run = 0;
  for (let c of onlyHeb(word))
    run += val(c), s += run;
  return s;
}, ribua = (w) => normalizeForCalc(w).split(/\s+/).reduce((t, word) => t + ribuaWord(word, (c) => GEM[c] || 0), 0), ribuaGadol = (w) => normalizeForCalc(w).split(/\s+/).reduce((t, word) => t + ribuaWord(word, (c) => FINAL[c] || GEM[c] || 0), 0), triangleWord = (w) => {
  let L = onlyHeb(w), s = 0, run = 0;
  for (let i = 0; i < L.length; i++)
    run += GEM[L[i]] || 0, s += run;
  return s;
}, triangleReverse = (w) => {
  let L = onlyHeb(w), s = 0, run = 0;
  for (let i = L.length - 1; i >= 0; i--)
    run += GEM[L[i]] || 0, s += run;
  return s;
}, stairTriangle = (w) => String(w || "").split(/\s+/).reduce((tot, word) => {
  let L = onlyHeb(word), s = 0;
  for (let i = 0; i < L.length; i++) s += (GEM[L[i]] || 0) * (i + 1);
  return tot + s;
}, 0), mistater = (w) => normalizeForCalc(w).split(/\s+/).reduce((tot, word) => {
  let L = onlyHeb(word), s = 0;
  for (let i = 0; i < L.length - 1; i++) s += Math.abs(GEM[L[i]] - GEM[L[i + 1]]);
  return tot + s;
}, 0), METHODS = [
  { key: "\u05E8\u05D2\u05D9\u05DC", tag: "hebrew", sub: "\u05D7\u05D9\u05D1\u05D5\u05E8 \u05E2\u05E8\u05DB\u05D9 \u05D4\u05D0\u05D5\u05EA\u05D9\u05D5\u05EA", soul: "\u05D4\u05DE\u05D4\u05D5\u05EA \u05D4\u05D2\u05DC\u05D5\u05D9\u05D4", fn: (w) => sumBy(w, GEM), map: GEM, col: "ragil" },
  { key: "\u05DE\u05D9\u05DC\u05D5\u05D9", tag: "hebrew", sub: "\u05E2\u05E8\u05DA \u05E9\u05B5\u05DD \u05D4\u05D0\u05D5\u05EA \u05D4\u05DE\u05DC\u05D0", soul: "\u05D4\u05E4\u05E0\u05D9\u05DE\u05D9\u05D5\u05EA \u2014 \u05DE\u05D4 \u05E9\u05DE\u05EA\u05DE\u05DC\u05D0 \u05D1\u05E4\u05E0\u05D9\u05DD", fn: (w) => sumBy(w, MILUI), map: MILUI, col: "miluy" },
  { key: "\u05DE\u05E1\u05EA\u05EA\u05E8", tag: "hebrew", sub: "\u05D4\u05E4\u05E8\u05E9\u05D9\u05DD \u05D1\u05D9\u05DF \u05D0\u05D5\u05EA\u05D9\u05D5\u05EA", soul: "\u05DE\u05D4 \u05E9\u05DE\u05E1\u05EA\u05EA\u05E8 \u05D1\u05D9\u05DF \u05D4\u05D0\u05D5\u05EA\u05D9\u05D5\u05EA", fn: mistater, map: null, col: "misratar" },
  { key: "\u05E7\u05D3\u05DE\u05D9", tag: "hebrew", sub: "\u05E1\u05DB\u05D5\u05DD \u05DE\u05E6\u05D8\u05D1\u05E8 \u05E2\u05D3 \u05D4\u05D0\u05D5\u05EA", soul: "\u05D4\u05E9\u05D5\u05E8\u05E9 \u05D4\u05DE\u05E6\u05D8\u05D1\u05E8", fn: (w) => sumBy(w, KID), map: KID, col: "kadmi" },
  { key: "\u05E8\u05D9\u05D1\u05D5\u05E2", tag: "hebrew", sub: "\u05E1\u05DB\u05D5\u05DD \u05D4\u05E7\u05D9\u05D3\u05D5\u05DE\u05D5\u05EA \u05D4\u05DE\u05E6\u05D8\u05D1\u05E8\u05D5\u05EA", soul: "\u05D4\u05D4\u05EA\u05E4\u05E9\u05D8\u05D5\u05EA \u05DE\u05D4\u05D0\u05D5\u05EA \u05D0\u05DC \u05D4\u05E9\u05DC\u05DD", fn: ribua, map: null, col: "ribua" },
  { key: "\u05D2\u05D3\u05D5\u05DC", tag: "hebrew", sub: "\u05E1\u05D5\u05E4\u05D9\u05D5\u05EA 500\u2013900", soul: "\u05D4\u05D4\u05EA\u05E4\u05E9\u05D8\u05D5\u05EA \u05D4\u05D2\u05D3\u05D5\u05DC\u05D4", fn: gadol, map: null, col: "gadol" },
  { key: "\u05E1\u05D9\u05D3\u05D5\u05E8\u05D9", tag: "hebrew", sub: "\u05DE\u05D9\u05E7\u05D5\u05DD \u05D4\u05D0\u05D5\u05EA 1\u201322", soul: "\u05D4\u05E1\u05D3\u05E8 \u05D5\u05D4\u05DE\u05D9\u05E7\u05D5\u05DD", fn: (w) => sumBy(w, ORD), map: ORD, col: "siduri" },
  { key: "\u05D0\u05EA\u05D1\u05E9", tag: "hebrew", sub: "\u05D4\u05D9\u05E4\u05D5\u05DA \u05D4\u05D0\u05F4\u05D1", soul: "\u05D4\u05DE\u05E8\u05D0\u05D4 \u2014 \u05D4\u05E6\u05D3 \u05D4\u05E0\u05D2\u05D3\u05D9", fn: (w) => sumBy(w, ATB), map: ATB, col: "atbash" },
  { key: "\u05D0\u05DC\u05D1\u05DD", tag: "hebrew", sub: "\u05D7\u05E6\u05D9 \u05DE\u05D5\u05DC \u05D7\u05E6\u05D9", soul: "\u05D1\u05DF/\u05D1\u05EA \u05D4\u05D6\u05D5\u05D2 \u2014 \u05D4\u05D6\u05D9\u05D5\u05D5\u05D2 \u05D4\u05DE\u05E9\u05DC\u05D9\u05DD", fn: (w) => sumBy(w, ALB), map: ALB, col: "albam" },
  { key: "\u05D0\u05D8\u05D1\u05D7", tag: "hebrew", sub: '\u05D6\u05D5\u05D2\u05D5\u05EA \u05DE\u05E9\u05DC\u05D9\u05DE\u05D5\u05EA (\u05DE\u05D4\u05E8\u05E9"\u05DC)', soul: "\u05D4\u05D6\u05D9\u05D5\u05D5\u05D2 \u05D4\u05DE\u05E9\u05DC\u05D9\u05DD \u05DC-10/100/500", fn: (w) => sumBy(w, ATBACH), map: ATBACH, col: null },
  { key: "\u05D0\u05D5\u05EA\u05D9\u05D5\u05EA \u05D0\u05D7\u05E8\u05D9", tag: "hebrew", sub: "\u05DB\u05DC \u05D0\u05D5\u05EA \u2192 \u05D4\u05D1\u05D0\u05D4 \u05D1\u05D0\u05F4\u05D1 (\u05E6\u05D5\u05E4\u05DF \u05D4\u05DE\u05D6\u05D5\u05D6\u05D4)", soul: "\u05DB\u05D5\u05D6\u05D5 \u05D1\u05DE\u05D5\u05DB\u05E1\u05D6 \u2014 \u05D4\u05E6\u05E2\u05D3 \u05E7\u05D3\u05D9\u05DE\u05D4", fn: (w) => sumBy(w, SHIFT_AFTER), map: SHIFT_AFTER, col: null },
  { key: "\u05D0\u05D5\u05EA\u05D9\u05D5\u05EA \u05DC\u05E4\u05E0\u05D9", tag: "hebrew", sub: "\u05DB\u05DC \u05D0\u05D5\u05EA \u2192 \u05D4\u05E7\u05D5\u05D3\u05DE\u05EA \u05D1\u05D0\u05F4\u05D1", soul: "\u05D4\u05E6\u05E2\u05D3 \u05D0\u05D7\u05D5\u05E8\u05D4 \u2014 \u05D4\u05E9\u05D5\u05E8\u05E9 \u05E9\u05DC\u05E4\u05E0\u05D9 \u05D4\u05D0\u05D5\u05EA", fn: (w) => sumBy(w, SHIFT_BEFORE), map: SHIFT_BEFORE, col: null },
  { key: "\u05DE\u05D9\u05DC\u05D5\u05D9 \u05D1\u05DC\u05D1\u05D3", tag: "hebrew", sub: "\u05D4\u05DE\u05D9\u05DC\u05D5\u05D9 \u05E4\u05D7\u05D5\u05EA \u05D4\u05D0\u05D5\u05EA \u05E2\u05E6\u05DE\u05D4", soul: "\u05D4\u05E4\u05E0\u05D9\u05DE\u05D9\u05D5\u05EA \u05D4\u05D8\u05D4\u05D5\u05E8\u05D4 \u2014 \u05D4\u05E0\u05E1\u05EA\u05E8 \u05E9\u05D1\u05D0\u05D5\u05EA", fn: (w) => sumBy(w, MILUI) - sumBy(w, GEM), map: null, col: null },
  { key: "\u05D4\u05DB\u05E4\u05DC\u05D4", tag: "hebrew", sub: "\u05DB\u05DC \u05D0\u05D5\u05EA \u05D1\u05E8\u05D9\u05D1\u05D5\u05E2 (\u05D0\u05D5\u05EA\xD7\u05E2\u05E6\u05DE\u05D4)", soul: "\u05D4\u05E2\u05D5\u05E6\u05DE\u05D4 \u05D4\u05E4\u05E0\u05D9\u05DE\u05D9\u05EA \u2014 \u05DB\u05DC \u05D0\u05D5\u05EA \u05DE\u05D5\u05DB\u05E4\u05DC\u05EA \u05D1\u05E2\u05E6\u05DE\u05D4", fn: (w) => sumBy(w, SQR), map: null, col: "hakpala" }
], LETTER_COLS = METHODS.filter((m) => m.map);
var gv = (c) => FINAL[c] || GEM[c] || 0, mistaterGadol = (w) => String(w || "").split(/\s+/).reduce((tot, word) => {
  let L = onlyHeb(word), s = 0;
  for (let i = 0; i < L.length - 1; i++) s += Math.abs(gv(L[i]) - gv(L[i + 1]));
  return tot + s;
}, 0), DEPTH_METHODS = [
  { key: "\u05DE\u05E9\u05D5\u05DC\u05E9 \u05D2\u05D3\u05D5\u05DC", tag: "hebrew", soul: "\u05E7\u05D3\u05DE\u05D9 \u05D2\u05D3\u05D5\u05DC \u2014 \u05D4\u05E1\u05D5\u05E4\u05D9\u05D5\u05EA \u05D1\u05E1\u05D3\u05E8 \u05D4\u05DE\u05D5\u05E8\u05D7\u05D1", fn: (w) => sumBy(w, KID_GADOL), col: "kadmi_gadol" },
  { key: "\u05DE\u05E1\u05EA\u05EA\u05E8 \u05D2\u05D3\u05D5\u05DC", tag: "hebrew", soul: "\u05D4\u05D4\u05E4\u05E8\u05E9\u05D9\u05DD \u05E2\u05DC \u05E2\u05E8\u05DB\u05D9 \u05D2\u05D3\u05D5\u05DC", fn: mistaterGadol, col: null },
  { key: "\u05DE\u05D9\u05DC\u05D5\u05D9 \u05D3\u05DE\u05D9\u05DC\u05D5\u05D9", tag: "hebrew", soul: "\u05DE\u05D9\u05DC\u05D5\u05D9 \u05D4\u05DE\u05D9\u05DC\u05D5\u05D9 \u2014 \u05D4\u05E4\u05E0\u05D9\u05DE\u05D9\u05D5\u05EA \u05D4\u05E2\u05DE\u05D5\u05E7\u05D4", fn: (w) => sumBy(w, MDM), col: "miluy_demiluy" },
  { key: "\u05DE\u05D9\u05DC\u05D5\u05D9 \u05D3\u05DE\u05D9\u05DC\u05D5\u05D9 \u05D2\u05D3\u05D5\u05DC", tag: "hebrew", soul: "\u05DE\u05D9\u05DC\u05D5\u05D9 \u05D3\u05DE\u05D9\u05DC\u05D5\u05D9 \u05D1\u05E1\u05D5\u05E4\u05D9\u05D5\u05EA \u05D2\u05D3\u05D5\u05DC", fn: (w) => sumBy(w, MDM_GADOL), col: null },
  { key: "\u05D4\u05DB\u05E4\u05DC\u05D4 \u05D2\u05D3\u05D5\u05DC\u05D4", tag: "hebrew", soul: "\u05D4\u05DB\u05E4\u05DC\u05D4 \u05D1\u05E1\u05D5\u05E4\u05D9\u05D5\u05EA \u05D2\u05D3\u05D5\u05DC (\u05DA=500\xB2)", fn: (w) => sumBy(w, SQR_GADOL), col: "hakpala_gadol" },
  { key: "\u05E8\u05D9\u05D1\u05D5\u05E2 \u05D2\u05D3\u05D5\u05DC", tag: "hebrew", soul: "\u05E8\u05D9\u05D1\u05D5\u05E2 \u05D4\u05E7\u05D9\u05D3\u05D5\u05DE\u05D5\u05EA \u05D1\u05E1\u05D5\u05E4\u05D9\u05D5\u05EA \u05D2\u05D3\u05D5\u05DC", fn: ribuaGadol, col: "ribua_gadol" },
  { key: "\u05DE\u05E9\u05D5\u05DC\u05E9 \u05DE\u05D9\u05DC\u05D4", tag: "hebrew", sub: "\u05D1\u05D5\u05E0\u05D9\u05DD \u05D0\u05EA \u05D4\u05D1\u05D9\u05D8\u05D5\u05D9 \u05D0\u05D5\u05EA-\u05D0\u05D7\u05E8-\u05D0\u05D5\u05EA \u05DE\u05D4\u05D4\u05EA\u05D7\u05DC\u05D4", soul: "\u05D4\u05D4\u05D9\u05D1\u05E0\u05D5\u05EA \u2014 \u05DB\u05DC \u05E9\u05DC\u05D1 \u05DE\u05D5\u05E1\u05D9\u05E3 \u05D0\u05D5\u05EA, \u05D5\u05E1\u05D5\u05DB\u05DE\u05D9\u05DD \u05D0\u05EA \u05DB\u05D5\u05DC\u05DD", fn: triangleWord, col: null },
  { key: "\u05DE\u05E9\u05D5\u05DC\u05E9 \u05D4\u05E4\u05D5\u05DA", tag: "hebrew", sub: "\u05DE\u05D5\u05E8\u05D9\u05D3\u05D9\u05DD \u05D0\u05D5\u05EA \u05DE\u05D4\u05D4\u05EA\u05D7\u05DC\u05D4 \u05D1\u05DB\u05DC \u05E9\u05DC\u05D1", soul: "\u05D4\u05D4\u05D9\u05E4\u05E8\u05D3\u05D5\u05EA \u2014 \u05DB\u05DC \u05E9\u05DC\u05D1 \u05DE\u05E1\u05D9\u05E8 \u05D0\u05D5\u05EA, \u05D5\u05E1\u05D5\u05DB\u05DE\u05D9\u05DD \u05D0\u05EA \u05DB\u05D5\u05DC\u05DD", fn: triangleReverse, col: null },
  { key: "\u05DE\u05E9\u05D5\u05DC\u05E9 \u05DE\u05D3\u05E8\u05D2\u05D5\u05EA", tag: "hebrew", sub: "\u05DB\u05DC \u05D0\u05D5\u05EA \u05DE\u05D5\u05DB\u05E4\u05DC\u05EA \u05D1\u05DE\u05D9\u05E7\u05D5\u05DE\u05D4 \u05D1\u05DE\u05D9\u05DC\u05D4", soul: "\u05D4\u05DE\u05D3\u05E8\u05D2\u05D5\u05EA \u2014 \u05DB\u05DC \u05D0\u05D5\u05EA \u05E2\u05D5\u05DC\u05D4 \u05DC\u05E4\u05D9 \u05DE\u05E7\u05D5\u05DE\u05D4 \u05D1\u05E1\u05D3\u05E8", fn: stairTriangle, col: null }
], METHOD_DB_COLS = Object.fromEntries(
  [...METHODS, ...DEPTH_METHODS].filter((m) => m.col).map((m) => [m.key, m.col])
);

// src/lib/research/gematriaRelationW2Executor.js
var ADAPTER_VERSION = "gematria-relation-w2-v1", GEMATRIA_RELATION_PAIR_MODE = Object.freeze({
  REPRESENTATION_PAIRS: "representation_pairs",
  INTAKE_DIRECT_PAIR: "intake_direct_pair"
});
function clean15(value) {
  return value == null ? null : String(value).trim() || null;
}
function uniq3(values) {
  return [...new Set(values.filter(Boolean))];
}
var ACCESS_ORDER = Object.freeze(["public", "public_candidate", "personal", "private"]);
function moreRestrictiveTier(a, b) {
  let aa = clean15(a) || "public", bb = clean15(b) || "public", ar = ACCESS_ORDER.indexOf(aa), br = ACCESS_ORDER.indexOf(bb), aRank = ar === -1 ? ACCESS_ORDER.length : ar, bRank = br === -1 ? ACCESS_ORDER.length : br;
  return aRank >= bRank ? aa : bb;
}
function independentEvidenceCounts(candidate = {}) {
  let evidence = candidate?.independent_evidence && typeof candidate.independent_evidence == "object" ? candidate.independent_evidence : {};
  return {
    edges: Array.isArray(evidence.edges) ? evidence.edges.length : 0,
    topic_cards: Array.isArray(evidence.topic_cards) ? evidence.topic_cards.length : 0,
    research_objects: Array.isArray(evidence.research_objects) ? evidence.research_objects.length : 0
  };
}
function hasSubstantiveEvidence(candidate = {}) {
  if (!candidate || typeof candidate != "object" || Array.isArray(candidate)) return !1;
  if (Array.isArray(candidate.engine_evidence) && candidate.engine_evidence.length > 0 || Array.isArray(candidate.composite_evidence) && candidate.composite_evidence.length > 0) return !0;
  let independent = independentEvidenceCounts(candidate);
  if (Object.values(independent).some((count) => count > 0)) return !0;
  let signal = Number(candidate.engine_signal);
  return Number.isFinite(signal) && signal > 0;
}
function projectGematriaRelationCandidateSummary(candidate = {}) {
  let components = candidate?.engine_signal_components && typeof candidate.engine_signal_components == "object" ? candidate.engine_signal_components : {};
  return {
    relation_kind: clean15(candidate.relation_kind) || "gematria_convergence",
    engine_signal: Number.isFinite(Number(candidate.engine_signal)) ? Number(candidate.engine_signal) : null,
    confidence: clean15(candidate.confidence),
    research_priority: clean15(candidate.research_priority),
    noise_flags: Array.isArray(candidate.noise_flags) ? candidate.noise_flags.map(String) : [],
    effective_independent_group_count: Number.isFinite(Number(components.effective_independent_group_count)) ? Number(components.effective_independent_group_count) : null,
    raw_independent_group_count: Number.isFinite(Number(components.raw_independent_group_count)) ? Number(components.raw_independent_group_count) : null,
    effective_structure_sensitive_group_count: Number.isFinite(Number(components.effective_structure_sensitive_group_count)) ? Number(components.effective_structure_sensitive_group_count) : null,
    expression_dependency: candidate?.expression_dependency && typeof candidate.expression_dependency == "object" ? { ...candidate.expression_dependency } : null,
    engine_evidence: Array.isArray(candidate.engine_evidence) ? candidate.engine_evidence : [],
    composite_evidence: Array.isArray(candidate.composite_evidence) ? candidate.composite_evidence : [],
    // independent_evidence may include access-controlled source objects. V1 intentionally does not
    // transport that payload through this generic adapter; source-native adapters remain owners.
    independent_evidence_transport: "excluded_v1_access_boundary",
    independent_evidence_counts: independentEvidenceCounts(candidate)
  };
}
function directPairRepresentations(intake) {
  let source = Array.isArray(intake?.representations) ? intake.representations : [];
  if (source.length !== 2) return [];
  let out = source.map((representation, index) => {
    let text = clean15(representation?.content);
    if (!text) return null;
    let accessTier = clean15(representation?.access?.tier) || "unclassified", sourceRef = clean15(representation?.ref) || `intake-representation:${index + 1}:${stableIdentityDigest(text)}`, safeRef2 = accessTier === "public" ? sourceRef : `repr:anon:${stableIdentityDigest(sourceRef)}`;
    return {
      ref: safeRef2,
      parent_identity_key: safeRef2,
      parent_identity_type: "expression",
      kind: clean15(representation?.kind) || "expression",
      role: clean15(representation?.role) || (index === 0 ? "pair_left" : "pair_right"),
      text,
      access_tier: accessTier,
      primary_for_identity: !0
    };
  });
  return out.some((value) => !value) || out[0].text === out[1].text ? [] : out;
}
function pairRepresentations(representations, maxPairs) {
  let unique = [], seen = /* @__PURE__ */ new Set();
  for (let rep of representations) {
    let text = clean15(rep?.text);
    !text || seen.has(text) || (seen.add(text), unique.push(rep));
  }
  let available = unique.length * (unique.length - 1) / 2, pairs = [];
  for (let i = 0; i < unique.length && pairs.length < maxPairs; i += 1)
    for (let j = i + 1; j < unique.length && pairs.length < maxPairs; j += 1)
      pairs.push([unique[i], unique[j]]);
  return {
    pairs,
    available,
    truncated: available > pairs.length
  };
}
function relationFinding(a, b, candidate) {
  let pairTier = moreRestrictiveTier(a.access_tier, b.access_tier), summary = projectGematriaRelationCandidateSummary(candidate), aRef = clean15(a.ref) || `text:${stableIdentityDigest(a.text)}`, bRef = clean15(b.ref) || `text:${stableIdentityDigest(b.text)}`, pairKey = [aRef, bRef].sort().join("|"), label = `${a.text} \u2194 ${b.text}`;
  return makeUniversalFinding({
    kind: "gematria-relation",
    // Relation Engine returns a candidate composition. The adapter does not promote it to an
    // epistemic stage; candidate remains source payload/context, not a fabricated Truth-axis value.
    subject: {
      type: "relation",
      key: `gematria-relation:${stableIdentityDigest(pairKey)}`,
      label
    },
    source: {
      engine: "relation-engine",
      adapter: ADAPTER_VERSION,
      sourceRef: "rpc:fn_relation_candidate",
      method: "fn_relation_candidate"
    },
    identity: {
      sourceIdentity: `fn_relation_candidate:${stableIdentityDigest(pairKey)}`,
      relationRef: `relation-candidate:${stableIdentityDigest(pairKey)}`
    },
    verification: {
      claimed_expression: null,
      claimed_method: null,
      claimed_value: null,
      engine_method_tested: "fn_relation_candidate",
      engine_result: summary,
      verification_state: "not_tested"
    },
    evidence: {
      refs: [aRef, bRef],
      facts: [{
        type: "gematria-relation-candidate",
        endpoint_refs: [aRef, bRef],
        ...summary
      }]
    },
    access: {
      tier: pairTier,
      reason: pairTier === "public" ? "both endpoint representations are public/input-safe" : "inherits the most restrictive endpoint representation tier"
    },
    provenance: {
      createdBy: "ENGINE:relation-engine",
      inputRef: `pair:${stableIdentityDigest(pairKey)}`,
      parentFindingIds: []
    },
    projection: {
      dimensions: {
        relation_candidate: summary,
        endpoints: [
          { ref: aRef, role: a.role || null, parent_identity_key: a.parent_identity_key || null },
          { ref: bRef, role: b.role || null, parent_identity_key: b.parent_identity_key || null }
        ]
      }
    }
  });
}
function createGematriaRelationW2Executor({
  supabase,
  maxRepresentations = 8,
  maxPairs = 12,
  pairMode = GEMATRIA_RELATION_PAIR_MODE.REPRESENTATION_PAIRS
} = {}) {
  if (typeof supabase?.rpc != "function") throw new Error("canonical Supabase RPC client required");
  let pairBudget = Math.max(1, Math.min(Number(maxPairs) || 12, 32)), directPair = pairMode === GEMATRIA_RELATION_PAIR_MODE.INTAKE_DIRECT_PAIR;
  return async ({ identityResolution, intake }) => {
    let representations = directPair ? directPairRepresentations(intake) : expandResearchTextRepresentations(identityResolution, {
      maxRepresentations: Math.max(2, Math.min(Number(maxRepresentations) || 8, 16))
    }), pairSet = directPair ? {
      pairs: representations.length === 2 ? [[representations[0], representations[1]]] : [],
      available: representations.length === 2 ? 1 : 0,
      truncated: !1
    } : pairRepresentations(representations, pairBudget), pairs = pairSet.pairs;
    if (!pairs.length)
      return {
        owner: "research_strategy_layer_law",
        status: CAPABILITY_STATUS.SKIPPED,
        reason: directPair ? "gematria_relations direct pair requires exactly two distinct personal intake representations" : "gematria_relations requires at least two distinct bounded text/name representations",
        findings: [],
        accessClass: ACCESS_CLASS.SOURCE_ACCESS_CONTROLLED,
        semanticClass: SEMANTIC_CLASS.DERIVATION,
        versionRefs: [ADAPTER_VERSION, "rpc:fn_relation_candidate"],
        cost: { certainty: "not_billable", ai_calls: 0, rpc_calls: 0, retry_count: 0 },
        trace: { pair_mode: pairMode, pair_count: 0, pair_budget: directPair ? 1 : pairBudget }
      };
    let findings = [], outcomes = [], failed = 0, statuses = [];
    for (let [a, b] of pairs)
      try {
        let out = await supabase.rpc("fn_relation_candidate", { p_a: a.text, p_b: b.text });
        if (out?.error) throw out.error;
        let candidate = out && typeof out == "object" && Object.prototype.hasOwnProperty.call(out, "data") ? out.data : out;
        if (!candidate || typeof candidate != "object" || Array.isArray(candidate)) {
          statuses.push({ status: "executed_empty" });
          continue;
        }
        if (!hasSubstantiveEvidence(candidate)) {
          statuses.push({ status: "executed_empty", reason: "no_substantive_evidence" });
          continue;
        }
        let finding = relationFinding(a, b, candidate);
        findings.push(finding), outcomes.push({
          findingId: finding.id,
          evidenceRelation: EVIDENCE_RELATION.CONVERGENCE,
          reason: "cross-method relation candidate is a composed convergence; it is never independent corroboration by itself"
        }), statuses.push({
          status: clean15(candidate?.status) || "candidate",
          effective_independent_group_count: Number(candidate?.engine_signal_components?.effective_independent_group_count) || 0,
          noise_flag_count: Array.isArray(candidate?.noise_flags) ? candidate.noise_flags.length : 0
        });
      } catch (error) {
        failed += 1, statuses.push({ status: "failed", error_class: error?.name || "Error" });
      }
    let restricted = representations.some((rep) => clean15(rep?.access_tier) && clean15(rep.access_tier) !== "public"), executed = pairs.length - failed, status = findings.length > 0 ? CAPABILITY_STATUS.EXECUTED : failed === 0 && executed === pairs.length ? CAPABILITY_STATUS.NEGATIVE_RESULT : CAPABILITY_STATUS.FAILED, reason = findings.length > 0 ? failed > 0 ? `relation engine returned findings for ${executed}/${pairs.length} bounded pairs; ${failed} failed` : null : status === CAPABILITY_STATUS.NEGATIVE_RESULT ? "canonical relation engine found no substantive evidence in the completed bounded pair search" : `relation engine completed ${executed}/${pairs.length} bounded pairs; ${failed} failed, so absence was not established`;
    return {
      owner: "research_strategy_layer_law",
      status,
      reason,
      findings,
      findingOutcomes: outcomes,
      accessClass: restricted ? ACCESS_CLASS.SOURCE_ACCESS_CONTROLLED : ACCESS_CLASS.PUBLIC_SOURCE,
      semanticClass: SEMANTIC_CLASS.DERIVATION,
      negativeScope: status === CAPABILITY_STATUS.NEGATIVE_RESULT ? {
        operation: directPair ? "direct_pair" : "bounded_representation_pairs",
        searched_pair_count: executed,
        requested_pair_count: pairs.length,
        pair_budget: directPair ? 1 : pairBudget,
        truncated: pairSet.truncated
      } : null,
      sourceRefs: uniq3(representations.map((rep) => rep.ref)),
      versionRefs: [ADAPTER_VERSION, "rpc:fn_relation_candidate"],
      cost: {
        certainty: "not_billable",
        ai_calls: 0,
        rpc_calls: pairs.length,
        retry_count: 0
      },
      bounded: {
        total_count: pairSet.available,
        returned_count: pairs.length,
        truncated: pairSet.truncated,
        ordering: "bounded_representation_input_order__unique_pairs",
        continuation: pairSet.truncated ? {
          kind: "increase_pair_budget",
          current_max_pairs: directPair ? 1 : pairBudget,
          next_max_pairs: Math.min(32, pairSet.available)
        } : null
      },
      trace: {
        adapter: ADAPTER_VERSION,
        pair_mode: pairMode,
        pair_count: pairs.length,
        available_pair_count: pairSet.available,
        pair_budget: directPair ? 1 : pairBudget,
        pair_budget_truncated: pairSet.truncated,
        failed_pair_count: failed,
        // No raw endpoint text in capability trace: private text remains only inside access-filtered Findings.
        pair_statuses: statuses,
        independent_evidence_transport: "excluded_v1_access_boundary",
        truth_boundary: "canonical fn_relation_candidate output; candidate/convergence only; no graph promotion and no independent-evidence upgrade"
      }
    };
  };
}

// src/lib/research/gematriaCorpusCrossingW2Executor.js
var GEMATRIA_CORPUS_CROSSING_ADAPTER_VERSION = "gematria-corpus-crossing-w2-v3", GEMATRIA_CORPUS_CROSSING_RPC = "strongest_crossings", GEMATRIA_CONFIRMED_RELATION_SOURCE = "public:relation_evidence", GEMATRIA_METHOD_SEMANTICS_SOURCE = "public:method_semantics", DEFAULT_LIMIT = 8, MAX_LIMIT = 12, MIN_METHODS = 2, MAX_TEXT_CODEPOINTS = 160, MAX_RELATION_NOTE_CODEPOINTS = 640;
function clean16(value) {
  return value == null ? "" : String(value).trim();
}
function boundedHebrewText(value) {
  let text = clean16(value);
  return !text || Array.from(text).length > MAX_TEXT_CODEPOINTS ? null : onlyHeb(normalizeForCalc(text)).length > 0 ? text : null;
}
function boundedText(value, max = MAX_RELATION_NOTE_CODEPOINTS) {
  let text = clean16(value).replace(/\s+/gu, " ");
  return text ? Array.from(text).slice(0, max).join("") : null;
}
function anagramKey(value) {
  return Array.from(onlyHeb(normalizeForCalc(value))).sort().join("");
}
function parseMethodsDetail(value) {
  let methods = [], seen = /* @__PURE__ */ new Set();
  for (let part of clean16(value).split(/\s*·\s*/u)) {
    let match = part.match(/^(.{1,40}?)\s*=\s*(-?\d{1,15})$/u);
    if (!match) continue;
    let method = clean16(match[1]), number = Number(match[2]);
    !method || !Number.isSafeInteger(number) || seen.has(method) || (seen.add(method), methods.push(Object.freeze({ method, value: number })));
  }
  return Object.freeze(methods);
}
function projectRow(expression, raw) {
  if (!raw || typeof raw != "object" || Array.isArray(raw)) return null;
  let partner = boundedHebrewText(raw.partner), declaredMethodCount = Number(raw.n_methods), methods = parseMethodsDetail(raw.methods_detail);
  if (!partner || !Number.isSafeInteger(declaredMethodCount) || declaredMethodCount < MIN_METHODS || methods.length < MIN_METHODS) return null;
  let normalizedExpression = normalizeForCalc(expression), normalizedPartner = normalizeForCalc(partner);
  return !normalizedPartner || normalizedPartner === normalizedExpression || anagramKey(partner) === anagramKey(expression) ? null : Object.freeze({
    partner,
    method_count: Math.min(declaredMethodCount, methods.length),
    methods
  });
}
function crossingFinding(expression, row) {
  let pairDigest = stableIdentityDigest(`${normalizeForCalc(expression)}|${normalizeForCalc(row.partner)}`), inputRef = `expression:${stableIdentityDigest(normalizeForCalc(expression))}`, partnerRef = `public-corpus-expression:${stableIdentityDigest(normalizeForCalc(row.partner))}`, engineResult = {
    relation_kind: "multi_method_corpus_convergence",
    method_count: row.method_count,
    methods: row.methods,
    minimum_required_methods: MIN_METHODS,
    dependency_independence_claimed: !1,
    relation_normalization: row.relation_normalization || null
  };
  return makeUniversalFinding({
    kind: "gematria-crossing",
    subject: {
      type: "relation",
      key: `gematria-crossing:${pairDigest}`,
      label: `${expression} \u2194 ${row.partner}`,
      lang: "he"
    },
    source: {
      engine: GEMATRIA_CORPUS_CROSSING_RPC,
      adapter: GEMATRIA_CORPUS_CROSSING_ADAPTER_VERSION,
      sourceRef: `rpc:${GEMATRIA_CORPUS_CROSSING_RPC}`,
      method: GEMATRIA_CORPUS_CROSSING_RPC,
      corpus: "gematria_words/bidim",
      lang: "he"
    },
    identity: {
      sourceIdentity: `${GEMATRIA_CORPUS_CROSSING_RPC}:${pairDigest}`,
      relationRef: `gematria-crossing:${pairDigest}`
    },
    verification: {
      claimed_expression: null,
      claimed_method: null,
      claimed_value: null,
      engine_method_tested: GEMATRIA_CORPUS_CROSSING_RPC,
      engine_result: engineResult,
      verification_state: "not_tested"
    },
    evidence: {
      refs: [inputRef, partnerRef],
      facts: [{
        type: "gematria-multi-method-corpus-crossing",
        expression,
        partner: row.partner,
        ...engineResult
      }]
    },
    access: {
      tier: "public",
      reason: "the crossing adapter reads only the verified and published public corpus RPC"
    },
    provenance: {
      createdBy: `ENGINE:${GEMATRIA_CORPUS_CROSSING_RPC}`,
      inputRef,
      parentFindingIds: []
    },
    projection: {
      dimensions: {
        endpoints: [expression, row.partner],
        methods: row.methods,
        method_count: row.method_count,
        independence: "not_claimed"
      }
    }
  });
}
function projectConfirmedRelation(expression, raw) {
  if (!raw || typeof raw != "object" || Array.isArray(raw) || raw.status !== "confirmed" || raw.engine_verified !== !0) return null;
  let aPhrase = boundedHebrewText(raw.a_phrase), bPhrase = boundedHebrewText(raw.b_phrase), method = boundedText(raw.method, 80), relationType = boundedText(raw.relation_type, 80), value = Number(raw.value);
  if (!aPhrase || !bPhrase || !method || !relationType || !Number.isSafeInteger(value)) return null;
  let normalizedExpression = normalizeForCalc(expression), expressionIsA = normalizeForCalc(aPhrase) === normalizedExpression, expressionIsB = normalizeForCalc(bPhrase) === normalizedExpression;
  if (expressionIsA === expressionIsB) return null;
  let partner = expressionIsA ? bPhrase : aPhrase, expressionMethod = expressionIsA ? method : "\u05E8\u05D2\u05D9\u05DC", partnerMethod = expressionIsA ? "\u05E8\u05D2\u05D9\u05DC" : method, semantic = raw.semantic && typeof raw.semantic == "object" ? Object.freeze({
    profile: boundedText(raw.semantic.profile, 40),
    relation_type: boundedText(raw.semantic.relation_type, 80),
    label_he: boundedText(raw.semantic.label_he, 120),
    calculation_description: boundedText(raw.semantic.calculation_description),
    semantic_description: boundedText(raw.semantic.semantic_description),
    confidence_source: boundedText(raw.semantic.confidence_source, 60),
    review_version: boundedText(raw.semantic.review_version, 60)
  }) : null;
  return Object.freeze({
    expression,
    partner,
    method_phrase: aPhrase,
    regular_phrase: bPhrase,
    method,
    relation_type: relationType,
    value,
    expression_method: expressionMethod,
    partner_method: partnerMethod,
    note: boundedText(raw.note),
    semantic
  });
}
function confirmedRelationFindings(expression, row) {
  let pairDigest = stableIdentityDigest([
    normalizeForCalc(row.method_phrase),
    normalizeForCalc(row.regular_phrase),
    row.method,
    row.value
  ].join("|")), inputRef = `expression:${stableIdentityDigest(normalizeForCalc(expression))}`, partnerRef = `public-corpus-expression:${stableIdentityDigest(normalizeForCalc(row.partner))}`, relationRef = `confirmed-gematria-relation:${pairDigest}`, engineResult = {
    relation_kind: "confirmed_cross_method_relation",
    relation_type: row.relation_type,
    expression: row.expression,
    partner: row.partner,
    value: row.value,
    expression_method: row.expression_method,
    partner_method: row.partner_method,
    engine_verified: !0,
    dependency_independence_claimed: !1
  }, relation = makeUniversalFinding({
    kind: "gematria-confirmed-relation",
    stage: "evidence",
    status: "confirmed",
    subject: {
      type: "relation",
      key: relationRef,
      label: `${expression} (${row.expression_method}) \u2194 ${row.partner} (${row.partner_method})`,
      lang: "he",
      value: row.value
    },
    source: {
      engine: "relation_evidence",
      adapter: GEMATRIA_CORPUS_CROSSING_ADAPTER_VERSION,
      name: "\u05DE\u05DE\u05E6\u05D0\u05D9 \u05D4\u05DE\u05D7\u05E7\u05E8 \u05D4\u05DE\u05D0\u05D5\u05E9\u05E8\u05D9\u05DD \u05E9\u05DC SOD1820",
      sourceRef: `${GEMATRIA_CONFIRMED_RELATION_SOURCE}:${pairDigest}`,
      method: row.method,
      corpus: "relation_evidence",
      lang: "he"
    },
    identity: {
      sourceIdentity: `relation_evidence:${pairDigest}`,
      relationRef
    },
    verification: {
      claimed_expression: `${expression} (${row.expression_method}) = ${row.partner} (${row.partner_method})`,
      claimed_method: row.method,
      claimed_value: row.value,
      engine_method_tested: `${row.expression_method}\u2194${row.partner_method}`,
      engine_result: engineResult,
      verification_state: "match"
    },
    evidence: {
      refs: [inputRef, partnerRef, `${GEMATRIA_CONFIRMED_RELATION_SOURCE}:${pairDigest}`],
      facts: [{
        type: "gematria-confirmed-cross-method-relation",
        ...engineResult
      }]
    },
    access: {
      tier: "public",
      reason: "confirmed engine-verified relation whose other endpoint passed the verified published public-corpus boundary"
    },
    provenance: {
      createdBy: "SOURCE:relation_evidence",
      inputRef,
      parentFindingIds: []
    },
    projection: {
      dimensions: {
        endpoints: [expression, row.partner],
        expression_method: row.expression_method,
        partner_method: row.partner_method,
        relation_type: row.relation_type,
        independence: "not_claimed"
      }
    }
  });
  if (!(row.semantic && Object.values(row.semantic).some(Boolean))) return Object.freeze([relation]);
  let semanticDigest = stableIdentityDigest(`${pairDigest}|${row.semantic?.review_version || ""}|${row.note || ""}`), interpretation = makeUniversalFinding({
    kind: "gematria-method-semantic",
    stage: "interpretation",
    status: "approved",
    subject: {
      type: "relation",
      key: `gematria-method-semantic:${semanticDigest}`,
      label: `${row.method}${row.semantic?.label_he ? ` \u2014 ${row.semantic.label_he}` : ""}`,
      lang: "he"
    },
    source: {
      engine: "method_semantics",
      adapter: GEMATRIA_CORPUS_CROSSING_ADAPTER_VERSION,
      name: "\u05DE\u05D5\u05D3\u05DC \u05D4\u05DE\u05E9\u05DE\u05E2\u05D5\u05EA \u05D4\u05DE\u05D0\u05D5\u05E9\u05E8 \u05E9\u05DC SOD1820",
      sourceRef: `${GEMATRIA_METHOD_SEMANTICS_SOURCE}:${semanticDigest}`,
      method: row.method,
      corpus: "method_semantics/relation_evidence",
      lang: "he"
    },
    identity: {
      sourceIdentity: `method_semantics:${semanticDigest}`,
      relationRef
    },
    verification: {
      claimed_expression: null,
      claimed_method: row.method,
      claimed_value: null,
      engine_method_tested: null,
      engine_result: null,
      verification_state: "not_tested"
    },
    evidence: {
      refs: [
        `${GEMATRIA_METHOD_SEMANTICS_SOURCE}:${semanticDigest}`,
        relation.source.sourceRef,
        relation.id
      ],
      facts: [{
        type: "gematria-method-semantic-interpretation",
        method: row.method,
        relation_type: row.semantic?.relation_type || row.relation_type,
        label_he: row.semantic?.label_he || null,
        calculation_description: row.semantic?.calculation_description || null,
        semantic_description: row.semantic?.semantic_description || null,
        relation_note: row.note || null,
        confidence_source: row.semantic?.confidence_source || null,
        review_version: row.semantic?.review_version || null,
        profile: row.semantic?.profile || "sod1820",
        relation: relation.id
      }]
    },
    access: {
      tier: "public",
      reason: "approved public SOD1820 method-semantic interpretation attached to admitted public relation evidence"
    },
    provenance: {
      createdBy: "SOURCE:method_semantics",
      inputRef,
      parentFindingIds: [relation.id]
    }
  });
  return Object.freeze([relation, interpretation]);
}
function createGematriaCorpusCrossingW2Executor({
  supabase,
  limit = DEFAULT_LIMIT,
  readConfirmedRelations = null,
  normalizeRelations = !1
} = {}) {
  if (typeof supabase?.rpc != "function") throw new Error("canonical Supabase RPC client required");
  let boundedLimit = Math.max(1, Math.min(Number(limit) || DEFAULT_LIMIT, MAX_LIMIT));
  return async ({ identityResolution }) => {
    let primary = identityResolution?.primary, expression = primary && ["phrase", "word"].includes(primary.type) ? boundedHebrewText(primary.label ?? primary.value) : null;
    if (!expression || identityResolution?.explicit_text_computation !== !0)
      return {
        owner: "research_strategy_layer_law",
        status: CAPABILITY_STATUS.SKIPPED,
        reason: "crossings require one exact Hebrew phrase and explicit text computation",
        findings: [],
        accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
        semanticClass: SEMANTIC_CLASS.DERIVATION,
        versionRefs: [GEMATRIA_CORPUS_CROSSING_ADAPTER_VERSION, `rpc:${GEMATRIA_CORPUS_CROSSING_RPC}`],
        cost: { certainty: "not_billable", ai_calls: 0, rpc_calls: 0, retry_count: 0 },
        trace: { minimum_methods: MIN_METHODS, result_limit: boundedLimit }
      };
    let crossingPromise = supabase.rpc(GEMATRIA_CORPUS_CROSSING_RPC, {
      p_self: expression,
      p_min: MIN_METHODS,
      p_limit: boundedLimit
    }).then((output) => ({ output, error: null })).catch((error) => ({ output: null, error })), relationPromise = typeof readConfirmedRelations == "function" ? Promise.resolve().then(() => readConfirmedRelations({ expression })).then((output) => ({ output, error: null })).catch((error) => ({ output: null, error })) : Promise.resolve({ output: { status: "not_configured", rows: [], rest_calls: 0 }, error: null }), [crossingRead, relationRead] = await Promise.all([crossingPromise, relationPromise]), crossingOutput = crossingRead.output, crossingComplete = !crossingRead.error && !crossingOutput?.error && Array.isArray(crossingOutput?.data), projectedCrossings = crossingComplete ? crossingOutput.data.slice(0, boundedLimit).map((row) => projectRow(expression, row)).filter(Boolean) : [], normalizationReads = normalizeRelations ? await Promise.all(projectedCrossings.map(async (row) => {
      try {
        let response = await supabase.rpc("fn_relation_candidate", { p_a: expression, p_b: row.partner });
        if (response?.error) throw response.error;
        let candidate = response && typeof response == "object" && Object.prototype.hasOwnProperty.call(response, "data") ? response.data : response;
        if (!candidate || typeof candidate != "object" || Array.isArray(candidate))
          return { status: "executed_empty", summary: null };
        let projected = projectGematriaRelationCandidateSummary(candidate), { engine_evidence: _engineEvidence, composite_evidence: _compositeEvidence, ...compact } = projected;
        return {
          status: "available",
          summary: {
            source: "rpc:fn_relation_candidate",
            ...compact
          }
        };
      } catch (error) {
        return { status: "failed", error_class: error?.name || "Error", summary: null };
      }
    })) : [], crossingFindings = projectedCrossings.map((row, index) => crossingFinding(expression, {
      ...row,
      relation_normalization: normalizationReads[index]?.summary || null
    })), relationOutput = relationRead.output, relationConfigured = typeof readConfirmedRelations == "function", relationUsable = relationConfigured && !relationRead.error && ["available", "partial"].includes(relationOutput?.status) && Array.isArray(relationOutput?.rows), relationComplete = !relationConfigured || relationUsable && relationOutput?.status === "available", projectedRelations = relationUsable ? relationOutput.rows.map((row) => projectConfirmedRelation(expression, row)).filter(Boolean) : [], relationFindings = projectedRelations.flatMap((row) => confirmedRelationFindings(expression, row)), findings = [...relationFindings, ...crossingFindings], normalizationComplete = !normalizeRelations || normalizationReads.every((read) => ["available", "executed_empty"].includes(read?.status)), allSourcesComplete = crossingComplete && relationComplete && normalizationComplete, status = findings.length ? CAPABILITY_STATUS.EXECUTED : allSourcesComplete ? CAPABILITY_STATUS.NEGATIVE_RESULT : CAPABILITY_STATUS.FAILED, relationFindingIds = new Set(relationFindings.map((finding) => finding.id)), confirmedRelationIds = new Set(relationFindings.filter((finding) => finding.kind === "gematria-confirmed-relation").map((finding) => finding.id));
    return {
      owner: "research_strategy_layer_law",
      status,
      reason: findings.length ? allSourcesComplete ? null : "completed with partial canonical crossing-source coverage" : allSourcesComplete ? "the completed public crossing sources found no valid relation" : "one or more canonical crossing sources were unavailable",
      findings,
      findingOutcomes: findings.map((finding) => ({
        findingId: finding.id,
        evidenceRelation: finding.kind === "gematria-method-semantic" ? EVIDENCE_RELATION.DERIVATION : EVIDENCE_RELATION.CONVERGENCE,
        dependsOn: finding.kind === "gematria-method-semantic" ? finding.provenance.parentFindingIds.filter((id) => confirmedRelationIds.has(id)) : [],
        reason: finding.kind === "gematria-method-semantic" ? "approved SOD1820 method meaning interprets the attached confirmed numerical relation" : relationFindingIds.has(finding.id) ? "confirmed engine-verified cross-method equality; formula independence is not claimed" : "multiple method matches form a corpus convergence; formula independence is not claimed"
      })),
      accessClass: ACCESS_CLASS.PUBLIC_SOURCE,
      semanticClass: SEMANTIC_CLASS.DERIVATION,
      negativeScope: status === CAPABILITY_STATUS.NEGATIVE_RESULT ? {
        operation: relationConfigured ? "expression_crossing_sources" : "strongest_crossings",
        minimum_methods: MIN_METHODS,
        result_limit: boundedLimit,
        completed: !0
      } : void 0,
      sourceRefs: [
        `rpc:${GEMATRIA_CORPUS_CROSSING_RPC}`,
        ...normalizeRelations ? ["rpc:fn_relation_candidate"] : [],
        "public:gematria_words",
        "public:bidim",
        ...relationConfigured ? [GEMATRIA_CONFIRMED_RELATION_SOURCE, GEMATRIA_METHOD_SEMANTICS_SOURCE] : []
      ],
      versionRefs: [
        GEMATRIA_CORPUS_CROSSING_ADAPTER_VERSION,
        `rpc:${GEMATRIA_CORPUS_CROSSING_RPC}`,
        ...normalizeRelations ? ["rpc:fn_relation_candidate"] : []
      ],
      cost: {
        certainty: "not_billable",
        ai_calls: 0,
        rpc_calls: 1 + (normalizeRelations ? projectedCrossings.length : 0),
        rest_calls: Number(relationOutput?.rest_calls) || 0,
        retry_count: 0
      },
      bounded: {
        total_count: null,
        returned_count: findings.length,
        truncated: !1,
        ordering: relationConfigured ? "confirmed_relation_evidence_first__then_engine_n_methods_desc" : "engine_n_methods_desc__engine_phrase_length_asc",
        continuation: null
      },
      trace: {
        minimum_methods: MIN_METHODS,
        result_limit: boundedLimit,
        same_method_source: {
          source: `rpc:${GEMATRIA_CORPUS_CROSSING_RPC}`,
          status: crossingComplete ? "available" : "unavailable",
          returned_count: crossingComplete ? crossingOutput.data.length : 0
        },
        relation_normalization: {
          source: "rpc:fn_relation_candidate",
          requested: normalizeRelations === !0,
          status: normalizeRelations ? normalizationComplete ? "available" : "partial" : "not_requested",
          requested_pair_count: normalizeRelations ? projectedCrossings.length : 0,
          normalized_pair_count: normalizationReads.filter((read) => read?.status === "available").length,
          empty_pair_count: normalizationReads.filter((read) => read?.status === "executed_empty").length,
          failed_pair_count: normalizationReads.filter((read) => read?.status === "failed").length
        },
        confirmed_relation_source: {
          source: GEMATRIA_CONFIRMED_RELATION_SOURCE,
          status: relationConfigured ? relationOutput?.status || "unavailable" : "not_configured",
          returned_count: projectedRelations.length,
          semantic_status: relationOutput?.semantic_status || null,
          public_endpoint_status: relationOutput?.public_endpoint_status || null
        },
        raw_row_count: crossingComplete ? crossingOutput.data.length : 0,
        admitted_finding_count: findings.length,
        source_total_known: !1,
        may_have_more: crossingComplete && crossingOutput.data.length >= boundedLimit,
        error_class: crossingRead.error?.name || (crossingOutput?.error ? "RpcError" : null) || relationRead.error?.name || normalizationReads.find((read) => read?.status === "failed")?.error_class || (relationConfigured && !relationUsable ? "RelationReadError" : null) || (relationOutput?.status === "partial" ? "PartialRelationRead" : null)
      }
    };
  };
}

// src/lib/research/researchRunRequest.js
var PUBLIC_NUMBER_RESEARCH_RUN_CONTRACT = "public-number-research-run-v1", PUBLIC_EXPRESSION_CROSSING_RESEARCH_RUN_CONTRACT = "public-expression-crossing-run-v1", PUBLIC_EXPRESSION_CROSSING_CAPABILITY = RESEARCH_CAPABILITY.CROSSINGS, PUBLIC_EXPRESSION_RESEARCH_CAPABILITIES = Object.freeze([
  RESEARCH_CAPABILITY.GEMATRIA,
  PUBLIC_EXPRESSION_CROSSING_CAPABILITY
]), PERSONAL_GEMATRIA_PAIR_RESEARCH_RUN_CONTRACT = "personal-gematria-pair-run-v1", PERSONAL_GEMATRIA_PAIR_CAPABILITY = RESEARCH_CAPABILITY.GEMATRIA_RELATIONS, PERSONAL_GEMATRIA_PAIR_MAX_CODEPOINTS = 160, PERSONAL_GEMATRIA_PAIR_MAX_UTF8_BYTES = 640, PUBLIC_NUMBER_RESEARCH_CAPABILITIES = Object.freeze([
  "numeric",
  "numeric_operators"
]), ALLOWED_CAPABILITIES = new Set(PUBLIC_NUMBER_RESEARCH_CAPABILITIES), ALLOWED_SURFACES = /* @__PURE__ */ new Set(["number", "heichal", "world", "system"]), PAIR_ALLOWED_SURFACES = /* @__PURE__ */ new Set([...ALLOWED_SURFACES, "raziel"]), EXPRESSION_ALLOWED_SURFACES = PAIR_ALLOWED_SURFACES, CONTROL_CHARACTER_RE = /[\u0000-\u001f\u007f-\u009f]/u;
function clean17(value) {
  return value == null ? "" : String(value).trim();
}
function exactCanonicalNumber(value) {
  let text = clean17(value);
  if (!/^\d{1,12}$/.test(text)) return null;
  let number = Number(text);
  return Number.isSafeInteger(number) && number >= 0 ? number : null;
}
function exactPairExpression(value, index) {
  if (typeof value != "string")
    throw new TypeError(`research-run: expression ${index + 1} must be a string`);
  let expression = value.trim();
  if (!expression)
    throw new TypeError(`research-run: expression ${index + 1} must not be empty`);
  if (CONTROL_CHARACTER_RE.test(expression))
    throw new TypeError(`research-run: expression ${index + 1} contains control characters`);
  if (Array.from(expression).length > PERSONAL_GEMATRIA_PAIR_MAX_CODEPOINTS)
    throw new TypeError(`research-run: expression ${index + 1} exceeds the character limit`);
  if (new TextEncoder().encode(expression).byteLength > PERSONAL_GEMATRIA_PAIR_MAX_UTF8_BYTES)
    throw new TypeError(`research-run: expression ${index + 1} exceeds the byte limit`);
  let normalized = normalizeForCalc(expression);
  if (!normalized || onlyHeb(normalized).length === 0)
    throw new TypeError(`research-run: expression ${index + 1} requires Hebrew text`);
  return { expression, normalized };
}
function exactPublicCrossingExpression(value) {
  return exactPairExpression(value, 0);
}
function normalizePublicNumberResearchRunRequest(input = {}) {
  if (!input || typeof input != "object" || Array.isArray(input))
    throw new TypeError("research-run: object body required");
  let number = exactCanonicalNumber(input.number);
  if (number == null)
    throw new TypeError("research-run: canonical non-negative number required");
  let requested = Array.isArray(input.requested_capabilities) ? [...new Set(input.requested_capabilities.map(clean17).filter(Boolean))] : [...PUBLIC_NUMBER_RESEARCH_CAPABILITIES];
  if (requested.length === 0)
    throw new TypeError("research-run: at least one requested capability is required");
  let disallowed = requested.filter((key) => !ALLOWED_CAPABILITIES.has(key));
  if (disallowed.length)
    throw new TypeError(`research-run: capability not allowed in ${PUBLIC_NUMBER_RESEARCH_RUN_CONTRACT}: ${disallowed.join(",")}`);
  let surface = clean17(input.surface) || "number";
  if (!ALLOWED_SURFACES.has(surface))
    throw new TypeError("research-run: unsupported surface");
  let question = clean17(input.question).slice(0, 500) || String(number);
  return Object.freeze({
    contract: PUBLIC_NUMBER_RESEARCH_RUN_CONTRACT,
    number,
    question,
    intent: "research",
    visitor_id: clean17(input.visitor_id) || null,
    interaction_id: clean17(input.interaction_id).slice(0, 180) || null,
    requested_capabilities: Object.freeze(requested),
    identity_candidates: Object.freeze([Object.freeze({
      type: "number",
      value: number,
      label: String(number),
      ref: `number:${number}`,
      source: RESEARCH_IDENTITY_SOURCE.NUMERIC_LITERAL,
      confidence: RESEARCH_IDENTITY_CONFIDENCE.EXACT,
      access: Object.freeze({ tier: "public" })
    })]),
    surface_context: Object.freeze({
      surface,
      subject: Object.freeze({
        type: "number",
        id: String(number),
        label: String(number)
      })
    })
  });
}
function normalizePersonalGematriaPairResearchRunRequest(input = {}) {
  if (!input || typeof input != "object" || Array.isArray(input))
    throw new TypeError("research-run: object body required");
  if (!Array.isArray(input.expressions) || input.expressions.length !== 2)
    throw new TypeError("research-run: exactly two expressions are required");
  let endpoints = input.expressions.map(exactPairExpression);
  if (endpoints[0].normalized === endpoints[1].normalized)
    throw new TypeError("research-run: expressions must be distinct after canonical normalization");
  let surface = clean17(input.surface) || "raziel";
  if (!PAIR_ALLOWED_SURFACES.has(surface))
    throw new TypeError("research-run: unsupported surface");
  let intake = buildResearchIntakeTransport({
    rawInput: null,
    representations: endpoints.map(({ expression }, index) => ({
      kind: "expression",
      content: expression,
      role: index === 0 ? "pair_left" : "pair_right",
      language: "he",
      script: "Hebr",
      access: { tier: "personal" }
    })),
    identityCandidates: [],
    origin: { channel: "web", surface },
    persistence: { mode: "ephemeral", persisted_ref: null },
    accessTier: "personal"
  });
  return Object.freeze({
    contract: PERSONAL_GEMATRIA_PAIR_RESEARCH_RUN_CONTRACT,
    question: "\u05D4\u05E9\u05D5\u05D5\u05D0\u05D4 \u05E7\u05E0\u05D5\u05E0\u05D9\u05EA \u05D1\u05D9\u05DF \u05E9\u05E0\u05D9 \u05D1\u05D9\u05D8\u05D5\u05D9\u05D9\u05DD",
    intent: "gematria_relation",
    visitor_id: null,
    interaction_id: clean17(input.interaction_id).slice(0, 180) || null,
    requested_capabilities: Object.freeze([PERSONAL_GEMATRIA_PAIR_CAPABILITY]),
    identity_candidates: Object.freeze([]),
    intake,
    surface_context: Object.freeze({
      surface,
      subject: Object.freeze({
        type: "expression_pair",
        id: "ephemeral-personal-pair",
        label: "\u05E9\u05E0\u05D9 \u05D1\u05D9\u05D8\u05D5\u05D9\u05D9\u05DD"
      })
    })
  });
}
function normalizePublicExpressionCrossingResearchRunRequest(input = {}) {
  if (!input || typeof input != "object" || Array.isArray(input))
    throw new TypeError("research-run: object body required");
  let { expression, normalized } = exactPublicCrossingExpression(input.expression), surface = clean17(input.surface) || "raziel";
  if (!EXPRESSION_ALLOWED_SURFACES.has(surface))
    throw new TypeError("research-run: unsupported surface");
  return Object.freeze({
    contract: PUBLIC_EXPRESSION_CROSSING_RESEARCH_RUN_CONTRACT,
    expression,
    normalized_expression: normalized,
    question: "\u05D7\u05D9\u05E4\u05D5\u05E9 \u05D4\u05E6\u05DC\u05D1\u05D5\u05EA \u05E7\u05E0\u05D5\u05E0\u05D9 \u05D1\u05DE\u05D0\u05D2\u05E8 \u05D4\u05E6\u05D9\u05D1\u05D5\u05E8\u05D9",
    intent: "gematria_crossing",
    visitor_id: clean17(input.visitor_id) || null,
    interaction_id: clean17(input.interaction_id).slice(0, 180) || null,
    requested_capabilities: PUBLIC_EXPRESSION_RESEARCH_CAPABILITIES,
    identity_candidates: Object.freeze([Object.freeze({
      type: "phrase",
      value: expression,
      label: expression,
      ref: `phrase:${normalized}`,
      source: RESEARCH_IDENTITY_SOURCE.TEXT_MATCH,
      confidence: RESEARCH_IDENTITY_CONFIDENCE.EXACT,
      access: Object.freeze({ tier: "public" })
    })]),
    surface_context: Object.freeze({
      surface,
      subject: Object.freeze({
        type: "phrase",
        id: `phrase:${normalized}`,
        label: expression
      })
    })
  });
}
function normalizeResearchRunRequest(input = {}) {
  let contract = clean17(input?.contract);
  if (!contract || contract === PUBLIC_NUMBER_RESEARCH_RUN_CONTRACT)
    return normalizePublicNumberResearchRunRequest(input);
  if (contract === PUBLIC_EXPRESSION_CROSSING_RESEARCH_RUN_CONTRACT)
    return normalizePublicExpressionCrossingResearchRunRequest(input);
  if (contract === PERSONAL_GEMATRIA_PAIR_RESEARCH_RUN_CONTRACT)
    return normalizePersonalGematriaPairResearchRunRequest(input);
  throw new TypeError("research-run: unsupported contract");
}

// src/lib/research/methodIdentity.js
var clean18 = (value) => value == null ? "" : String(value).trim();
function normalizedMethodIdentity(value) {
  return clean18(value).replace(/[\s"'״׳’‘\-_/]/g, "");
}
function isRegularMethodIdentity(value) {
  return normalizedMethodIdentity(value) === "\u05E8\u05D2\u05D9\u05DC";
}

// src/lib/research/numberPhrasePresentationOrder.js
var NUMBER_PHRASE_PRESENTATION_AUTHORITY = Object.freeze({
  table: "public.gematria_words",
  field: "lead_rank",
  ref: "public.gematria_words.lead_rank",
  scope: "equal_regular_phrase_prominence",
  method: "\u05E8\u05D2\u05D9\u05DC",
  version: 1
}), NUMBER_PHRASE_PRESENTATION_LIMIT = 24, clean19 = (value) => value == null ? "" : String(value).trim();
function safeNumber(value) {
  let number = Number(value);
  return Number.isSafeInteger(number) && number >= 0 ? number : null;
}
function safeRank(value) {
  let rank = Number(value);
  return Number.isSafeInteger(rank) && rank > 0 ? rank : null;
}
function orderedRegularRows(rows, number) {
  let seen = /* @__PURE__ */ new Set();
  return (Array.isArray(rows) ? rows : []).map((row, sourceIndex) => ({ row, sourceIndex, rank: safeRank(row?.lead_rank) })).filter(({ row }) => clean19(row?.id) && clean19(row?.phrase) && safeNumber(row?.ragil) === number && row?.is_verified === !0 && row?.is_published === !0 && row?.is_encrypted !== !0).sort((a, b) => a.rank != null && b.rank != null ? a.rank - b.rank || a.sourceIndex - b.sourceIndex : a.rank != null ? -1 : b.rank != null ? 1 : a.sourceIndex - b.sourceIndex).filter(({ row }) => {
    let phrase = clean19(row.phrase);
    return seen.has(phrase) ? !1 : (seen.add(phrase), !0);
  }).slice(0, NUMBER_PHRASE_PRESENTATION_LIMIT);
}
function isSameRegularFinding(finding, phrase, number) {
  return finding?.kind !== "gematria" || clean19(finding?.subject?.label) !== phrase || safeNumber(finding?.subject?.value) !== number ? !1 : [
    finding?.source?.method,
    finding?.verification?.engine_method_tested,
    finding?.verification?.claimed_method
  ].some(isRegularMethodIdentity);
}
function numberLeadOrderRowToUniversalFinding(row, { number } = {}) {
  let value = safeNumber(number ?? row?.ragil), phrase = clean19(row?.phrase), id = clean19(row?.id), leadRank = safeRank(row?.lead_rank);
  if (value == null || !phrase || !id || row?.is_verified !== !0 || row?.is_published !== !0 || row?.is_encrypted === !0) return null;
  let sourceRef = `gematria_words:${id}`, nodeId = clean19(row?.node_id);
  return makeUniversalFinding({
    kind: "gematria",
    stage: null,
    status: null,
    subject: { type: "phrase", key: phrase, label: phrase, value, lang: "he" },
    source: {
      engine: "gematria-corpus",
      adapter: leadRank == null ? "number-regular-corpus-v1" : "number-lead-order-v1",
      name: "\u05DE\u05D0\u05D2\u05E8 \u05D4\u05D2\u05D9\u05DE\u05D8\u05E8\u05D9\u05D4 \u05D4\u05DE\u05D0\u05D5\u05DE\u05EA",
      sourceRef,
      method: NUMBER_PHRASE_PRESENTATION_AUTHORITY.method,
      corpus: "gematria_words",
      lang: "he"
    },
    identity: {
      sourceIdentity: { table: "gematria_words", id },
      entityRef: nodeId ? `node:${nodeId}` : null
    },
    // The stored row is a published, verified corpus claim. This adapter does not rerun the engine,
    // so it leaves the claim-vs-engine verification state honestly unknown instead of self-matching.
    verification: {
      claimed_expression: phrase,
      claimed_method: NUMBER_PHRASE_PRESENTATION_AUTHORITY.method,
      claimed_value: value,
      engine_method_tested: null,
      engine_result: null,
      statement_lang: "he",
      verification_state: null
    },
    evidence: {
      refs: [sourceRef],
      facts: [{
        type: "published-gematria-phrase",
        expression: phrase,
        method: NUMBER_PHRASE_PRESENTATION_AUTHORITY.method,
        value,
        status: "verified_published",
        lead_rank: leadRank,
        authority: leadRank == null ? "public.gematria_words" : NUMBER_PHRASE_PRESENTATION_AUTHORITY.ref,
        presentation_scope: leadRank == null ? "equal_regular_phrase_projection" : NUMBER_PHRASE_PRESENTATION_AUTHORITY.scope
      }]
    },
    access: {
      tier: "public",
      reason: "caller-scoped public gematria_words row admitted only when verified and published"
    },
    provenance: {
      createdBy: "CORPUS:gematria_words",
      createdAt: row?.created_at || void 0,
      inputRef: `number:${value}`
    },
    projection: {
      anchors: [{ space: "number", value }],
      dimensions: {
        presentation: {
          authority: leadRank == null ? "public.gematria_words" : NUMBER_PHRASE_PRESENTATION_AUTHORITY.ref,
          scope: leadRank == null ? "equal_regular_phrase_projection" : NUMBER_PHRASE_PRESENTATION_AUTHORITY.scope,
          leadRank
        }
      }
    },
    view: { rendererHints: { role: "curated-regular-phrase" } }
  });
}
function mergeNumberPhrasePresentationOrder({ findings = [], rows = [], number } = {}) {
  let value = safeNumber(number), sourceFindings = Array.isArray(findings) ? findings : [];
  if (value == null) return Object.freeze({ findings: sourceFindings, ranking: [], added_count: 0, row_count: 0 });
  let projectedRegular = [], ranking = [], added = 0, ordered = orderedRegularRows(rows, value);
  for (let { row, rank } of ordered) {
    let phrase = clean19(row.phrase), finding = sourceFindings.find((candidate) => isSameRegularFinding(candidate, phrase, value));
    if (!finding) {
      if (finding = numberLeadOrderRowToUniversalFinding(row, { number: value }), !finding) continue;
      added++;
    }
    projectedRegular.push(finding), rank != null && ranking.push({
      finding_id: finding.id,
      rank,
      score: null,
      axes: {
        authority: NUMBER_PHRASE_PRESENTATION_AUTHORITY.ref,
        presentation_scope: NUMBER_PHRASE_PRESENTATION_AUTHORITY.scope,
        method: NUMBER_PHRASE_PRESENTATION_AUTHORITY.method,
        number: value,
        lead_rank: rank
      },
      reasons: ["\u05E1\u05D3\u05E8 \u05D1\u05D9\u05D8\u05D5\u05D9\u05D9\u05DD \u05D9\u05D3\u05E0\u05D9 \u05E7\u05D9\u05D9\u05DD \u05D1\u05D3\u05E3 \u05D4\u05DE\u05E1\u05E4\u05E8"]
    });
  }
  let projectedIds = new Set(projectedRegular.map((finding) => finding.id)), merged = [...projectedRegular, ...sourceFindings.filter((finding) => !projectedIds.has(finding?.id))];
  return Object.freeze({
    findings: Object.freeze(merged),
    ranking: Object.freeze(ranking),
    added_count: added,
    row_count: ordered.length
  });
}

// supabase/functions/research-run/index.ts
var SUPABASE_URL = (Deno.env.get("SUPABASE_URL") || "").trim(), ANON_KEY = (Deno.env.get("SUPABASE_ANON_KEY") || "").trim(), SERVICE_KEY = (Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "").trim(), CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "authorization, content-type, apikey, x-client-info, x-supabase-api-version",
  "Access-Control-Max-Age": "86400"
}, UUID_RE2 = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i, VISITOR_ID_RE = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|v[a-z0-9_-]{7,79})$/i;
function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...CORS }
  });
}
function safeUuid(value) {
  let text = String(value || "").trim();
  return UUID_RE2.test(text) ? text : null;
}
function safeVisitorId(value) {
  let text = String(value || "").trim();
  return VISITOR_ID_RE.test(text) ? text : null;
}
function cleanAuthHeader(req) {
  let value = String(req.headers.get("authorization") || "").trim();
  return /^Bearer\s+\S+$/i.test(value) ? value : null;
}
async function verifiedUserId(authHeader) {
  if (!authHeader || !SUPABASE_URL || !ANON_KEY) return null;
  try {
    let r = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: ANON_KEY, Authorization: authHeader }
    });
    if (!r.ok) return null;
    let body = await r.json();
    return safeUuid(body?.id);
  } catch {
    return null;
  }
}
function rpcTransport(apiKey, authorization) {
  return {
    async rpc(name, args = {}) {
      try {
        let r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${encodeURIComponent(name)}`, {
          method: "POST",
          headers: {
            apikey: apiKey,
            Authorization: authorization,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(args)
        });
        if (!r.ok) {
          let detail = await r.text().catch(() => "");
          return { data: null, error: { message: `rpc ${name} failed: ${r.status} ${detail.slice(0, 180)}` } };
        }
        return { data: await r.json().catch(() => null), error: null };
      } catch (error) {
        return { data: null, error: { message: error instanceof Error ? error.message : String(error) } };
      }
    }
  };
}
async function fetchNumberPhrasePresentationRows(apiKey, authorization, number) {
  let url = new URL(`${SUPABASE_URL}/rest/v1/gematria_words`);
  url.searchParams.set("select", "id,phrase,ragil,lead_rank,is_verified,is_published,is_encrypted,node_id,created_at"), url.searchParams.set("ragil", `eq.${number}`), url.searchParams.set("is_verified", "eq.true"), url.searchParams.set("is_published", "eq.true"), url.searchParams.set("or", "(is_encrypted.eq.false,is_encrypted.is.null)"), url.searchParams.set("order", "lead_rank.asc.nullslast,created_at.desc.nullslast"), url.searchParams.set("limit", String(NUMBER_PHRASE_PRESENTATION_LIMIT));
  try {
    let response = await fetch(url, {
      method: "GET",
      headers: { apikey: apiKey, Authorization: authorization }
    });
    if (!response.ok) return { rows: [], status: "unavailable", http_status: response.status };
    let data = await response.json().catch(() => null);
    return Array.isArray(data) ? { rows: data, status: "available", http_status: response.status } : { rows: [], status: "unavailable", http_status: response.status };
  } catch {
    return { rows: [], status: "unavailable", http_status: null };
  }
}
var CONFIRMED_RELATION_LIMIT = 3, METHOD_SEMANTICS_LIMIT = 32, METHOD_REGISTRY_LIMIT = 64;
function postgrestQuoted(value) {
  return `"${String(value ?? "").replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}
async function callerRestRows(apiKey, authorization, table, configure) {
  let url = new URL(`${SUPABASE_URL}/rest/v1/${table}`);
  configure(url);
  try {
    let response = await fetch(url, {
      method: "GET",
      headers: { apikey: apiKey, Authorization: authorization }
    });
    if (!response.ok) return { rows: [], status: "unavailable", http_status: response.status };
    let data = await response.json().catch(() => null);
    return Array.isArray(data) ? { rows: data, status: "available", http_status: response.status } : { rows: [], status: "unavailable", http_status: response.status };
  } catch {
    return { rows: [], status: "unavailable", http_status: null };
  }
}
async function fetchGematriaMethodDependencyRows(apiKey, authorization) {
  return callerRestRows(apiKey, authorization, "gematria_methods", (url) => {
    url.searchParams.set("select", "method_key,derived_from,dependency_rules,dependency_version"), url.searchParams.set("active", "eq.true"), url.searchParams.set("order", "sort_order.asc.nullslast,method_key.asc"), url.searchParams.set("limit", String(METHOD_REGISTRY_LIMIT));
  });
}
async function fetchConfirmedSemanticRelationRows(apiKey, authorization, { expression }) {
  let restCalls = 1, quotedExpression = postgrestQuoted(expression), relationRead = await callerRestRows(apiKey, authorization, "relation_evidence", (url) => {
    url.searchParams.set(
      "select",
      "relation_type,method,a_phrase,b_phrase,value,note,engine_verified,status,updated_at"
    ), url.searchParams.set("status", "eq.confirmed"), url.searchParams.set("engine_verified", "eq.true"), url.searchParams.set("or", `(a_phrase.eq.${quotedExpression},b_phrase.eq.${quotedExpression})`), url.searchParams.set("order", "updated_at.desc.nullslast"), url.searchParams.set("limit", String(CONFIRMED_RELATION_LIMIT));
  });
  if (relationRead.status !== "available")
    return { rows: [], status: "unavailable", rest_calls: restCalls };
  let candidates = relationRead.rows.slice(0, CONFIRMED_RELATION_LIMIT);
  if (!candidates.length)
    return {
      rows: [],
      status: "available",
      rest_calls: restCalls,
      semantic_status: "not_needed",
      public_endpoint_status: "not_needed"
    };
  let methodsReadPromise = callerRestRows(apiKey, authorization, "method_semantics", (url) => {
    url.searchParams.set(
      "select",
      "profile,method,relation_type,label_he,calculation_description,semantic_description,confidence_source,review_version"
    ), url.searchParams.set("profile", "eq.sod1820"), url.searchParams.set("status", "eq.approved"), url.searchParams.set("is_active", "eq.true"), url.searchParams.set("limit", String(METHOD_SEMANTICS_LIMIT));
  }), partnerByRow = candidates.map((row) => String(row?.a_phrase || "").trim() === expression ? String(row?.b_phrase || "").trim() : String(row?.a_phrase || "").trim()), uniquePartners = [...new Set(partnerByRow.filter(Boolean))], publicPartnersPromise = callerRestRows(apiKey, authorization, "gematria_words", (url) => {
    url.searchParams.set("select", "phrase"), url.searchParams.set("phrase", `in.(${uniquePartners.map(postgrestQuoted).join(",")})`), url.searchParams.set("is_verified", "eq.true"), url.searchParams.set("is_published", "eq.true"), url.searchParams.set("or", "(is_encrypted.eq.false,is_encrypted.is.null)"), url.searchParams.set("limit", String(CONFIRMED_RELATION_LIMIT));
  });
  restCalls += 2;
  let [methodsRead, publicPartnersRead] = await Promise.all([
    methodsReadPromise,
    publicPartnersPromise
  ]), publicPartners = new Set(
    (publicPartnersRead.status === "available" ? publicPartnersRead.rows : []).map((row) => String(row?.phrase || "").trim()).filter(Boolean)
  ), publicEndpointComplete = publicPartnersRead.status === "available", semanticByMethod = new Map(
    (methodsRead.status === "available" ? methodsRead.rows : []).map((row) => [String(row?.method || "").trim(), row])
  );
  return {
    rows: candidates.flatMap((row, index) => {
      let partner = partnerByRow[index];
      if (!partner || !publicPartners.has(partner)) return [];
      let semantic = semanticByMethod.get(String(row?.method || "").trim()) || null;
      return [{ ...row, semantic }];
    }),
    status: publicEndpointComplete && methodsRead.status === "available" ? "available" : "partial",
    rest_calls: restCalls,
    semantic_status: methodsRead.status,
    public_endpoint_status: publicEndpointComplete ? "available" : "partial"
  };
}
async function serviceRpc(name, args) {
  if (!SUPABASE_URL || !SERVICE_KEY) return null;
  let out = await rpcTransport(SERVICE_KEY, `Bearer ${SERVICE_KEY}`).rpc(name, args);
  return out.error ? null : out.data;
}
function capabilityOutcome(status) {
  switch (String(status || "")) {
    case "executed":
      return "success";
    case "negative_result":
      return "negative_result";
    case "failed":
      return "tool_error";
    case "context_required":
      return "access_filtered";
    default:
      return "failed_with_reason";
  }
}
function bundleOutcome(bundle) {
  return bundle?.coverage?.partial === !0 ? "partial" : (bundle?.findings || []).length > 0 ? "success" : Number(bundle?.coverage?.negative_result || bundle?.coverage?.negative || 0) > 0 ? "negative_result" : "partial";
}
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ status: "error", error: "method_not_allowed" }, 405);
  if (!SUPABASE_URL || !ANON_KEY || !SERVICE_KEY) return json({ status: "error", error: "server_not_configured" }, 503);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ status: "error", error: "invalid_json_body" }, 400);
  }
  let run;
  try {
    run = normalizeResearchRunRequest(body);
  } catch (error) {
    return json({ status: "error", error: "invalid_request", detail: error instanceof Error ? error.message : String(error) }, 400);
  }
  let authHeader = cleanAuthHeader(req);
  if (!authHeader) return json({ status: "error", error: "authorization_required" }, 401);
  let userId = await verifiedUserId(authHeader), personalPair = run.contract === PERSONAL_GEMATRIA_PAIR_RESEARCH_RUN_CONTRACT, expressionCrossing = run.contract === PUBLIC_EXPRESSION_CROSSING_RESEARCH_RUN_CONTRACT, publicNumber = !personalPair && !expressionCrossing;
  if (personalPair && !userId)
    return json({ status: "error", error: "authenticated_user_required" }, 401);
  let visitorId = userId ? null : safeVisitorId(run.visitor_id);
  if (!userId && !visitorId)
    return json({ status: "error", error: "visitor_identity_required" }, 400);
  let identity = userId ? `u:${userId}` : `v:${visitorId}`, identityClass = userId ? "authenticated_user" : "public_user", executionCapability = personalPair ? "research-w2:gematria-relations" : expressionCrossing ? "research-w2:public-expression-crossings" : "research-w2:public-number", subjectRef = personalPair ? "expression-pair:ephemeral" : expressionCrossing ? "expression:ephemeral-public-query" : `number:${run.number}`, routingReason = personalPair ? "explicit_authenticated_personal_gematria_pair_v1" : expressionCrossing ? "explicit_public_expression_crossing_v1" : "explicit_public_number_golden", replayInputRef = subjectRef, traceId = crypto.randomUUID(), rootSpanId = crypto.randomUUID(), traceStartedAt = (/* @__PURE__ */ new Date()).toISOString();
  if (!await serviceRpc("op_trace_begin_v1", {
    p_trace_id: traceId,
    p_root_span_id: rootSpanId,
    p_context: {
      interaction_id: safeUuid(run.interaction_id),
      capability: executionCapability,
      surface: run.surface_context.surface,
      channel: "web",
      locale: "he",
      identity_class: identityClass,
      subject_ref: subjectRef,
      root_name: "research-run",
      owner_ref: "research_strategy_layer_law v17 + research_workspace_law v5"
    },
    p_started_at: traceStartedAt
  })) return json({ status: "error", error: "trace_unavailable" }, 503);
  let gateSpanId = crypto.randomUUID(), gateStartedAt = (/* @__PURE__ */ new Date()).toISOString(), gate = await serviceRpc("fn_capability_execution_gate_v1", {
    p_capability: executionCapability,
    p_flag_key: null,
    p_required_entitlement: "public",
    p_user_ref: userId,
    p_visitor: visitorId,
    p_identity: identity,
    p_budget_kind: "none",
    p_budget_tier: null,
    p_budget_limit_override: null
  }), gateEndedAt = (/* @__PURE__ */ new Date()).toISOString(), gateAllowed = gate?.allowed === !0, gateTraced = await serviceRpc("op_trace_record_span_v1", {
    p_trace_id: traceId,
    p_span_id: gateSpanId,
    p_parent_span_id: rootSpanId,
    p_kind: "db_rpc",
    p_name: "fn_capability_execution_gate_v1",
    p_started_at: gateStartedAt,
    p_ended_at: gateEndedAt,
    p_outcome: gate ? gateAllowed ? "success" : "access_filtered" : "failed_with_reason",
    p_detail: {
      capability: executionCapability,
      owner_ref: "site_flags_lock_law v3 + platform_tiers_law v4 + ai_quota_law v3",
      output_use: "not_applicable",
      stop_reason: gate ? gateAllowed ? null : "gate_denied" : "gate_unavailable",
      resources: { rpc_calls: 1 },
      cost: { certainty: "not_billable" },
      replay: { ownerRuleRefs: ["site_flags_lock_law v3", "platform_tiers_law v4", "ai_quota_law v3"] },
      privacy: { redactionApplied: !0, rawPrivatePayloadLogged: !1 }
    }
  });
  if (!gateTraced || !gate || !gateAllowed)
    return await serviceRpc("op_trace_finish_v1", {
      p_trace_id: traceId,
      p_root_span_id: rootSpanId,
      p_outcome: gate ? "access_filtered" : "failed_with_reason",
      p_ended_at: (/* @__PURE__ */ new Date()).toISOString(),
      p_stop_reason: gate ? "gate_denied" : "gate_unavailable"
    }), json({
      status: "error",
      error: gate ? gateTraced ? "access_filtered" : "trace_incomplete" : "gate_unavailable",
      trace_id: traceId
    }, 200);
  let callerRpc = rpcTransport(ANON_KEY, authHeader), baseExecutors = createCanonicalW2Executors({
    supabase: callerRpc,
    serverContext: !1
  }), presentationRanking = [], numericExecutor = baseExecutors.numeric, publicExecutors = publicNumber && typeof numericExecutor == "function" ? Object.freeze({
    ...baseExecutors,
    numeric: async (args) => {
      let [numeric, presentationRead] = await Promise.all([
        numericExecutor(args),
        fetchNumberPhrasePresentationRows(ANON_KEY, authHeader, run.number)
      ]);
      if (numeric?.status !== "executed" || presentationRead.status !== "available")
        return {
          ...numeric,
          trace: {
            ...numeric?.trace || {},
            presentation_order: {
              authority: NUMBER_PHRASE_PRESENTATION_AUTHORITY.ref,
              scope: NUMBER_PHRASE_PRESENTATION_AUTHORITY.scope,
              status: presentationRead.status,
              row_count: 0,
              added_finding_count: 0,
              rpc_calls: 1,
              ai_calls: 0,
              retry_count: 0
            }
          }
        };
      let projected = mergeNumberPhrasePresentationOrder({
        findings: numeric.findings,
        rows: presentationRead.rows,
        number: run.number
      });
      return presentationRanking = [...projected.ranking], {
        ...numeric,
        findings: projected.findings,
        sourceRefs: [.../* @__PURE__ */ new Set([...numeric.sourceRefs || [], NUMBER_PHRASE_PRESENTATION_AUTHORITY.ref])],
        versionRefs: [.../* @__PURE__ */ new Set([...numeric.versionRefs || [], `number-phrase-presentation-order:v${NUMBER_PHRASE_PRESENTATION_AUTHORITY.version}`])],
        trace: {
          ...numeric.trace || {},
          presentation_order: {
            authority: NUMBER_PHRASE_PRESENTATION_AUTHORITY.ref,
            scope: NUMBER_PHRASE_PRESENTATION_AUTHORITY.scope,
            status: "available",
            row_count: projected.row_count,
            added_finding_count: projected.added_count,
            rpc_calls: 1,
            ai_calls: 0,
            retry_count: 0
          }
        }
      };
    }
  }) : baseExecutors, executors = personalPair ? Object.freeze({
    ...baseExecutors,
    [PERSONAL_GEMATRIA_PAIR_CAPABILITY]: createGematriaRelationW2Executor({
      supabase: callerRpc,
      pairMode: GEMATRIA_RELATION_PAIR_MODE.INTAKE_DIRECT_PAIR,
      maxRepresentations: 2,
      maxPairs: 1
    })
  }) : expressionCrossing ? Object.freeze({
    gematria: createGematriaMethodProfileW2Executor({
      supabase: callerRpc,
      readMethodRegistry: () => fetchGematriaMethodDependencyRows(ANON_KEY, authHeader)
    }),
    [PUBLIC_EXPRESSION_CROSSING_CAPABILITY]: createGematriaCorpusCrossingW2Executor({
      supabase: callerRpc,
      limit: 8,
      normalizeRelations: !0,
      readConfirmedRelations: (args) => fetchConfirmedSemanticRelationRows(ANON_KEY, authHeader, args)
    })
  }) : publicExecutors, capabilityEvents = [], composeSpanId = crypto.randomUUID(), composeStartedAt = (/* @__PURE__ */ new Date()).toISOString(), authorizationContext = userId ? {
    verified_authority: {
      source: "supabase_auth",
      subject_verified: !0,
      admin: gate?.entitlement?.is_admin === !0
    },
    entitlement_level: gate?.entitlement?.entitlement || null
  } : null, bundle;
  try {
    bundle = await composeResearchW2({
      question: run.question,
      intent: run.intent,
      identityCandidates: run.identity_candidates,
      rawInput: personalPair ? null : expressionCrossing ? run.expression : String(run.number),
      intake: personalPair ? run.intake : null,
      explicitTextComputation: expressionCrossing,
      authorizationContext,
      contextType: identityClass,
      surfaceContext: run.surface_context,
      requestedCapabilities: run.requested_capabilities,
      // No identity/text inference ever widens this transport's execution plan beyond the exact
      // capabilities the validated request asked for — even if `question` free text mentions more.
      capabilityAllowlist: run.requested_capabilities,
      requestedDepth: personalPair ? "personal_gematria_pair_v1" : expressionCrossing ? "public_expression_crossing_v1" : "golden_public_number_v1",
      executors,
      rankingResolver: publicNumber ? () => presentationRanking : null,
      // Timestamps/status/counts only — never raw Findings/content cross this boundary.
      executionObserver: (event) => capabilityEvents.push(event)
    });
  } catch {
    return await serviceRpc("op_trace_finish_v1", {
      p_trace_id: traceId,
      p_root_span_id: rootSpanId,
      p_outcome: "failed_with_reason",
      p_ended_at: (/* @__PURE__ */ new Date()).toISOString(),
      p_stop_reason: "composer_failed"
    }), json({ status: "error", error: "research_failed", trace_id: traceId }, 200);
  }
  let composeEndedAt = (/* @__PURE__ */ new Date()).toISOString(), planRef = personalPair ? "research-plan-v2:personal-gematria-pair" : expressionCrossing ? "research-plan-v2:public-expression-crossing" : `research-plan-v2:number:${run.number}`, traceComplete = !!await serviceRpc("op_trace_record_span_v1", {
    p_trace_id: traceId,
    p_span_id: composeSpanId,
    p_parent_span_id: rootSpanId,
    p_kind: "router_plan",
    p_name: "composeResearchW2",
    p_started_at: composeStartedAt,
    p_ended_at: composeEndedAt,
    p_outcome: bundleOutcome(bundle),
    p_detail: {
      capability: executionCapability,
      owner_ref: "research_strategy_layer_law v17",
      plan_ref: planRef,
      routing_reason: routingReason,
      output_use: "used",
      resources: { capability_count: capabilityEvents.length },
      cost: { certainty: "not_billable" },
      replay: {
        inputRef: replayInputRef,
        ownerRuleRefs: ["research_strategy_layer_law v17", "research_workspace_law v5"],
        parametersRef: run.contract
      },
      privacy: { redactionApplied: !0, rawPrivatePayloadLogged: !1 }
    }
  });
  for (let event of capabilityEvents)
    await serviceRpc("op_trace_record_span_v1", {
      p_trace_id: traceId,
      p_span_id: crypto.randomUUID(),
      p_parent_span_id: composeSpanId,
      p_kind: "engine",
      p_name: `w2:${event.capability}`,
      p_started_at: event.started_at,
      p_ended_at: event.ended_at,
      p_outcome: capabilityOutcome(event.status),
      p_detail: {
        capability: event.capability,
        owner_ref: event.owner || "research_strategy_layer_law v17",
        plan_ref: planRef,
        output_use: event.finding_count > 0 ? "used" : "not_applicable",
        resources: {
          findings: event.finding_count,
          bounded: event.bounded || null
        },
        cost: { certainty: "not_billable" },
        replay: { inputRef: replayInputRef },
        privacy: { redactionApplied: !0, rawPrivatePayloadLogged: !1 }
      }
    }) || (traceComplete = !1);
  if (!traceComplete)
    return await serviceRpc("op_trace_finish_v1", {
      p_trace_id: traceId,
      p_root_span_id: rootSpanId,
      p_outcome: "failed_with_reason",
      p_ended_at: (/* @__PURE__ */ new Date()).toISOString(),
      p_stop_reason: "trace_incomplete"
    }), json({ status: "error", error: "trace_incomplete", trace_id: traceId }, 200);
  let outcome = bundleOutcome(bundle);
  return await serviceRpc("op_trace_finish_v1", {
    p_trace_id: traceId,
    p_root_span_id: rootSpanId,
    p_outcome: outcome,
    p_ended_at: (/* @__PURE__ */ new Date()).toISOString(),
    p_stop_reason: null
  }) ? json({
    status: "ok",
    contract: run.contract,
    trace_id: traceId,
    bundle
  }) : json({ status: "error", error: "trace_incomplete", trace_id: traceId }, 200);
});
