const {request}=require('@playwright/test');
module.exports=async function(context){
 const proxy=await request.newContext({proxy:{server:process.env.HTTPS_PROXY},timeout:30000});
 await context.route('**/*',async route=>{
  const req=route.request(),u=new URL(req.url());
  if(u.origin==='http://127.0.0.1:4173')return route.continue();
  if(!['GET','HEAD','OPTIONS'].includes(req.method()) && !(u.origin==='https://linswmnnkjxvweumprav.supabase.co' && /^\/rest\/v1\/rpc\//.test(u.pathname))) return route.abort('blockedbyclient');
  try { const response=await proxy.fetch(req); await route.fulfill({response}); }catch {await route.abort('failed');}
 });return proxy;
};