
const deny=()=>{throw Error('SOURCE_ACCEPTANCE_NETWORK_DENIED');};
globalThis.fetch=deny;globalThis.WebSocket=class{constructor(){deny();}};
for(const name of ['http','https']){const api=require('node:'+name);api.request=deny;api.get=deny;}
const net=require('node:net');net.connect=deny;net.createConnection=deny;net.Socket.prototype.connect=deny;
require('node:module').syncBuiltinESMExports();
